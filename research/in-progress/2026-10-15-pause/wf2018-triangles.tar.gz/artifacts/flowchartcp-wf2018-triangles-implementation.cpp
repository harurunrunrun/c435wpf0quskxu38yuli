#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <istream>
#include <ostream>
#include <span>
#include <stdexcept>
#include <string>
#include <vector>

namespace triangular_runs {
// At a vertex (row,k): horizontal to k+2,then down-left/down-right.
inline constexpr std::uint8_t horizontal = 1, down_left = 2, down_right = 4;
struct Grid {
    int rows = 0, columns = 0;
    std::vector<std::uint8_t> edges;
};

inline void check_dimensions(int rows, int columns) {
    if (rows < 1 || rows > 3000 || columns < 1 || columns > 6000)
        throw std::invalid_argument("triangular-grid dimensions");
}
inline void validate(const Grid& grid) {
    check_dimensions(grid.rows, grid.columns);
    if (grid.edges.size() != std::size_t(grid.rows) * grid.columns)
        throw std::invalid_argument("triangular-grid edge array size");
    for (int row = 0; row < grid.rows; ++row) {
        for (int k = 0; k < grid.columns; ++k) {
            const auto bits = grid.edges[std::size_t(row) * grid.columns + k];
            unsigned allowed = 0;
            if ((k & 1) == (row & 1)) {
                if (k + 2 < grid.columns) allowed |= horizontal;
                if (row + 1 < grid.rows) {
                    if (k > 0) allowed |= down_left;
                    if (k + 1 < grid.columns) allowed |= down_right;
                }
            }
            if ((unsigned(bits) & ~allowed) != 0)
                throw std::invalid_argument("edge has no legal endpoints");
        }
    }
}

namespace detail {
class Fenwick {
    std::vector<int> tree;
public:
    explicit Fenwick(int n) : tree(std::size_t(n) + 1) {}
    void clear() { std::fill(tree.begin(), tree.end(), 0); }
    void add(int point, int delta) {
        for (int i = point + 1; i < int(tree.size()); i += i & -i)
            tree[i] += delta;
    }
    int prefix(int end) const {
        int result = 0;
        for (int i = end; i > 0; i -= i & -i) result += tree[i];
        return result;
    }
    int range(int left, int right) const { return prefix(right) - prefix(left); }
};

inline std::int64_t one_direction(const Grid& grid, bool reverse) {
    const int offset = grid.rows / 2 + 1;
    const int width = offset + (grid.columns + 1) / 2 + 2;
    std::vector<int> up(width), diagonal(width), expiry_head(width), next(width);
    Fenwick active(width);
    const int first_row = reverse ? grid.rows - 1 : 0;
    const int first_parity = first_row & 1;
    auto edge = [&](int row, int k, unsigned mask) {
        return (grid.edges[std::size_t(row) * grid.columns + k] & mask) != 0;
    };
    std::int64_t answer = 0;
    for (int y = 0; y < grid.rows; ++y) {
        const int row = reverse ? grid.rows - 1 - y : y;
        std::fill(expiry_head.begin(), expiry_head.end(), -1);
        active.clear();
        int left_run = 0;
        for (int k = row & 1; k < grid.columns; k += 2) {
            const int x = (k - y - first_parity) / 2 + offset;
            left_run = k >= 2 && edge(row, k - 2, horizontal) ? left_run + 1 : 0;
            bool has_up = false, has_diagonal = false;
            if (y > 0 && !reverse) {
                has_up = k > 0 && edge(row - 1, k - 1, down_right);
                has_diagonal = k + 1 < grid.columns && edge(row - 1, k + 1, down_left);
            } else if (y > 0) {
                has_up = k > 0 && edge(row, k, down_left);
                has_diagonal = k + 1 < grid.columns && edge(row, k, down_right);
            }
            up[x] = has_up ? up[x] + 1 : 0;
            // x increases,so diagonal[x+1] still belongs to the previous row.
            diagonal[x] = has_diagonal ? diagonal[x + 1] + 1 : 0;
            for (int j = expiry_head[x]; j != -1; j = next[j]) active.add(j, -1);
            const int size = std::min(left_run, up[x]);
            if (size) answer += active.range(x - size, x);
            if (diagonal[x] > 0) {
                active.add(x, 1);
                const int expires = x + diagonal[x] + 1;
                if (expires < width) {
                    next[x] = expiry_head[expires];
                    expiry_head[expires] = x;
                }
            }
        }
    }
    return answer;
}
} // namespace detail

inline std::int64_t count_triangles(const Grid& grid) {
    validate(grid);
    return detail::one_direction(grid, false) + detail::one_direction(grid, true);
}

inline Grid parse_picture(int rows, int columns, std::span<const std::string> lines) {
    check_dimensions(rows, columns);
    if (lines.size() != std::size_t(2 * rows - 1))
        throw std::invalid_argument("triangular-grid picture line count");
    const int width = 2 * columns - 1;
    for (const auto& line : lines)
        if (line.size() > std::size_t(width))
            throw std::invalid_argument("triangular-grid picture line width");
    auto at = [&](int row, int col) {
        return std::size_t(col) < lines[row].size() ? lines[row][col] : ' ';
    };
    // Validate the entire picture before allocating the parsed edge array.
    for (int row = 0; row < rows; ++row) {
        const int parity = row & 1;
        const int first = 2 * parity;
        const int last = parity < columns
            ? 2 * (parity + 2 * ((columns - 1 - parity) / 2)) : -1;
        for (int k = parity; k < columns; k += 2) {
            if (at(2 * row, 2 * k) != 'x')
                throw std::invalid_argument("missing triangular-grid vertex");
            if (k + 2 < columns) {
                const char a = at(2 * row, 2 * k + 1);
                if ((a != ' ' && a != '-') || at(2 * row, 2 * k + 2) != a
                    || at(2 * row, 2 * k + 3) != a)
                    throw std::invalid_argument("horizontal edge needs three dashes");
            }
        }
        const auto& line = lines[2 * row];
        for (int col = 0; col < int(line.size()); ++col) {
            const char ch = line[col];
            if (ch == ' ') continue;
            const bool vertex = col >= first && col <= last && (col - first) % 4 == 0;
            const bool dash = col > first && col < last && (col - first) % 4 != 0;
            if (!((ch == 'x' && vertex) || (ch == '-' && dash)))
                throw std::invalid_argument("unexpected vertex-row character");
        }
        if (row + 1 < rows) {
            const auto& between = lines[2 * row + 1];
            for (int col = 0; col < int(between.size()); ++col) {
                if (between[col] == ' ') continue;
                const int gap = col / 2;
                const char expected = (gap & 1) == parity ? '\\' : '/';
                if ((col & 1) == 0 || gap + 1 >= columns || between[col] != expected)
                    throw std::invalid_argument("unexpected diagonal-row character");
            }
        }
    }
    Grid grid{rows, columns, std::vector<std::uint8_t>(std::size_t(rows) * columns)};
    for (int row = 0; row < rows; ++row) {
        for (int k = row & 1; k < columns; k += 2) {
            auto& bits = grid.edges[std::size_t(row) * columns + k];
            if (k + 2 < columns && at(2 * row, 2 * k + 1) == '-') bits |= horizontal;
            if (row + 1 < rows) {
                if (k > 0 && at(2 * row + 1, 2 * k - 1) == '/') bits |= down_left;
                if (k + 1 < columns && at(2 * row + 1, 2 * k + 1) == '\\') bits |= down_right;
            }
        }
    }
    return grid;
}

inline std::int64_t count_picture(int rows, int columns,
                                  std::span<const std::string> lines) {
    return count_triangles(parse_picture(rows, columns, lines));
}

inline std::int64_t read_and_count(std::istream& input) {
    int rows = 0, columns = 0;
    if (!(input >> rows >> columns)) throw std::invalid_argument("missing picture dimensions");
    check_dimensions(rows, columns);
    std::string line;
    std::getline(input, line);
    if (line.find_first_not_of(" \t\r") != std::string::npos)
        throw std::invalid_argument("unexpected dimension-line token");
    std::vector<std::string> lines;
    lines.reserve(2 * rows - 1);
    for (int i = 0; i < 2 * rows - 1; ++i) {
        if (!std::getline(input, line)) throw std::invalid_argument("missing picture line");
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (line.size() > std::size_t(2 * columns - 1))
            throw std::invalid_argument("picture line too long");
        lines.push_back(std::move(line));
    }
    input >> std::ws;
    if (input.peek() != std::char_traits<char>::eof())
        throw std::invalid_argument("unexpected data after picture");
    return count_picture(rows, columns, lines);
}

inline void solve(std::istream& input, std::ostream& output) {
    const auto answer = read_and_count(input);
    const std::string text = std::to_string(answer) + '\n';
    output.write(text.data(), static_cast<std::streamsize>(text.size()));
    if (!output) throw std::ios_base::failure("triangle answer write failed");
}
} // namespace triangular_runs
