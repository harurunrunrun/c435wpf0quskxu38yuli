#!/usr/bin/env python3
"""Extract the actual single visible MDX C++ fence and verify literal grid edges."""
import argparse,hashlib,json,os,pathlib,re,subprocess,tempfile

HARNESS=r'''
#include <chrono>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <new>
#include <random>
#include <sstream>
#include <sys/resource.h>
#include <type_traits>
using namespace triangular_runs;
using I=std::int64_t;
struct Injected:std::bad_alloc{};
struct alignas(std::max_align_t) Header{std::size_t bytes;};
static long fail_after=-1,allocations=0;static std::size_t live_bytes=0,peak_bytes=0;
__attribute__((noinline))void*operator new(std::size_t n){if(fail_after>=0&&allocations++==fail_after)throw Injected{};auto*p=static_cast<Header*>(std::malloc(sizeof(Header)+n));if(!p)throw std::bad_alloc{};p->bytes=n;live_bytes+=n;peak_bytes=std::max(peak_bytes,live_bytes);return p+1;}
__attribute__((noinline))void operator delete(void*q)noexcept{if(q){auto*p=static_cast<Header*>(q)-1;live_bytes-=p->bytes;std::free(p);}}
void*operator new[](std::size_t n){return::operator new(n);}void operator delete[](void*p)noexcept{::operator delete(p);}void operator delete(void*p,std::size_t)noexcept{::operator delete(p);}void operator delete[](void*p,std::size_t)noexcept{::operator delete(p);}
static std::uint64_t checks=0,api=0,checksum=0,patterns=0,pattern_shapes=0,randoms=0,literal_triangles=0,literal_edge_tests=0,encode_decode=0,raw_counts=0,streams=0,writers=0,metamorphic=0,invalids=0,faults=0;
static std::mt19937_64 rng(0x20180419ULL);
void need(bool b,const char*why){++checks;if(!b)throw std::runtime_error(why);}void rec(I x){checksum=checksum*1000003ULL+static_cast<std::uint64_t>(x);}
I core(const Grid&g){++api;auto v=count_triangles(g);rec(v);return v;}
Grid parsed(int r,int c,const std::vector<std::string>&lines){++api;++encode_decode;return parse_picture(r,c,lines);}
struct Edge{int a,b,slot;std::uint8_t bit;};
std::vector<Edge>catalogue(int r,int c){std::vector<Edge>out;
 for(int y=0;y<r;++y)for(int k=y&1;k<c;k+=2){int a=y*c+k;
  if(k+2<c)out.push_back({a,a+2,a,1});
  if(y+1<r){if(k>0)out.push_back({a,a+c-1,a,2});if(k+1<c)out.push_back({a,a+c+1,a,4});}
 }return out;}
Grid from_bits(int r,int c,const std::vector<Edge>&edges,const std::vector<bool>&chosen){Grid g{r,c,std::vector<std::uint8_t>(std::size_t(r)*c)};
 for(std::size_t i=0;i<edges.size();++i)if(chosen[i])g.edges[edges[i].slot]|=edges[i].bit;
 return g;}
I literal(int r,int c,const std::vector<Edge>&edges,const std::vector<bool>&chosen){const int vertices=r*c;std::vector<int>lookup(std::size_t(vertices)*vertices,-1);
 for(std::size_t i=0;i<edges.size();++i)lookup[edges[i].a*vertices+edges[i].b]=lookup[edges[i].b*vertices+edges[i].a]=static_cast<int>(i);
 auto has=[&](int a,int b){++literal_edge_tests;int e=lookup[a*vertices+b];return e>=0&&chosen[e];};I answer=0;
 for(int y=0;y<r;++y)for(int k=y&1;k<c;k+=2)for(int length=1;k+2*length<c;++length)for(int direction:{-1,1}){
  int apex_row=y+direction*length;if(apex_row<0||apex_row>=r)continue;++literal_triangles;bool closed=true;
  for(int i=0;i<length;++i){int row=y+direction*i,next=row+direction;
   closed&=has(y*c+k+2*i,y*c+k+2*i+2);
   closed&=has(row*c+k+i,next*c+k+i+1);
   closed&=has(row*c+k+2*length-i,next*c+k+2*length-i-1);
  }answer+=closed;
 }return answer;}
std::vector<std::string>encode(int r,int c,const std::vector<Edge>&edges,const std::vector<bool>&chosen,bool trim){std::vector<std::string>lines(2*r-1,std::string(2*c-1,' '));
 for(int y=0;y<r;++y)for(int k=y&1;k<c;k+=2)lines[2*y][2*k]='x';
 for(std::size_t i=0;i<edges.size();++i)if(chosen[i]){int ay=edges[i].a/c,ak=edges[i].a%c,by=edges[i].b/c,bk=edges[i].b%c;
  if(ay==by){int start=2*std::min(ak,bk);for(int step=1;step<=3;++step)lines[2*ay][start+step]='-';}
  else lines[ay+by][ak+bk]=bk>ak?'\\':'/';
 }
 if(trim)for(auto&line:lines){auto last=line.find_last_not_of(' ');line.resize(last==std::string::npos?0:last+1);}
 return lines;}
std::string text_picture(int r,int c,const std::vector<std::string>&lines,bool crlf=false){std::string text=std::to_string(r)+" "+std::to_string(c)+(crlf?"\r\n":"\n");
 for(const auto&line:lines){text+=line;text+=crlf?"\r\n":"\n";}return text;}
void stream_check(int r,int c,const std::vector<std::string>&lines,I expected,bool crlf){const auto text=text_picture(r,c,lines,crlf);std::istringstream input(text);++api;++streams;need(read_and_count(input)==expected,"raw reader preserves empty/omitted-tail picture lines");
 std::istringstream again(text);std::ostringstream output;output<<std::hex<<std::showbase<<std::setfill('@');output.width(19);const auto flags=output.flags();const auto fill=output.fill();auto width=output.width();++api;++writers;solve(again,output);
 need(output.str()==std::to_string(expected)+"\n","writer decimal exact unformatted result");need(output.flags()==flags&&output.fill()==fill&&output.width()==width,"writer preserves caller format");}
void verify(int r,int c,const std::vector<Edge>&edges,const std::vector<bool>&chosen,bool io){const auto g=from_bits(r,c,edges,chosen);const auto before=g.edges;I expected=literal(r,c,edges,chosen);
 need(core(g)==expected,"all-three-literal-edge-chain oracle");need(g.edges==before,"core does not mutate parsed edge data");
 auto full=encode(r,c,edges,chosen,false),trimmed=encode(r,c,edges,chosen,true);
 const auto p=parsed(r,c,full),q=parsed(r,c,trimmed);need(p.rows==r&&p.columns==c&&p.edges==g.edges&&q.edges==g.edges,"every edge pattern ASCII encode/decode");
 ++api;++raw_counts;need(count_picture(r,c,trimmed)==expected,"combined raw-picture count versus literal edges");if(io)stream_check(r,c,trimmed,expected,patterns%2);
}
void exhaustive(){for(int r=1;r<=4;++r)for(int c=1;c<=6;++c){auto e=catalogue(r,c);if(e.size()>18)continue;++pattern_shapes;
 for(std::uint64_t mask=0;mask<(1ULL<<e.size());++mask){std::vector<bool>chosen(e.size());for(std::size_t i=0;i<e.size();++i)chosen[i]=(mask>>i)&1;++patterns;verify(r,c,e,chosen,patterns%503==0);}
}}
void random_checks(){for(int it=0;it<1200;++it){int r=1+int(rng()%12),c=1+int(rng()%21);auto e=catalogue(r,c);std::vector<bool>chosen(e.size());for(std::size_t i=0;i<e.size();++i)chosen[i]=rng()%4!=0;
 verify(r,c,e,chosen,it<100);++randoms;
 if(it<200){Grid base=from_bits(r,c,e,chosen);I before=core(base);Grid padded{r+4,c+4,std::vector<std::uint8_t>(std::size_t(r+4)*(c+4))};
  for(int row=0;row<r;++row)for(int k=0;k<c;++k)padded.edges[std::size_t(row+2)*(c+4)+k+2]=base.edges[std::size_t(row)*c+k];
  need(core(padded)==before,"isolated two-row/column border preserves triangles");++metamorphic;
  if(r%2==1){Grid reflected{r,c,std::vector<std::uint8_t>(std::size_t(r)*c)};
   for(std::size_t i=0;i<e.size();++i)if(chosen[i]){int ar=r-1-e[i].a/c,ak=e[i].a%c,br=r-1-e[i].b/c,bk=e[i].b%c;if(ar>br){std::swap(ar,br);std::swap(ak,bk);}if(ar==br)reflected.edges[std::size_t(ar)*c+std::min(ak,bk)]|=1;else reflected.edges[std::size_t(ar)*c+ak]|=bk<ak?2:4;}
   need(core(reflected)==before,"odd-height true vertical geometric reflection");++metamorphic;
  }
 }
}}
Grid complete(int r,int c){Grid g{r,c,std::vector<std::uint8_t>(std::size_t(r)*c)};for(int y=0;y<r;++y)for(int k=y&1;k<c;k+=2){auto&v=g.edges[std::size_t(y)*c+k];if(k+2<c)v|=1;if(y+1<r){if(k>0)v|=2;if(k+1<c)v|=4;}}return g;}
I full_formula(int r,int c){I result=0;for(int size=1;size<r&&2*size<c;++size){I even=(c+1-2*size)/2,odd=(c-2*size)/2;int count=r-size;
 auto rows=[&](int first){I evens=(count+((first&1)==0))/2;return evens*even+(count-evens)*odd;};result+=rows(0)+rows(size);}return result;}
struct Maximum{int r,c;std::string name;I answer;double seconds;};static std::vector<Maximum>maximums;
void maximum_case(int r,int c,const std::string&name,bool missing=false){auto g=complete(r,c);I expected=full_formula(r,c);if(missing){g.edges[0]&=~1;expected-=std::min(r-1,(c-1)/2);}
 auto start=std::chrono::steady_clock::now();need(core(g)==expected,"original maximum complete grid independent parity closed formula/boundary edge incidence");double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();maximums.push_back({r,c,name,expected,seconds});}
void maximum_checks(){for(int r=1;r<=12;++r)for(int c=1;c<=15;++c){auto e=catalogue(r,c);std::vector<bool>chosen(e.size(),true);need(full_formula(r,c)==literal(r,c,e,chosen),"independent complete-grid formula versus literal three-side enumeration");}
 maximum_case(3000,6000,"complete source maximum");maximum_case(3000,6000,"leftmost top horizontal edge absent",true);maximum_case(3000,5999,"odd source width");maximum_case(2999,6000,"odd source height");maximum_case(3000,1,"empty odd vertex rows");maximum_case(1,6000,"no height");maximum_case(3000,3,"single possible horizontal base");
 auto g=complete(3000,6000);std::vector<std::string>lines(5999,std::string(11999,' '));for(int y=0;y<3000;++y){for(int k=y&1;k<6000;k+=2){lines[2*y][2*k]='x';if(k+2<6000)for(int d=1;d<=3;++d)lines[2*y][2*k+d]='-';}if(y+1<3000)for(int k=0;k+1<6000;++k)lines[2*y+1][2*k+1]=(k&1)==(y&1)?'\\':'/';}
 auto start=std::chrono::steady_clock::now();++api;++raw_counts;need(count_picture(3000,6000,lines)==full_formula(3000,6000),"full source raw parse+count");maximums.push_back({3000,6000,"raw full-width picture parse and count",full_formula(3000,6000),std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()});
 const auto raw=text_picture(3000,6000,lines);std::istringstream input(raw);std::ostringstream output;start=std::chrono::steady_clock::now();++api;++streams;++writers;solve(input,output);need(output.str()=="17991001000\n","maximum raw stream reader/writer including64bitcount");maximums.push_back({3000,6000,"full raw stream solve",17991001000LL,std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()});
}
template<class F>void invalid(F fn){++api;bool caught=false;try{fn();}catch(const std::invalid_argument&){caught=true;}need(caught,"invalid input rejected");++invalids;}
void api_checks(){static_assert(std::is_same_v<decltype(&count_triangles),I(*)(const Grid&)>);static_assert(std::is_same_v<decltype(&parse_picture),Grid(*)(int,int,std::span<const std::string>)>);
 invalid([]{(void)count_triangles({0,1,{}});});invalid([]{(void)count_triangles({3001,1,{}});});invalid([]{(void)count_triangles({1,6001,{}});});invalid([]{(void)count_triangles({1,0,{}});});invalid([]{(void)count_triangles({1,1,{}});});
 for(auto g:std::vector<Grid>{{1,2,{0,1}},{1,1,{1}},{2,3,{2,0,0,0,0,0}},{1,1,{4}},{1,1,{8}},{1,3,{0,0,1}}})invalid([&]{(void)count_triangles(g);});
 for(const auto&lines:std::vector<std::vector<std::string>>{{},{"X"},{"xx"},{"x\t"},{"x-"}})invalid([&]{(void)parse_picture(1,1,lines);});
 for(const std::string&row:{std::string("x-- x"),std::string("x- -x"),std::string("x___x"),std::string("x---X")})invalid([&]{(void)parse_picture(1,3,std::vector<std::string>{row});});
 for(const std::string&between:{std::string(" /"),std::string("\\"),std::string("  /"),std::string(" x"),std::string(" \t")})invalid([&]{(void)parse_picture(2,2,std::vector<std::string>{"x",between,"  x"});});
 for(const std::string&text:{std::string(""),std::string("99999999999999999999 1\n"),std::string("1 1 extra\nx\n"),std::string("2 1\nx\n"),std::string("1 1\nx\nextra"),std::string("1 1\nx\rX\n")})invalid([&]{std::istringstream in(text);(void)read_and_count(in);});
 auto empty=parsed(2,1,{"x","",""});need(core(empty)==0,"source C1 can have no vertex on odd row");stream_check(2,1,{"x","",""},0,true);
 auto source=complete(7,9),copy=source;I answer=core(source);std::fill(copy.edges.begin(),copy.edges.end(),0);need(core(copy)==0&&core(source)==answer,"copied grid data independent");for(int i=0;i<1000;++i)need(core(i&1?source:copy)==(i&1?answer:0),"no persistent state between calls");
 std::istringstream in("1 1\nx\n");std::ostringstream out;out.setstate(std::ios::badbit);++api;bool failed=false;try{solve(in,out);}catch(const std::ios_base::failure&){failed=true;}need(failed,"failed output propagated");
}
template<class F>void faults_for(F fn){const auto memory=live_bytes;fail_after=1000000;allocations=0;++api;fn();long sites=allocations;fail_after=-1;need(live_bytes==memory&&sites>0,"fault target complete allocation accounting");
 for(long site=0;site<sites;++site){fail_after=site;allocations=0;bool caught=false;try{++api;fn();}catch(const Injected&){caught=true;}fail_after=-1;need(caught&&live_bytes==memory,"pure API strong allocation unwind and exact exception subtype");++faults;++api;fn();need(live_bytes==memory,"successful reentry after fault");}}
void exception_checks(){auto g=complete(17,31);auto e=catalogue(17,31);std::vector<bool>chosen(e.size(),true);auto lines=encode(17,31,e,chosen,true);auto before=g.edges;auto raw_before=lines;
 faults_for([&]{need(count_triangles(g)==full_formula(17,31),"allocation core success");});faults_for([&]{auto q=parse_picture(17,31,lines);need(q.edges==before,"allocation parse success");});faults_for([&]{need(count_picture(17,31,lines)==full_formula(17,31),"allocation combined success");});faults_for([&]{auto q=g;need(q.edges==before,"allocation independent copy success");});
 need(g.edges==before&&lines==raw_before,"all allocation exceptions preserve caller containers");}
int main(){try{auto start=std::chrono::steady_clock::now();exhaustive();random_checks();maximum_checks();api_checks();exception_checks();rusage usage{};getrusage(RUSAGE_SELF,&usage);
 std::cout<<"{\"checks\":"<<checks<<",\"apiCalls\":"<<api<<",\"allEdgeSubsets\":"<<patterns<<",\"allSmallShapes\":"<<pattern_shapes<<",\"randomInputs\":"<<randoms<<",\"literalTriangleCandidates\":"<<literal_triangles<<",\"literalBoundaryEdgeTests\":"<<literal_edge_tests<<",\"asciiEncodeDecodeCalls\":"<<encode_decode<<",\"rawCountCalls\":"<<raw_counts<<",\"streamCases\":"<<streams<<",\"writerCases\":"<<writers<<",\"metamorphicChecks\":"<<metamorphic<<",\"invalidCases\":"<<invalids<<",\"allocationFailuresInjected\":"<<faults<<",\"checksum\":\""<<checksum<<"\",\"seconds\":"<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<",\"peakRSSKiB\":"<<usage.ru_maxrss<<",\"maximumCases\":[";
 bool comma=false;for(const auto&c:maximums){if(comma)std::cout<<',';comma=true;std::cout<<"{\"rows\":"<<c.r<<",\"columns\":"<<c.c<<",\"name\":\""<<c.name<<"\",\"answer\":"<<c.answer<<",\"seconds\":"<<c.seconds<<'}';}std::cout<<"]}\n";
 }catch(const std::exception&e){fail_after=-1;std::cerr<<e.what()<<'\n';return 1;}}
'''

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--sanitize',action='store_true');ap.add_argument('--article',default='/tmp/flowchartcp-wf2018-triangles-article.mdx');ap.add_argument('--output');args=ap.parse_args()
    article=pathlib.Path(args.article).read_bytes();text=article.decode();fences=re.findall(r'^```cpp\s*\n(.*?)^```\s*$',text,re.M|re.S);assert len(fences)==1 and '<details'not in text
    assert re.findall(r'^## (.*)$',text,re.M)==['使う場面','考え方','適用条件','なぜ正しいか','計算量','実装','関連する手法','参考資料'];cpp=fences[0]
    flags=['-std=c++20','-O2','-Wall','-Wextra','-Werror']
    if args.sanitize:flags+=['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie']
    with tempfile.TemporaryDirectory(prefix='flowchartcp-triangles-native-')as folder:
        source=pathlib.Path(folder)/'check.cpp';binary=pathlib.Path(folder)/'check';source.write_text(cpp+'\n'+HARNESS);subprocess.run(['g++',*flags,str(source),'-o',str(binary)],check=True)
        env=os.environ.copy()
        if args.sanitize:env['ASAN_OPTIONS']='detect_leaks=0:halt_on_error=1:quarantine_size_mb=64';env['UBSAN_OPTIONS']='halt_on_error=1:print_stacktrace=1'
        run=subprocess.run([str(binary)],capture_output=True,text=True,env=env)
        if run.returncode:raise RuntimeError(run.stderr or run.stdout)
        result=json.loads(run.stdout)
    result.update(cppSha256=hashlib.sha256(cpp.encode()).hexdigest(),articleSha256=hashlib.sha256(article).hexdigest(),sanitized=args.sanitize,compilerFlags=flags)
    output=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
    if args.output:pathlib.Path(args.output).write_text(output)
    print(output,end='')
if __name__=='__main__':main()
