from pathlib import Path
import hashlib,json
P=Path('/tmp');B=P/'flowchartcp-ioi2015-baseline'
def read(name):return json.loads((P/f'flowchartcp-ioi2015-{name}.json').read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,obj):
 p=P/f'flowchartcp-ioi2015-{name}.json';p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');return p
selection=read('selection');manifest=read('manifest');vendor=read('vendor-manifest');routes=read('routes');scope=read('scope-checks');probe=read('probe');runtime=read('runtime-replay')
by={r['techniqueId']:r for r in scope['records']}
ids=['boxes','scales','teams','horses','sorting','towns']
related={
'boxes':['heuristic-precedence-two-opt','median-window-budget','optional-booster-subset-speed'],
'scales':['interactive','interactive-bit-group-testing','interactive-transition-count-species-decision-trees'],
'teams':['persistent-segment-tree','persistent-prefix-kth','matching','threshold-coupon-max-discount'],
'horses':['segment-tree','maximum-product-sign-exchange','point-update-nonadjacent-max-sum'],
'sorting':['permutation-cycle-minimum-swaps','simultaneous-swap-parity','binary-search'],
'towns':['interactive-tree-diameter','tree-eccentricity-diameter-endpoints','centroid-count-cross-subtrees']}
features={
'boxes':['円周上の各地点へ一個ずつ配達し、倉庫のある出発点へ最後に戻る。','一回に運べる個数Kが決まり、補充は出発点だけ。重複地点もある。','位置は整列済み。時計回り・反時計回りとも単位移動費用は同じ。'],
'scales':['六個の相異なる重さの硬貨の全順序を復元する。','合法質問は三個の最小・中央・最大、または別硬貨より重い中の最小（なければ三個の最小）。','返答を見る前の事前計算を許し、どの順序でも最悪質問回数を抑える。'],
'teams':['各学生はチーム人数の閉区間[A,B]を受け入れる。','一つのチーム人数kならk人が必要。一人は当日一回だけ使え、余ってもよい。','同じ学生集合に対して独立な日のチーム人数列を多数質問する。'],
'horses':['正の整数倍率Xで年ごとに所持数を増やし、各年の正の価格Yで任意個数を売れる。','倍率または価格の一点代入が累積し、各更新後の最大収入を法1e9+7で返す。','最大化する大小は剰余を取る前の巨大な整数。倍率1が多数続くこともある。'],
'sorting':['順列を直す任意二位置交換を一回ずつ行う。相手が先に行う交換列は事前に全て分かる。','初期状態と各round終了後に完成を判定し、同位置交換で何もしなくてもよい。','最小round数と、各roundの相手交換後に実行する自分の位置交換列が必要。'],
'towns':['正重みの隠れ木の葉だけに番号があり、二葉の距離だけを質問できる。','内部都市は次数3以上で、全葉への最遠距離を最小にする既存内点を探す。','そのhubを除いた全成分の葉数がN/2以下となるhubの有無も、ceil(7N/2)質問内で判定する。']}
gaps={
'boxes':('circular-capacity-delivery-one-full-turn-prefix-batches','容量付き円上配達を、左右のK個ずつの往復と高々一回の全周へ分ける','倉庫へ戻る容量制約と、全周tripを高々一回にする交換補題、左右prefix/suffixのK刻みDPがない。'),
'scales':('restricted-ternary-oracle-permutation-decision-tree','少数の全順列候補を、実行可能な三返答質問だけで深さ制限内に分ける','任意の部分集合質問や隣接変化回数ではなく、120個の硬貨質問に限定して深さ6の全分岐を実現する必要がある。'),
'teams':('interval-team-demand-persistent-count-bulk-greedy','人数の区間を持つ候補から、同じ人数だけを各チームへ一括して割り当てる','増加するチーム人数ごとの最小B優先の交換と、適格頻度−当日使用済み頻度を部分木単位で消費する再利用APIがない。'),
'horses':('bounded-price-prefix-product-saturated-candidate-updates','正の倍率と価格の一点変更後に、prefix積と末尾価格の積が最大の位置を求める','一般の結合的な集計は到達するが、倍率1の圧縮、価格上限による候補数の定数化、飽和積による正確比較とmod積の分離がない。'),
'sorting':('scheduled-position-swaps-commuting-value-swaps-minimum-rounds','既知の位置交換が毎回先に入る順列を、最少回数の自分の交換で直す','静的N−cycleの交換数だけでは相手の先行交換を織り込めない。値交換の可換性・round可否の単調性・位置への戻しが不足する。'),
'towns':('leaf-distance-hidden-hubs-projection-majority-queries','葉間距離だけから隠れた内点の最小半径と、葉数が均衡する成分分割を判定する','直径の質問部品はあるが、既存内点を表す射影座標と離散hub、offpath同成分の同値関係、予算内多数派検証がない。')}
api={
'boxes':{'entry':'delivery(N,K,L,positions)','calls':'one call','return':'minimum elapsed seconds after all deliveries and return to section0','positions':'nondecreasing,duplicate locations allowed,teams at0 allowed','cppHeaderBytesRetrieved':False,'exactCppSignatureConfirmed':False,'signatureEvidence':'abstract routine/parameter names in primary statement; original sample implementation/header not retrieved'},
'scales':{'entries':['init(T)','orderCoins()'],'callbacks':['getLightest(A,B,C)','getMedian(A,B,C)','getHeaviest(A,B,C)','getNextLightest(A,B,C,D)','answer(W)'],'protocol':'init once,orderCoins once per test; answer six labels light to heavy exactly once then return; query arguments distinct','cppHeaderBytesRetrieved':False,'exactCppSignatureConfirmed':False},
'teams':{'entries':['init(N,A,B)','can(M,K)'],'protocol':'init once,can once per independent day;1 feasible or0 impossible','cppHeaderBytesRetrieved':False,'exactCppSignatureConfirmed':False},
'horses':{'entries':['init(N,X,Y)','updateX(pos,val)','updateY(pos,val)'],'protocol':'one init and cumulative updates; every call returns optimum mod1000000007;positions zero-based','cppHeaderBytesRetrieved':False,'exactCppSignatureConfirmed':False},
'sorting':{'entry':'findSwapPairs(N,S,M,X,Y,P,Q)','protocol':'one call; return R;write first R entries P/Q in preallocated M arrays;indices may coincide;sorted initial R0','cppHeaderBytesRetrieved':False,'exactCppSignatureConfirmed':False},
'towns':{'entry':'hubDistance(N,sub)','callback':'getDistance(i,j)','protocol':'up to40 cases per run; fresh state every call;sub1/2 may return +/-R;sub3..6 +R iff balanced hub exists,otherwise -R;getDistance same or invalid args returns0','cppHeaderBytesRetrieved':False,'exactCppSignatureConfirmed':False}}
numeric={
'boxes':{'verified':False,'known':{'positionOrder':'nondecreasing','coordinates':'0..L-1','capacity':'positive K','scoreWeights':[10,10,15,15,20,30],'seconds':2,'memoryMB':1500},'unconfirmed':['N/K/L numeric maximums and every subtask bound omitted from accessible primary extraction. Values from memory or mirrors are not adopted.']},
'scales':{'verified':False,'known':{'coins':6,'distinctWeights':True,'permutationCandidates':720,'legalQueries':120,'minimumWorstCaseQueries':6,'queryLimitProvenance':'editorial six-weighing strategy plus independent exhaustive tree and information lower bound; primary scoring defines optimum abstractly','seconds':1,'memoryMB':1500,'subtasks':'none; score depends on worst query count per run'},'unconfirmed':['Primary init(T) integer range is omitted by PDF extraction.','Numerical partial-score formula in k/s/global runs is omitted; full-score6 is independently established,partial scores not reconstructed.']},
'teams':{'verified':True,'known':{'N':[1,500000],'Q':[1,200000],'sumM':200000,'A_B':'1<=A[i]<=B[i]<=N','M':'1<=M<=N','K':'1<=K[j]<=N','scoreWeights':[21,13,43,23],'subtasks':[{'N':100,'Q':100},{'N':100000,'Q':1},{'N':100000,'Q':100000,'sumM':100000},{'N':500000,'Q':200000,'sumM':200000}],'seconds':4,'memoryMB':1500},'unconfirmed':[]},
'horses':{'verified':True,'known':{'N':[1,500000],'updates':[0,100000],'initialAndUpdatedX_Y':[1,1000000000],'modulus':1000000007,'scoreWeights':[17,17,20,23,23],'subtasks':[{'N':10,'updates':0,'X_Ymax':10,'productXmax':1000},{'N':1000,'updates':1000},{'N':500000,'updates':100000,'minX':2},{'N':500000,'updates':10000},{'N':500000,'updates':100000}],'seconds':1.5,'memoryMB':1500},'unconfirmed':[]},
'sorting':{'verified':False,'known':{'permutation':'0..N-1','indices':'0..N-1,including self-swaps','solutionGuaranteedWithinM':True,'scoreWeights':[8,12,16,18,20,26],'subtasksRequiringMinimumR':[5,6],'seconds':1,'memoryMB':1500},'unconfirmed':['Exact N/M bounds and numerical upper limits on R in each subtask omitted from accessible primary extraction.','Subtasks1..3 extra numerical constraints on X/Y omitted; chosen method does not rely on them.']},
'towns':{'verified':True,'known':{'N':[6,110],'casesPerRunMax':40,'distinctLeafDistance':[1,1000000],'internalDegreeMin':3,'scoreWeights':[13,12,13,10,13,39],'queryLimits':['N(N-1)/2','ceil(7N/2)','N(N-1)/2','ceil(7N/2)','5N','ceil(7N/2)'],'balancedHubRequired':[False,False,True,True,True,True],'subtask4InternalDegree':3,'seconds':1,'memoryMB':1500},'unconfirmed':[]}}
numericurls={
'boxes':['https://ioi.te.lv/locations/ioi15/contest/day1/boxes/en-ISC.ISC.pdf','https://ioi.te.lv/locations/ioi15/contest/day1/notice/fa-IRN.IRN.pdf'],
'scales':['https://www2.ioi-jp.org/ioi/2015/tasks/scales-en.pdf','https://ioi.te.lv/locations/ioi15/contest/day1/notice/fa-IRN.IRN.pdf'],
'teams':['https://ioinformatics.org/files/ioi2015problem2.pdf','https://ioi.te.lv/locations/ioi15/contest/day1/teams/fa-IRN.IRN.pdf','https://ioi.te.lv/locations/ioi15/contest/day1/notice/fa-IRN.IRN.pdf'],
'horses':['https://ioi.te.lv/locations/ioi15/contest/day2/horses/sk-SK.SVK.pdf','https://www2.ioi-jp.org/ioi/2015/tasks/notice-day2-en.pdf'],
'sorting':['https://www2.ioi-jp.org/ioi/2015/tasks/sorting-en.pdf','https://ioi.te.lv/locations/ioi15/contest/day2/sorting/sk-SK.SVK.pdf','https://www2.ioi-jp.org/ioi/2015/tasks/notice-day2-en.pdf'],
'towns':['https://ioi.te.lv/locations/ioi15/contest/day2/towns/en-ISC.ISC.pdf','https://www2.ioi-jp.org/ioi/2015/tasks/notice-day2-en.pdf']}
numeric['boxes']={'verified':True,'known':{'N':[1,10000000],'KOverallUpper':10000000,'KRelation':'Subtask6 1<=K<=N;subtask5 separately allows1<=K<=3000 without an additional K<=N assumption','L':[1,1000000000],'positionOrder':'nondecreasing,duplicates and0 allowed','scoreWeights':[10,10,15,15,20,30],'subtasks':[{'N':[1,1000],'K':1,'L':[1,1000000000]},{'N':[1,1000],'K':'N','L':[1,1000000000]},{'N':[1,10],'K':'1..N','L':[1,1000000000]},{'N':[1,1000],'K':'1..N','L':[1,1000000000]},{'N':[1,1000000],'K':[1,3000],'L':[1,1000000000]},{'N':[1,10000000],'K':'1..N','L':[1,1000000000]}],'seconds':2,'memoryMB':1500},'unconfirmed':[]}
numericurls['boxes'] += ['https://ioi.te.lv/locations/ioi15/contest/day1/boxes/en-LKA.LKA.pdf']
numericurls['teams'] += ['https://ioi.te.lv/locations/ioi15/contest/day1/teams/en-LKA.LKA.pdf','https://ioi.te.lv/locations/ioi15/contest/day1/teams/en-VEN.VEN.pdf']
numericurls['horses'] += ['https://ioi.te.lv/locations/ioi15/contest/day2/horses/en-LVA.LVA.pdf']
api['teams'].update(exactCppSignatureConfirmed=True,printedCppSignatures=['void init(int N,int A[],int B[]);','int can(int M,int K[]);'],signatureEvidenceUrl='https://ioi.te.lv/locations/ioi15/contest/day1/teams/en-VEN.VEN.pdf',signatureEvidence='Printed primary C/C++ program signature,not actual retrieved header bytes.')
methods={
'boxes':{'method':'K個ずつのprefix/suffix往復DPと、高々一回の連続K個全周tripの全境界走査。','proof':[
'各補充点0間のtripを考える。同じ向きに同じ辺を二度通る閉歩行は訪問集合を保って短縮でき、最短は片側往復または全周一回。片側の端点が半周を超えれば全周へ替えて短縮する。',
'半周ごとに全周担当を倉庫から遠い側へ移す交換は往復距離を増やさない。片側往復は最遠K個を同じtripに集めても増えないため、全tripの配達集合を座標順の連続blockへ揃えられる。',
'連続block分割で半周境界を跨ぐblockは高々一個。他の全周blockは同じ担当集合を片側往復へ変更して全周以下の費用にできる。残る全周blockは他のtripから補ってmin(K,N)個を満たしてよい。',
'昇順pについて A[i]=A[max(0,i-K)]+2p[i-1]、B[i]=B[min(N,i+K)]+2(L-p[i])。全境界iでA[i]+B[i]およびA[i]+L+B[min(N,i+K)]の最小を取る。二式は全て合法な配達を表し、変形後最適解を含む。'],
'complexity':'整列済み入力でO(N)時間/O(N)空間。64bitや最大実行の具体的API検証は原典N/K/L数値が未確認のため未完。','officialEditorialVerified':True,'unreviewedAlternatives':['公式末尾のO(K)境界候補を各O(N/K)で評価するメモリ節約別実装は完成APIとして未検証。']},
'scales':{'method':'720順列と120合法質問の3分割を前計算し、残りdepth dなら各返答候補数<=3^(d-1)を必要条件として分枝限定し、6深さの完全決定木を生成。','proof':[
'三硬貨集合は20通り。min/median/maxで60質問、残り三個から別Dを選ぶnextLightestで60質問、計120。ABC内の引数順では質問結果集合が変わらず、これで合法質問を尽くす。',
'各queryの返答はABCのいずれか。各順列のrankを直接計算して3つの互いに素な候補bitsetを作る。深さdの決定木が持てる葉は高々3^dなので、その上限を超える子を持つqueryは棄却してよい。',
'探索は残る全合法質問を検討し、各非空返答子について再帰解があるものだけ採用する。全720順列で葉がその順列一つとなり深さ6であることを直接照合した。生成木のhashも保存する。',
'3^5=243<720の情報量下界と、実在する深さ6木から最悪6が最適。確率的平均や違法な任意部分集合質問へ置き換えない。'],
'complexity':'候補720/質問120/depth6は定数。採用生成器の1369状態は実測であり探索worst-caseの多項式保証ではない。生成木を事前固定すれば一case6callback。T最大/partial-score式/実grader適合は未確認。','officialEditorialVerified':True,'unreviewedAlternatives':['最適6問以外の部分点採点式とmanual hardcoded treeは未検証。']},
'teams':{'method':'チーム人数を昇順にし、現在適格な学生から上限Bの小さいk人を選ぶ。A閾値ごとの永続B頻度と、当日使用済みの別永続頻度の差を、部分木ごと一括消費する独立実装方針。','proof':[
'現在人数kの適格者uを最小B順に選ぶ。別最適割当がvを選びuを後のk′>=kへ置くなら交換できる。vはA_v<=k<=k′かつB_v>=B_u>=k′。uが未使用なら単に置換。よって先に小Bを使う選択は後を妨げない。',
'A<=kを満たす全学生のB頻度root[k]を一点加算のpath copyingで保存。当日usedは0から始め、kの増加に伴いroot[k]は点ごと非減少なのでeligible-usedは常に非負。B<kは対象外である。',
'eligible-usedを小B側から必要人数だけ消費する。完全消費する部分木では、新usedをeligibleの既存nodeそのものへ置き換える。これはused+(eligible-used)=eligibleであり、他の版を書き換えない。葉で一部だけ消費するときは個数を増やす。',
'消費対象はBの区間[k,last]とlast葉の一部なので、再帰が細分化するのは閾値と最後の選択位置の高々二本の境界だけ。全被覆部分木は共有で停止するため、一teamにO(log N)node訪問/新規nodeで済む。毎日usedを0へ戻して独立性を保つ。'],
'complexity':'前処理O(NlogN)、一queryの人数列整列O(MlogM)+一括消費O(MlogN)、前処理node O(NlogN)+当日O(MlogN)空間。全席/学生をqueryごとに列挙しない。','officialEditorialVerified':False,'unreviewedAlternatives':['公式前半のpersistent二次元greedyと交換の核は確認。末尾Hall DP/一交差/イベント＋fractional cascadingの別満点手順を、本独立bulk方式の証明へ読み替えない。']},
'horses':{'method':'一年度に全頭売る最適性、X=1 runの最大Yへの圧縮、最後の高々30個X>1とrun代表だけの候補化。比較には上限1e9+1の飽和積、出力にはmod積を別保存。','proof':[
'一年の各馬は同じ倍率・価格を受け、売る/残すの最適継続価値は一頭ごと線形。逆向きDP F_i=max(Y_i,X_{i+1}F_{i+1})より、初期一頭の最大収入はmax_i(Y_i*prod_{j<=i}X_j)。全頭を同一最適年に売る整数行動で上界を達成する。',
'X>1が30個ある区間の倍率積は2^30>1e9。そこより前の候補は、後側の任意正価格>=1に厳密に負ける。従って最後30個の非単位倍率より前を落としてよい。非単位倍率間のX=1 runはprefix積が等しいので最大Yだけを残す。',
'i<jの比較はY_iと(prod_{i<h<=j}X_h)*Y_jだけでよい。積が1e9を超えた場合は後者が常に大きいため、倍率積を1e9+1で飽和しても大小判定は変わらない。最終交差積は<=1000000001*1000000000でsigned64bit内。',
'非単位位置ordered set、最大YのRMQ、mod積/飽和積のセグメント木でpoint updateを反映する。run内代表の位置を保持し、比較を終えてからprefix mod積*Yを返す。巨大収入そのものを浮動小数点やmodで比較しない。'],
'complexity':'O(N)またはset構築込みO(NlogN)前処理、1更新O(log(1e9)logN)、O(N)空間の方針。prototypeは配列走査/任意精度整数を使い、上記更新API/時間上限の実証ではない。','officialEditorialVerified':True,'unreviewedAlternatives':['浮動小数点log比較法は採用せず、その誤差も確認していない。']},
'sorting':{'method':'相手の位置swap prefix t後の順列についてN-cyclecount<=tか判定し、単調性で最小tを二分探索。最後に値swap列を作り、実際の各roundで現在位置へ変換して実行する。','proof':[
'位置の置換を作用させる操作と、値ラベルの置換を作用させる操作は可換。よって自分の交換を値swapとして表せば、t回分の相手位置swapを先に行う仮想状態へ移してよい。',
'仮想状態の最小任意交換数はN−サイクル数。これがt以下なら余りは同位置swapで埋められ、逆にt回以下の自分swapで完成するならその距離以下である。',
'tで可なら次roundは相手と同じ位置対を自分もswapして完成状態を保てる。したがって判定は単調。N−1回あれば任意の仮想順列を直せるため、上界min(M,N−1)で十分（原典はM内の解を保証）。',
'仮想最終配列を固定する値swap列を保存し、実際には毎round相手位置swapを実行した後、その二値の現在位置を逆配列から取得してswapする。可換性により同じ最終値置換が施される。初期整列は0roundで直ちに停止する。'],
'complexity':'全入力読み込みを含めO(M+NlogN)時間/O(N+M)保持、prefixを外部arrayとして参照すれば補助O(N)。原典N/M数値・完成C++/witness最大実行は未確認。','officialEditorialVerified':True,'unreviewedAlternatives':['公式コメントの動的cycleをBBSTで更新する別手順は未検証。']},
'towns':{'method':'二点からの全葉距離と射影座標で離散hub候補を得る。左右成分を先に人数で除き、offpathがN/2超の高々一候補だけにBoyer–Moore＋既知Equal group代表による重み検証を行う独立補完。','proof':[
'任意葉vから最遠葉s、sから最遠葉tを求めD=d(s,t)。対称既知距離を再利用し自己質問を省けば2N−3回。最遠葉は直径端点であり、連続中心はv−s経路にある。vの直径合流座標はsからD/2以上で、v−s上の座標cの離心率はmax(c,D−c)。',
'各葉uのv−sへの射影はc(u)=(d(s,u)+d(s,v)−d(v,u))/2。経路上の各内部都市は次数3以上なので経路外へ分かれる葉があり、射影の異なる値（両端葉0,d(v,s)を除く）が全ての候補内点を尽くす。max(c,D−c)最小の既存座標は高々二個。',
'c(u)<rと>rはhubの左右二成分。どちらかがN/2超なら追加質問なしで棄却。X={u:c(u)=r}内の二葉は、同じoffpath成分 iff d(s,x)+d(s,y)−d(x,y)>2r。Xの人数自体がN/2以下ならその候補はbalanced。異なるrのXは互いに素で、|X|>N/2は高々一候補だけ。',
'm=|X|についてBoyer–Mooreの残高0時候補設定R回、Equal E回、NotEqual U回ならm=R+E+U、最終残高f=R+E−U。異色一対の除去は厳密多数色を失わないため、f=0なら多数派なし、f>0なら元の多数派は最終候補色。',
'候補選定のEqual返答の辺だけで同色groupをunionする。各Equalは新要素をつなぎ、group数m−E。候補group以外の代表を一度ずつ候補と比較すれば同色人数をgroup重みで完全に集計できる。比較総数は(m−R)+(m−E−1)=(3m−f)/2−1<1.5m。global N/2超ならm/2超でもあるのでこれで足りる。',
'初期2N−3と、多くても一集合への<1.5m<=1.5N追加からceil(7N/2)以内。公式odd集合を任意dropする記述をそのまま正しいとは認定せず、独立のgroup検証証明で補う。'],
'complexity':'O(N)距離質問、cacheをmap/arrayで持つ研究版はO(N²)まで空間。候補抽出にsortを使えばO(NlogN)計算、group DSU O(N alphaN)。完成callback API/全source最大native検証は未実装。','officialEditorialVerified':False,'unreviewedAlternatives':['公式p2のodd-set任意discardの文字どおりの正当性は未確認。AABでAをdiscardして残りA/Bをcancelすると誤る。採用方式はこの解釈に依存しない。']}}

methods['boxes']['complexity']='整列済み入力でO(N)時間/O(N)空間。N<=1e7,L<=1e9から各往復DP中間は2NL<=2e16、最終和も2NL+L以内でsigned64bitに収まる。完成API/最大原典native実行は未作成。'
graphs=json.loads((B/'data/flows.json').read_text());graphby={g['id']:g for g in graphs};roots=runtime['entryDomainIds']
base_reasons={
'ranges':'配列の選択・区間集計・更新が中心の入口。', 'dp':'状態の段階推移を問う入口だが、入出力の特徴そのものとは限らない。',
'graphs':'明示されたネットワークの経路/接続が中心。隠れ距離callbackの予算とは別に扱う。','flow-matching':'候補を互いに重ならず割り当てる特徴に適合する。',
'strings':'文字列比較/出現/変換が主目的ではない。','math':'算術部品があっても、原典の操作や観測を直接表す入口を優先する。',
'geometry':'点の位置と移動距離を直接表す。','game-probability':'相手は勝敗目的の未知戦略ではなく、確定した入力/オラクルまたは既知列。',
'thinking':'一般的な思考道具へ到達しても、必要な具体技巧の対応とは数えない。','heuristic':'全域の厳密解/質問回数保証が必要で、近似改善の目的ではない。',
'condition-check':'特徴や条件の不明点の避難先。原典の確認済み構造を代用する主入口ではない。',
'set-operations':'集合を使う部品があっても、集合演算そのものが要求出力ではない。','interactive-oracles':'隠れ情報を合法な質問で取得する特徴に適合する。',
'grid-arrangements':'二次元セルの配置や領域の要求ではない。','fixed-output':'問題ごと入力/応答で答えが変わり、固定出力ではない。'}
relevance={'boxes':{'geometry':'円上の地点への移動と配達が入力の直接的特徴なので採用。','ranges':'整列座標prefixは解法後の部品。原典の円・容量・帰還をgeometryから先に辿る。','flow-matching':'teamsへ物を配るが一対一の相性ではなく移動/容量が費用。'},
'scales':{'interactive-oracles':'硬貨の順序が隠れ、三返答の合法callbackで復元するので採用。','ranges':'値そのものや配列の比較は入力されず、自由な比較や区間集計を選べない。'},
'teams':{'flow-matching':'一日一回の学生を各teamのk席へ割り当てる特徴なので採用。','ranges':'各学生の許容区間は候補側の属性で、配列区間の集計ではない。'},
'horses':{'ranges':'倍率/価格配列の一点代入を累積して全体最大値を返すため採用。','geometry':'時間順のprefixであり空間移動ではない。'},
'sorting':{'ranges':'順列の位置交換とその操作列を求めるため採用。','game-probability':'相手swap列は全て既知。敵対的未知応答ゲームではない。','interactive-oracles':'質問callbackではなく相手swap列が初めに入力される。'},
'towns':{'interactive-oracles':'隠れた木の辺や内部都市を読めず、葉間距離callbackに厳しい上限があるため採用。','graphs':'木の数学は使うが、明示全辺/全頂点を読む記事の条件へyesとは答えない。'}}
assessments={}
for task in ids:
 assessments[task]=[]
 for root in roots:
  g=graphby[root];node=next(n for n in g['nodes'] if n['id']==g['root'])
  assessments[task].append({'entryGraphId':root,'rootNodeId':node['id'],'rootQuestion':node['title'],'rootOptions':node.get('options',[]),'rootRawNodeSha256':hashlib.sha256(json.dumps(node,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'selectedCanonical':root==routes[task]['entryGraphId'],'assessment':relevance[task].get(root,base_reasons[root])})
save('root-assessments',assessments)
records=[]
for selected in selection['records']:
 task=selected['officialTaskId'];route=routes[task];gapid,gaptitle,reason=gaps[task];m=methods[task];nu=numeric[task]
 branch=route['reached']
 if task=='horses':
  g=graphby['range-point-value-goals'];n=next(n for n in g['nodes'] if n['id']=='point-set-goal');branch={'graphId':g['id'],'nodeId':n['id'],'question':n['title'],'currentOptions':n['options']}
 if task in ['scales','towns','sorting']:
  gid,nid=('range-sequence-changes','updates') if task=='sorting' else ('interactive-oracles','response')
  g=graphby[gid];n=next(n for n in g['nodes'] if n['id']==nid)
  branch={'graphId':gid,'nodeId':nid,'question':n['title'],'currentOptions':n.get('options',[]),'policy':'append one feature answer;preserve all existing answer targets,options order and old paths'}
 entry={'source':'IOI',**{k:v for k,v in selected.items() if k!='source'},'contest':'IOI 2015','editorialUrl':f'https://ioi.te.lv/locations/ioi15/contest/solutions/{task}.pdf','hostStatementUrl':f'https://ioi.te.lv/locations/ioi15/contest/day{selected["day"]}/{task}/en-ISC.ISC.pdf','cutoffVerification':'Official 2015 primary distribution and official editorial predate cutoff; retrieval crawl dates are not publication dates.','features':features[task],
 'constraints':{'api':api[task],'numeric':nu['known'],'numericBoundsVerified':nu['verified'],'unconfirmedSourceNumericDetails':nu['unconfirmed'],'sourceEvidenceUrls':numericurls[task]},
 'reviewStatus':'verified','verification':'independent-analysis','classification':'missing-technique','auditOutcome':'missing-technique','entryGraphId':route['entryGraphId'],'choices':route['choices'],'steps':route['steps'],'expectedTechniqueIds':[],'actualReachedTechniqueIds':route['reached']['techniques'],'initialReached':route['reached'],'originalRootReached':route['reached'],'originalRootReachedTechniqueIds':route['reached']['techniques'],'canonicalRouteEnd':route['reached'],'researchSolutionConfirmed':True,'completedApiCoverage':False,
 'gap':{'id':gapid,'title':gaptitle,'features':features[task],'firstMissingGraphId':route['reached']['graphId'],'firstMissingNodeId':route['reached']['nodeId'],'stopNodeType':route['reached']['type'],'currentQuestion':route['reached']['title'],'currentOptions':route['reached']['options'],'reason':reason,'neededTechniqueIds':[gapid],'implementationNeeded':True,'existingRelatedTechniqueIds':related[task],'proposedFeatureAnswer':gaptitle,'proposedBranchAt':branch},
 'technicalFindings':{'verification':'independent-analysis','chosenFullSolutionVerified':True,'method':m['method'],'complexity':m['complexity'],'independentProofSupplement':m['proof'],'sourceUrls':[selected['statementUrl'],f'https://ioi.te.lv/locations/ioi15/contest/solutions/{task}.pdf',*numericurls[task]],'editorialProvenance':{'officialArchiveIndex':'https://ioi.te.lv/locations/ioi15/contest/index.shtml','linkedEditorialUrl':f'https://ioi.te.lv/locations/ioi15/contest/solutions/{task}.pdf','retrieval':'primary PDF text or indexed primary PDF full text; PDF images and original model source bytes not claimed','chosenMethodIndependentDetails':task in ['teams','towns'],'allOptionalEditorialMethodsVerified':False},'fullImplementationValidated':False,'unconfirmedRequiredLemmas':[],'unconfirmedSourceNumericDetails':nu['unconfirmed'],'unreviewedAlternativeDetails':m['unreviewedAlternatives'],'remainingImplementationValidation':['自然な日本語の具体技巧記事と常時可視完全C++20/API・原典callback adapterを作る。','実fenceをliteral oracle/元最大/不正/再入/通常ASanと別peerで検証する。','未取得の原典headerと未読の数値欄は推測せず、実装前に必要箇所を一次資料で補う。'],'probeEvidence':probe[task]},
 'materialStatus':{'statement':'retrieved-and-reviewed','statementVerified':True,'fullOriginalNumericContractVerified':nu['verified'],'officialEditorialRetrieved':True,'officialEditorialVerified':m['officialEditorialVerified'],'officialEditorial':'retrieved-and-reviewed-selected-core-with-independent-supplements','solution':'retrieved-and-reviewed','numericBounds':'verified-primary' if nu['verified'] else 'partially-unconfirmed-primary-formulas-missing','visualDetails':'not-claimed'},
 'collectionStatus':'statement-and-independent-analysis-verified','techniqueMappingStatus':'not-registered-until-article-flow-and-independent-validation','reviewedAt':'2026-10-15',
 'relatedArticleReview':[{'techniqueId':i,'file':by[i]['articlePath'],'sha256':by[i]['articleSha256'],'cppFenceSha256':by[i]['combinedCppSha256'],'cppFences':by[i]['cppFences'],'fullArticleAndAllCodeRead':True,'originalFullRangeApiReusable':False,'nativeCheckKind':'actual frozen fence own-component check,not full-source solver','fullImplementationRevalidatedForOriginal':False,'title':by[i]['metadata']['row']['title'],'scopeMismatch':by[i]['verifiedScopeDifference'],'componentCheck':by[i]['componentCheck'],'metadataSourceFiles':[{'file':by[i]['metadata']['path'],'sha256':by[i]['metadata']['fileSha256']}]} for i in related[task]],
 'navigationReplay':{'runtime':'independent raw JSON walker versus frozen actual flow.ts using separately frozen vendor compiler','stepsSha256':route['stepsSha256'],'stepsSha256Encoding':'UTF-8 canonical sorted-key compact JSON','choicesConsumed':len(route['choices']),'graphDataSha256':manifest['primaryFiles']['data/flows.json'],'routeBoundaries':route['routeBoundaries'],'all15EntryDomainsConsidered':roots,'all15RootAssessmentFile':'/tmp/flowchartcp-ioi2015-root-assessments.json','originalReferenceAlreadyRegistered':False},
 'verificationNotes':['初回の確認済み研究、未読数値、実装未作成を別欄へ保存する。一般記事到達を対応済みに数えない。','Python研究prototypeと近接記事のcomponent compileは、原典全域C++/API/ASan検証ではない。','初回recordへ将来の完成証拠を遡及せず、実記事とflowが完成した後にresolutionだけ追加する。']}
 entry['technicalFindings']['principalMathematicsConfirmed']=True
 if not nu['verified']:
  entry['reviewStatus']='unconfirmed'
  entry['classification']='unconfirmed'
  entry['auditOutcome']='unconfirmed'
  entry['researchSolutionConfirmed']=False
  entry['collectionStatus']='statement-reviewed-full-source-range-unconfirmed'
  entry['materialStatus']['solution']='principal-mathematics-reviewed-source-range-unconfirmed'
  entry['technicalFindings']['chosenFullSolutionVerified']=False
  entry['technicalFindings']['fullSourceCoverageGate']='Primary numeric/score contract remains unconfirmed; a successful finite mathematical model is not a positive original-full-range solution review.'
  entry['verificationNotes'].append('主要数学と小prototypeは確認できたが、原典の未読数値/採点契約を埋めないため、初回研究positiveには加算しない。')
 records.append(entry)
audit={'schemaVersion':1,'corpusId':'ioi-2015','title':'IOI2015 本競技全6題の固定初回監査','cutoff':'2026-10-14','auditedAt':'2026-10-15','selection':selection,'snapshot':manifest,'dependencyExtension':vendor,'records':records,
'status':{'fixedProblemListComplete':True,'firstPassAuditComplete':True,'fixedCorpusResearchComplete':True,'fixedCorpusResearchCompleteDefinition':'六題の選定した主要解法・必須補題を独立に確認した状態。二題に残る原典数値欄、全別解、完成API/記事/原典最大実行まで確認した意味ではない。','fixedCorpusPrimaryNumericCollectionComplete':False,'fixedCorpusCoverageComplete':False,'globalCoverageComplete':False,'globalLearningComplete':False,'recordCount':6,'statementVerifiedCount':6,'numericBoundsVerifiedCount':3,'numericBoundsUnconfirmedCount':3,'officialEditorialRetrievedCount':6,'officialEditorialVerifiedCount':4,'solutionReviewedCount':6,'coveredCount':0,'missingRouteCount':0,'missingTechniqueCount':6,'unconfirmedCount':0,'unconfirmedPrincipalDetailsCount':0,'unconfirmedSourceNumericRecordCount':3,'unavailableCount':0,'fullImplementationValidatedCount':0,'articleResolutionComplete':False,'articleResolutionNotes':'研究6/6、完成API/記事/原典flow/coverage0/6。未読数値3/6と原典header未取得6/6は独立に保持する。'},
'classificationDefinitions':{'missing-technique':'原典の主要手順が確認でき、現具体記事/原典全域API/特徴flowが足りない。数値欄の未確認は別に保存。','unconfirmed':'選定した必須補題または主要解法を確認できない場合。','covered':'完全な原典全域技巧記事/API/比較検証/特徴経路と実target証拠がある場合のみ。'},
'materials':{'officialTaskIndex':selection['primaryListUrl'],'officialIoiYearPage':selection['secondaryOfficialListUrl'],'officialDistributionIndex':'https://ioi.te.lv/locations/ioi15/contest/index.shtml','notices':['https://ioi.te.lv/locations/ioi15/contest/day1/notice/fa-IRN.IRN.pdf','https://www2.ioi-jp.org/ioi/2015/tasks/notice-day2-en.pdf'],'pdfImagesRead':False,'actualOriginalCppHeaderBytesRetrieved':False,'retrievalFailuresNotFilledFromMemory':True,'teamsFallbackPrimary':'https://ioinformatics.org/files/ioi2015problem2.pdf'},
'limits':['Sortingの数値表とScalesのT範囲/partial-score式は原典PDF抽出欠落。最大値を推測しない。','Towns公式odd-set discardの未確認を、独立のBoyer–Moore/Equal-group補完へ読み替えない。','二題のsource numeric完全収集、六題の全別解/全実装、世界全体の学習完了は主張しない。'],
'validation':{'rawReplayScript':'/tmp/flowchartcp-ioi2015-replay.py','rawRoutes':'/tmp/flowchartcp-ioi2015-routes.json','runtimeReplayScript':'/tmp/flowchartcp-ioi2015-runtime-replay.mjs','runtimeReplayResults':'/tmp/flowchartcp-ioi2015-runtime-replay.json','rootAssessments':'/tmp/flowchartcp-ioi2015-root-assessments.json','probeScript':'/tmp/flowchartcp-ioi2015-probe.py','probeResults':'/tmp/flowchartcp-ioi2015-probe.json','scopeScript':'/tmp/flowchartcp-ioi2015-scope-checks.py','scopeResults':'/tmp/flowchartcp-ioi2015-scope-checks.json','frozenValidator':{'command':'node scripts/validate.mjs','cwd':str(B),'exitCode':0,'summary':'Validated511techniques532mappings478diagrams3739nodes25sourceledgers.No files changed.'},'runtime':runtime,'prototypeIsProductionApi':False},
'preservation':{'allInitialRawAndAllFullMdxRetained':True,'allOldAuditsRetained':True,'rawBeforeCopyAfterAllEqual':True,'initialRecordProjectionPolicy':'Never rewrite initial six records/status/selection/snapshot;append genuine subsequent review/resolution only.','sharedFilesModified':False,'vendorSeparateEpoch':True}}
audit['status'].update(fixedCorpusResearchComplete=False,fixedCorpusResearchCompleteDefinition='全6題の原典範囲を含む主要手順が確認されて初めてtrue。現時点は主要数学prototype6/6、原典numeric確認を通った研究4/6。',numericBoundsVerifiedCount=4,numericBoundsUnconfirmedCount=2,solutionReviewedCount=4,missingTechniqueCount=4,unconfirmedCount=2,unconfirmedSourceNumericRecordCount=2,principalMathematicsConfirmedCount=6,successfulPrototypeCount=6,articleResolutionNotes='原典範囲を確認済みの研究4/6、未確認2/6、完成API/記事/原典flow/coverage0/6。未読数値をprototype成功から昇格しない。')
save('audit',audit)
proposal={'corpusId':'ioi-2015','sharedEditsPerformed':False,'fixedBeforeTechniqueSearch':True,'selectionSha256':sha(P/'flowchartcp-ioi2015-selection.json'),'auditFile':'data/corpus-audits/ioi-2015.json','expectedProblems':6,'fixedProblems':[{'source':'IOI','problemId':r['problemId'],'title':r['englishTitle'],'date':r['date'],'datePrecision':'day','difficulty':None} for r in records],'initialResearch':6,'initialCompleteApi':0,'initialCoverage':0,'unconfirmedNumericRecords':['ioi2015_scales','ioi2015_sorting'],'newKnownGaps':[{'id':r['gap']['id'],'features':r['features'],'problemId':r['problemId'],'proposedBranchAt':r['gap']['proposedBranchAt'],'proposedFeatureAnswer':r['gap']['proposedFeatureAnswer'],'guards':({'boxes':['単一倉庫と対称円周移動で補充は倉庫だけか','容量と重複を含む全配達後に倉庫へ戻るか','原典N/K/Lを一次確認して計算量と整数範囲に収まるか'],'scales':['相異なる六硬貨で全順序を特定するか','min/median/maxと別硬貨のnextLightestだけが合法か','全順列6問/原典Tとcall順を保証できるか'],'teams':['各候補の適格条件は人数の閉区間だけか','一日内で再利用禁止/日ごとの使用はリセットか','N50万/Q20万/sumM20万の範囲か'],'horses':['全倍率と価格は1..1e9の正整数か','一点代入が累積し最大収入はmod前の大小か','N50万/更新10万に収まるか'],'sorting':['相手の全位置交換列が既知で毎回先行するか','自分は任意位置swap/selfswap可で最小roundと操作列を求めるか','原典N/Mとintegerを一次確認しwithinM保証があるか'],'towns':['葉距離の正重み木で未知内点は次数3以上か','最小radiusの既存内点とleaf成分balanceを求めるか','N6..110/ceil3.5N質問/40call状態分離を保証できるか']}[r['officialTaskId']]),'negativeOrUnknown':'condition-check','articleMustBeGeneralTechnique':True} for r in records],
'retention':{'required':'Keep all1468 initialraw/all511MDX and separate105vendor in deterministic archive with original ledger before/after and fullhashes;manifest-only retention is insufficient.','frozenPaths':str(B),'futureNormalizedScripts':'Use fresh temp restoration,verify every raw SHA each time,stdout JSON by default,output file only explicit argument. Preserve math/route/counter semantics.','recommendedFixedSuite':['initial six identity/status/projection SHA,selection-before-search proof','all1468raw+all511MDX+10audit restore hashes,105vendor separateepoch','all15root nodes/full labels and six canonical traces versus frozen actualruntime','all532walk full records/steps/terminals and no original shared changes','all19near fullMDX/CPP/meta hashes and actual component preflight','six smallmath prototype results with timing excluded;no productionAPI/ASan reinterpretation','genuine laterresolution allowed,initial records never rewritten']},'sourceDatePrecision':'day','difficulty':None,'globalLearningComplete':False,'publicationCommitPushPerformed':False}
proposal['initialResearch']=4
proposal['initialUnconfirmed']=2
proposal['successfulMathematicalPrototypes']=6
proposal['unconfirmedTechniqueCandidates']=[r for r in proposal['newKnownGaps'] if r['problemId'] in ['ioi2015_scales','ioi2015_sorting']]
proposal['newKnownGaps']=[r for r in proposal['newKnownGaps'] if r['problemId'] not in ['ioi2015_scales','ioi2015_sorting']]
save('registration-proposal',proposal)
town_peer=P/'flowchartcp-ioi2015-towns-peer-review.json'
snapshot_peer=P/'flowchartcp-ioi2015-snapshot-peer-review.json'
audit['independentSubreviews']=[{'scope':'initial selection/snapshot/raw/runtime only;not full audit','path':str(snapshot_peer),'sha256':sha(snapshot_peer),'fullAuditPeerComplete':False},{'scope':'Towns primary bounds and independent majority/geometry supplements only;not full audit','path':str(town_peer),'sha256':sha(town_peer),'fullAuditPeerComplete':False}]
audit['records'][-1]['technicalFindings']['independentPeerSupplement']={'review':str(town_peer),'reviewSha256':sha(town_peer),'probe':'/tmp/flowchartcp-ioi2015-towns-peer-probe.py','results':'/tmp/flowchartcp-ioi2015-towns-peer-results.json','checks':4959568,'checksum':'10829276836059346714','officialOddDiscardVerified':False}
save('audit',audit)
lines=['# IOI2015 本競技6題の固定初回監査','',
'初回は研究4/6、未確認2/6、完成API0/6、記事・経路対応0/6。六つの小数学prototypeは成功したが、Scales・Sortingの原典数値/採点欄が読めていないため、この二題を原典全域の研究positiveへ昇格しない。Boxes・Teams・Horses・Townsは数値と選定した主要手順を一次資料と独立証明で確認した。全別解や世界全体の網羅を完了した意味ではない。','',
'## 母集団と凍結','',
'[日本委員会の本番課題一覧](https://www2.ioi-jp.org/ioi/2015/tasks/index.html)と[IOI公式年別一覧](https://ioinformatics.org/page/ioi-2015/41)から、本競技の六identityと日付を技巧検索より先に固定した。practiceは除く。IOI公式年ページのPDFリンク順はJPの日内順と異なり、problem2.pdfはTeams、problem3.pdfはBoxesであるため、PDF番号から日内順を推測しない。','',
'|日付|task ID|英題|日本語題|初回分類|','|---|---|---|---|---|']
for r in records:lines.append(f'|{r["date"]}|{r["officialTaskId"]}|{r["englishTitle"]}|{r["title"]}|{r["classification"]}|')
lines+=['',f'選定SHA `{sha(P/"flowchartcp-ioi2015-selection.json")}`。`semanticTechniqueSearchStarted:false`は選定時点の状態を保存する欄であり、現在の調査進行に合わせて書き換えない。',
'',f'初回epochは511 full MDX /511 metadata /532 references /478 graphs /3739 nodes /532 walks /10 old audits、raw1468 files（public479、その他989）。manifest SHA `{sha(P/"flowchartcp-ioi2015-manifest.json")}`、SHA256SUMS SHA `{manifest["ledgerSha256"]}`。before/copy/after全1468件が同一で、全MDX実bytes・全既存audit・SVG・validator・runtimeを保存した。後のPaint等登録はこのepochへ遡及しない。',
'',f'vendor105ファイルは別epochでbefore/copy/after一致、manifest SHA `{sha(P/"flowchartcp-ioi2015-vendor-manifest.json")}`。初回1468へ混ぜない。凍結先は `/tmp/flowchartcp-ioi2015-baseline`。manifestだけの保存ではなく、全ファイル実物が存在する。','',
'## 原典・APIと未読欄','',
'[公式配布archive](https://ioi.te.lv/locations/ioi15/contest/index.shtml)の実リンクから六つのEditorialへ到達した。Scales/Horsesはdirect openが失敗する場合も、実URLを対象にした検索のprimary PDF本文を読めた。本文中に数式が欠落した部分は、第三者の数値・記憶・検索語に埋め込んだ推定値では補わない。原典PDF画像は取得できたと主張せず、actual C++ sample/header bytesも六題とも未取得である。Noticeはsample implementationの正しい署名を使う契約であり、abstract API名・引数・呼出順を確認し、Teamsだけは追加の公式VEN配布本文で印字されたC/C++署名も読めた（actual header bytesとは別）。','',
'Day1の[公式IRN Notice](https://ioi.te.lv/locations/ioi15/contest/day1/notice/fa-IRN.IRN.pdf)のindexed本文からBoxes2秒/Scales1秒/Teams4秒、全1500MB。[Day2英語Notice](https://www2.ioi-jp.org/ioi/2015/tasks/notice-day2-en.pdf)からHorses1.5秒/Sorting1秒/Towns1秒、全1500MB。標準入出力・ファイルI/Oは禁止、指定routineでgraderと連携する。','',
'TeamsはJP hostの英語PDFがcache missでも、公式年別一覧の実Teamsリンクから[公式IOI PDF](https://ioinformatics.org/files/ioi2015problem2.pdf)2頁を読める。最大数値はIRNを指定した検索から実際に返された[公式LKA配布本文](https://ioi.te.lv/locations/ioi15/contest/day1/teams/en-LKA.LKA.pdf)のindexed本文で再確認した。検索指定URLと実際に返された根拠URLを混同しない。[VEN配布本文](https://ioi.te.lv/locations/ioi15/contest/day1/teams/en-VEN.VEN.pdf)にはC/C++署名もある。Horsesは[主催SVK訳](https://ioi.te.lv/locations/ioi15/contest/day2/horses/sk-SK.SVK.pdf)、Townsは[主催ISC本文](https://ioi.te.lv/locations/ioi15/contest/day2/towns/en-ISC.ISC.pdf)のindexed本文で欠ける数式を補った。','',
'成功した数値取得query例: `site:ioi.te.lv/locations/ioi15/contest/day1/teams/fa-IRN.IRN.pdf "500000"`（実際の結果URLはLKA）、`site:ioi.te.lv/locations/ioi15/contest/day2/horses/sk-SK.SVK.pdf "500000"`、`site:ioi.te.lv/locations/ioi15/contest/day2/towns/ "Subtasks"`。Townsのexact ISC URL+`Subtasks`検索は全6予算表も表示した。','',
'## 六題の数学・停止位置・具体不足','']
for r in records:
 task=r['officialTaskId'];m=methods[task];nu=numeric[task]
 lines += [f'### {r["englishTitle"]} ({task})','',f'[原典]({r["statementUrl"]}) / [公式Editorial]({r["editorialUrl"]})。初回 `{r["reviewStatus"]}`、原典numeric完全確認 `{nu["verified"]}`、完成API `false`。',
 '', '特徴: '+ ' / '.join(r['features']), '', 'API: `'+json.dumps(api[task],ensure_ascii=False)+'`。', '', '確認済み数値: `'+json.dumps(nu['known'],ensure_ascii=False)+'`。']
 if nu['unconfirmed']:lines+=['','未確認: '+' / '.join(nu['unconfirmed'])]
 lines += ['', '選定手順: '+m['method'],'']
 for i,proof in enumerate(m['proof'],1):lines.append(f'{i}. {proof}')
 lines += ['',m['complexity'],'','公式全別解の確認とは分ける: '+' / '.join(m['unreviewedAlternatives']),'',
 '初回実経路: `'+r['entryGraphId']+' → '+' → '.join(r['choices'])+'`。','']
 for step in r['steps']:lines.append(f'- `{step["graphId"]}/{step["nodeId"]}`「{step["question"]}」→ `{step["answer"]}`「{step["answerLabel"]}」。')
 lines += ['',f'到達 `{r["initialReached"]["graphId"]}/{r["initialReached"]["nodeId"]}`（{r["initialReached"]["type"]}）「{r["initialReached"]["title"]}」。到達技巧 `{r["actualReachedTechniqueIds"]}` は部品の到達であり、原典全域対応ではない。', '', '不足: '+r['gap']['reason'], '', '候補ID `'+r['gap']['id']+'`。特徴で選ぶ案: '+r['gap']['proposedFeatureAnswer']+'。guard案はregistration-proposal.jsonに保存し、否定/不明はcondition-checkへ戻す。','',
 '近接記事の全文・全C++・metadataを照合した範囲:','']
 for a in r['relatedArticleReview']:lines.append(f'- `{a["techniqueId"]}`: {a["scopeMismatch"]} 本文SHA `{a["sha256"]}`。')
 lines+=['','小研究probe（原典完成APIの検証ではない）: `'+json.dumps(probe[task],ensure_ascii=False)+'`。','']
lines += ['## 全15分野の比較と独立再生','',
'全六題それぞれについて15根のquestion・全選択肢・root node hashと採用/不採用理由を `root-assessments.json` に保存した。アルゴリズム名から後付けでrootを選ばず、入力の操作・観測を優先する。Horsesは「一点代入→集計→結合可能」を実際にyesへ辿り、generic segment-tree結果まで進めた上で、巨大積の正確比較と更新要約が不足すると判断した。途中に選べる正しいaggregate選択肢があるのに早く止めた記録にはしない。','',
'独立Python raw walkerは質問全文・回答label・target・route境界・到達node全fieldを保存する。別のJSは凍結src/lib/flow.tsを別epochのコンパイラで実compileし、六canonicalと532旧walkの2816回答について、raw steps/label/terminalの全fieldと一致させる。旧全record実bytes自体もledger固定である。`runtime-replay.json` に結果。凍結validatorは511/532/478/3739と25source ledgerを検査し成功、書換えなし。','',
'19近接MDXの各fenceをそのまま抽出して通常C++20 compile/runし、各記事の本来のcomponentの小例を確認した。原典ソルバへ組み替えたものではない。`scope-checks.json` は全MDX/CPP/metadataのhash、全component harnessとscope差を保持する。','',
'## 検査とcounterの意味','',
'`probe.py` はPython小規模研究モデルだけで、新しいC++20本体、原典callback adapter、最大原典native性能、ASanは作成/実行していない。87,395は保存rawの1468SHA比較を含むassertion数。各題のcase数はprobe.jsonへ別に記録し、Horsesの全売却historyケースと更新比較、Scalesの全順列と探索state数を混ぜない。Scales探索の1369state/計算時間は実測であり、探索木生成の一般多項式最悪上界ではない。','',
'Townsだけの別peer補助は `flowchartcp-ioi2015-towns-peer-review.json` とnotes/probe/resultsに保存。142418同値分割・712089閾値、38092 weighted tree、4959568 checksで一致し、source N6..110も独立確認した。この補助を全監査peer完了へ広げない。公式odd arbitrary discardの未確認を残したまま、別のEqual group多数派証明が全質問予算を満たすと確認した。','',
'snapshotだけの別peer補助は `flowchartcp-ioi2015-snapshot-peer-review.json`。1468raw、105vendor、15roots、532walkとactual runtimeを確認したが、六題のsource/nearby scope full peer完了とは呼ばない。最終audit全体は別peerの精査待ちである。','',
'## 再現入口と次の作業','',
'```sh\npython3 /tmp/flowchartcp-ioi2015-probe.py\npython3 /tmp/flowchartcp-ioi2015-scope-checks.py\npython3 /tmp/flowchartcp-ioi2015-replay.py\nnode /tmp/flowchartcp-ioi2015-runtime-replay.mjs\n```','',
'probeは現在tmp JSONを書き出す著者用である。恒久版へ移す際は元rawと元JSONを残し、fresh tempへ全rawを復元して毎回1468SHAを再照合し、既定stdout JSON、明示output引数時だけ結果を書き出す。意味・乱数seed・counterは変えない。全1468raw/全511MDXを決定的archiveで保持し、vendor105を別archiveに分けることを提案する。metadataやmanifestだけで代用しない。','',
'最終freeze前にpeerからの新primary LKA配布を著者も再確認でき、Boxesの全6数値表を解消した。N最大1e7/L最大1e9、subtask5のK<=3000をK<=Nへ狭めない。成功queryは `site:ioi.te.lv/locations/ioi15/contest/day1/boxes/en-LKA.LKA.pdf "Subtasks"`、実際の返却URLも同じである。優先followupはSorting数値表、Scales T範囲/partial-score式のprimary再取得。新しいsource候補がない同一cache/DNS失敗の反復を続けず、未確認の初回状態を残す。数値確認済み四題にも、一般技巧記事・完全API・原典最大・literal比較・invalid/reentrant・通常ASan・別peer・特徴分岐を新たに作る必要がある。初回六rowのpositive/unknown/全falseflag/stopを改変せず、後続の真正な証拠をsubsequent review/resolutionだけで追加する。','',
'日付はJP公式日別一覧で2015-07-28/2015-07-30を確認し、難度値は全題null。カットオフ2026-10-14、調査2026-10-15。共有article/data/flow/walk/audit/plan/sourceは本担当が一切編集していない。']
(P/'flowchartcp-ioi2015-notes.md').write_text('\n'.join(lines)+'\n')
artifacts=['selection.json','manifest.json','vendor-manifest.json','audit.json','notes.md','probe.py','probe.json','scope-checks.py','scope-checks.json','replay.py','routes.json','runtime-replay.mjs','runtime-replay.json','root-assessments.json','old-walk-traces.json','registration-proposal.json','build-audit.py']
sidecar={'corpusId':'ioi-2015','status':'frozen-initial-audit-awaiting-full-independent-review','sharedFilesModified':False,'fixedDenominator':6,'fixedBeforeTechniqueMatching':True,'originalTaskIds':ids,'initialCounts':manifest['rawCounts'],'initialRawEpoch':{'manifestSha256':sha(P/'flowchartcp-ioi2015-manifest.json'),'selectionSha256':sha(P/'flowchartcp-ioi2015-selection.json'),'ledgerSha256':manifest['ledgerSha256'],'all1468RawBytesRetained':True,'all511FullMdxRetained':True,'beforeCopiedAfterEqual':True},'laterDependencyEpoch':{'manifestSha256':sha(P/'flowchartcp-ioi2015-vendor-manifest.json'),'files':105,'beforeCopiedAfterEqual':True,'initialEpochUnchanged':True},'artifacts':{str(P/f'flowchartcp-ioi2015-{f}'):sha(P/f'flowchartcp-ioi2015-{f}') for f in artifacts},'stageCounts':{'statementsRead':6,'principalMathematicsConfirmed':6,'successfulSmallPythonPrototypes':6,'sourceNumericVerified':4,'sourceNumericUnconfirmed':2,'researchPositive':4,'unconfirmed':2,'confirmedMissingTechniques':4,'completeOriginalApi':0,'articleCoverage':0,'productionCppNewFences':0,'sourceMaximumNativeRuns':0,'asanRuns':0},'sourceGate':{'unconfirmedRecords':['ioi2015_scales','ioi2015_sorting'],'prototypeDoesNotMakeThesePositive':True,'allOriginalHeadersUnretrieved':True,'pdfImagesNotClaimedRead':True,'townsOfficialOddDiscardVerified':False,'townsChosenIndependentSupplementVerified':True},'independentSubreviews':audit['independentSubreviews'],'fullAuditPeerComplete':False,'manualCommands':['python3 /tmp/flowchartcp-ioi2015-probe.py','python3 /tmp/flowchartcp-ioi2015-scope-checks.py','python3 /tmp/flowchartcp-ioi2015-replay.py','node /tmp/flowchartcp-ioi2015-runtime-replay.mjs'],'probeResultSummary':{'assertions':probe['assertions'],'allSixSmallModelsPassed':True,'runtime':runtime,'nearest19ComponentsPassed':True,'productionApiClaimed':False},'oldCorporaPreservation':{k:v for k,v in manifest['fullRawHashes'].items() if k.startswith('data/corpus-audits/')},'retentionPlan':proposal['retention'],'globalLearningComplete':False,'globalCoverageComplete':False,'publishingCommitPushPerformed':False}
save('sidecar',sidecar)
print(json.dumps({'records':len(records),'research':4,'unconfirmed':2,'numericVerified':4,'coverage':0,'auditSha256':sha(P/'flowchartcp-ioi2015-audit.json'),'scopeArticles':19}))
