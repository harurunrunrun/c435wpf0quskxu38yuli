# IOI2015 本競技6題の固定初回監査

初回は研究4/6、未確認2/6、完成API0/6、記事・経路対応0/6。六つの小数学prototypeは成功したが、Scales・Sortingの原典数値/採点欄が読めていないため、この二題を原典全域の研究positiveへ昇格しない。Boxes・Teams・Horses・Townsは数値と選定した主要手順を一次資料と独立証明で確認した。全別解や世界全体の網羅を完了した意味ではない。

## 母集団と凍結

[日本委員会の本番課題一覧](https://www2.ioi-jp.org/ioi/2015/tasks/index.html)と[IOI公式年別一覧](https://ioinformatics.org/page/ioi-2015/41)から、本競技の六identityと日付を技巧検索より先に固定した。practiceは除く。IOI公式年ページのPDFリンク順はJPの日内順と異なり、problem2.pdfはTeams、problem3.pdfはBoxesであるため、PDF番号から日内順を推測しない。

|日付|task ID|英題|日本語題|初回分類|
|---|---|---|---|---|
|2015-07-28|boxes|Boxes with souvenirs|お土産の箱|missing-technique|
|2015-07-28|scales|Scales|秤|unconfirmed|
|2015-07-28|teams|Teams|チーム|missing-technique|
|2015-07-30|horses|Horses|馬|missing-technique|
|2015-07-30|sorting|Sorting|ソート|unconfirmed|
|2015-07-30|towns|Towns|町|missing-technique|

選定SHA `59b8335b6974a7158b85b67a69ab350d6a38aa80ddffaa8b917289c33b4cfe16`。`semanticTechniqueSearchStarted:false`は選定時点の状態を保存する欄であり、現在の調査進行に合わせて書き換えない。

初回epochは511 full MDX /511 metadata /532 references /478 graphs /3739 nodes /532 walks /10 old audits、raw1468 files（public479、その他989）。manifest SHA `0a91e9dc6ab00b503599d321b7ede775d1a6474acc304b1391786f8a89399fd0`、SHA256SUMS SHA `00425972dcc3f2e1a3cf6a9cf51e264c2be1e427116eb5f3192231d0939198a6`。before/copy/after全1468件が同一で、全MDX実bytes・全既存audit・SVG・validator・runtimeを保存した。後のPaint等登録はこのepochへ遡及しない。

vendor105ファイルは別epochでbefore/copy/after一致、manifest SHA `f32897da8cb4f6db938e85aa2ee721aa4ce00d97353bcc9f59a5904e8d05ca2f`。初回1468へ混ぜない。凍結先は `/tmp/flowchartcp-ioi2015-baseline`。manifestだけの保存ではなく、全ファイル実物が存在する。

## 原典・APIと未読欄

[公式配布archive](https://ioi.te.lv/locations/ioi15/contest/index.shtml)の実リンクから六つのEditorialへ到達した。Scales/Horsesはdirect openが失敗する場合も、実URLを対象にした検索のprimary PDF本文を読めた。本文中に数式が欠落した部分は、第三者の数値・記憶・検索語に埋め込んだ推定値では補わない。原典PDF画像は取得できたと主張せず、actual C++ sample/header bytesも六題とも未取得である。Noticeはsample implementationの正しい署名を使う契約であり、abstract API名・引数・呼出順を確認し、Teamsだけは追加の公式VEN配布本文で印字されたC/C++署名も読めた（actual header bytesとは別）。

Day1の[公式IRN Notice](https://ioi.te.lv/locations/ioi15/contest/day1/notice/fa-IRN.IRN.pdf)のindexed本文からBoxes2秒/Scales1秒/Teams4秒、全1500MB。[Day2英語Notice](https://www2.ioi-jp.org/ioi/2015/tasks/notice-day2-en.pdf)からHorses1.5秒/Sorting1秒/Towns1秒、全1500MB。標準入出力・ファイルI/Oは禁止、指定routineでgraderと連携する。

TeamsはJP hostの英語PDFがcache missでも、公式年別一覧の実Teamsリンクから[公式IOI PDF](https://ioinformatics.org/files/ioi2015problem2.pdf)2頁を読める。最大数値はIRNを指定した検索から実際に返された[公式LKA配布本文](https://ioi.te.lv/locations/ioi15/contest/day1/teams/en-LKA.LKA.pdf)のindexed本文で再確認した。検索指定URLと実際に返された根拠URLを混同しない。[VEN配布本文](https://ioi.te.lv/locations/ioi15/contest/day1/teams/en-VEN.VEN.pdf)にはC/C++署名もある。Horsesは[主催SVK訳](https://ioi.te.lv/locations/ioi15/contest/day2/horses/sk-SK.SVK.pdf)、Townsは[主催ISC本文](https://ioi.te.lv/locations/ioi15/contest/day2/towns/en-ISC.ISC.pdf)のindexed本文で欠ける数式を補った。

成功した数値取得query例: `site:ioi.te.lv/locations/ioi15/contest/day1/teams/fa-IRN.IRN.pdf "500000"`（実際の結果URLはLKA）、`site:ioi.te.lv/locations/ioi15/contest/day2/horses/sk-SK.SVK.pdf "500000"`、`site:ioi.te.lv/locations/ioi15/contest/day2/towns/ "Subtasks"`。Townsのexact ISC URL+`Subtasks`検索は全6予算表も表示した。

## 六題の数学・停止位置・具体不足

### Boxes with souvenirs (boxes)

[原典](https://www2.ioi-jp.org/ioi/2015/tasks/boxes-en.pdf) / [公式Editorial](https://ioi.te.lv/locations/ioi15/contest/solutions/boxes.pdf)。初回 `verified`、原典numeric完全確認 `True`、完成API `false`。

特徴: 円周上の各地点へ一個ずつ配達し、倉庫のある出発点へ最後に戻る。 / 一回に運べる個数Kが決まり、補充は出発点だけ。重複地点もある。 / 位置は整列済み。時計回り・反時計回りとも単位移動費用は同じ。

API: `{"entry": "delivery(N,K,L,positions)", "calls": "one call", "return": "minimum elapsed seconds after all deliveries and return to section0", "positions": "nondecreasing,duplicate locations allowed,teams at0 allowed", "cppHeaderBytesRetrieved": false, "exactCppSignatureConfirmed": false, "signatureEvidence": "abstract routine/parameter names in primary statement; original sample implementation/header not retrieved"}`。

確認済み数値: `{"N": [1, 10000000], "KOverallUpper": 10000000, "KRelation": "Subtask6 1<=K<=N;subtask5 separately allows1<=K<=3000 without an additional K<=N assumption", "L": [1, 1000000000], "positionOrder": "nondecreasing,duplicates and0 allowed", "scoreWeights": [10, 10, 15, 15, 20, 30], "subtasks": [{"N": [1, 1000], "K": 1, "L": [1, 1000000000]}, {"N": [1, 1000], "K": "N", "L": [1, 1000000000]}, {"N": [1, 10], "K": "1..N", "L": [1, 1000000000]}, {"N": [1, 1000], "K": "1..N", "L": [1, 1000000000]}, {"N": [1, 1000000], "K": [1, 3000], "L": [1, 1000000000]}, {"N": [1, 10000000], "K": "1..N", "L": [1, 1000000000]}], "seconds": 2, "memoryMB": 1500}`。

選定手順: K個ずつのprefix/suffix往復DPと、高々一回の連続K個全周tripの全境界走査。

1. 各補充点0間のtripを考える。同じ向きに同じ辺を二度通る閉歩行は訪問集合を保って短縮でき、最短は片側往復または全周一回。片側の端点が半周を超えれば全周へ替えて短縮する。
2. 半周ごとに全周担当を倉庫から遠い側へ移す交換は往復距離を増やさない。片側往復は最遠K個を同じtripに集めても増えないため、全tripの配達集合を座標順の連続blockへ揃えられる。
3. 連続block分割で半周境界を跨ぐblockは高々一個。他の全周blockは同じ担当集合を片側往復へ変更して全周以下の費用にできる。残る全周blockは他のtripから補ってmin(K,N)個を満たしてよい。
4. 昇順pについて A[i]=A[max(0,i-K)]+2p[i-1]、B[i]=B[min(N,i+K)]+2(L-p[i])。全境界iでA[i]+B[i]およびA[i]+L+B[min(N,i+K)]の最小を取る。二式は全て合法な配達を表し、変形後最適解を含む。

整列済み入力でO(N)時間/O(N)空間。N<=1e7,L<=1e9から各往復DP中間は2NL<=2e16、最終和も2NL+L以内でsigned64bitに収まる。完成API/最大原典native実行は未作成。

公式全別解の確認とは分ける: 公式末尾のO(K)境界候補を各O(N/K)で評価するメモリ節約別実装は完成APIとして未検証。

初回実経路: `geometry → travel-partition`。

- `geometry/geometry-task`「点や座標から何を求めますか？」→ `travel-partition`「移動・格子経路・長方形の切り分け」。

到達 `geometry-travel-partition/geometry-task`（question）「点や座標から何を求めますか？」。到達技巧 `[]` は部品の到達であり、原典全域対応ではない。

不足: 倉庫へ戻る容量制約と、全周tripを高々一回にする交換補題、左右prefix/suffixのK刻みDPがない。

候補ID `circular-capacity-delivery-one-full-turn-prefix-batches`。特徴で選ぶ案: 容量付き円上配達を、左右のK個ずつの往復と高々一回の全周へ分ける。guard案はregistration-proposal.jsonに保存し、否定/不明はcondition-checkへ戻す。

近接記事の全文・全C++・metadataを照合した範囲:

- `heuristic-precedence-two-opt`: 受取・配達の先行制約を保つ局所改善であり、積載K/円周/厳密最短の三種trip分解を持たない。 本文SHA `38fd7ceb398565203fb0f072c927bdd1bf55646b397c818219cdc614b34e60b0`。
- `median-window-budget`: 固定個数を中央値に集める線上距離和で、補充点に戻る容量Kの巡回とは目的も費用も違う。 本文SHA `1969038daf43271e85ad7d385c5b394ae6c1bec0e46b546d6523320f8c91a24a`。
- `optional-booster-subset-speed`: 任意加速点付き小集合巡回であり、指数時間・必須点12個のAPI。円上大量重複配送の全域を含まない。 本文SHA `c58e7630749bdc2b7ac5e14e1d451d500d99c3c37bb194d4ad58420a6524cdf0`。

小研究probe（原典完成APIの検証ではない）: `{"cases": 8982, "oracle": "unrestricted circle-walk BFS per trip, then mask partition DP", "maxTeams": 5, "maxCircleLength": 7, "seconds": 0.24907855001220014}`。

### Scales (scales)

[原典](https://www2.ioi-jp.org/ioi/2015/tasks/scales-en.pdf) / [公式Editorial](https://ioi.te.lv/locations/ioi15/contest/solutions/scales.pdf)。初回 `unconfirmed`、原典numeric完全確認 `False`、完成API `false`。

特徴: 六個の相異なる重さの硬貨の全順序を復元する。 / 合法質問は三個の最小・中央・最大、または別硬貨より重い中の最小（なければ三個の最小）。 / 返答を見る前の事前計算を許し、どの順序でも最悪質問回数を抑える。

API: `{"entries": ["init(T)", "orderCoins()"], "callbacks": ["getLightest(A,B,C)", "getMedian(A,B,C)", "getHeaviest(A,B,C)", "getNextLightest(A,B,C,D)", "answer(W)"], "protocol": "init once,orderCoins once per test; answer six labels light to heavy exactly once then return; query arguments distinct", "cppHeaderBytesRetrieved": false, "exactCppSignatureConfirmed": false}`。

確認済み数値: `{"coins": 6, "distinctWeights": true, "permutationCandidates": 720, "legalQueries": 120, "minimumWorstCaseQueries": 6, "queryLimitProvenance": "editorial six-weighing strategy plus independent exhaustive tree and information lower bound; primary scoring defines optimum abstractly", "seconds": 1, "memoryMB": 1500, "subtasks": "none; score depends on worst query count per run"}`。

未確認: Primary init(T) integer range is omitted by PDF extraction. / Numerical partial-score formula in k/s/global runs is omitted; full-score6 is independently established,partial scores not reconstructed.

選定手順: 720順列と120合法質問の3分割を前計算し、残りdepth dなら各返答候補数<=3^(d-1)を必要条件として分枝限定し、6深さの完全決定木を生成。

1. 三硬貨集合は20通り。min/median/maxで60質問、残り三個から別Dを選ぶnextLightestで60質問、計120。ABC内の引数順では質問結果集合が変わらず、これで合法質問を尽くす。
2. 各queryの返答はABCのいずれか。各順列のrankを直接計算して3つの互いに素な候補bitsetを作る。深さdの決定木が持てる葉は高々3^dなので、その上限を超える子を持つqueryは棄却してよい。
3. 探索は残る全合法質問を検討し、各非空返答子について再帰解があるものだけ採用する。全720順列で葉がその順列一つとなり深さ6であることを直接照合した。生成木のhashも保存する。
4. 3^5=243<720の情報量下界と、実在する深さ6木から最悪6が最適。確率的平均や違法な任意部分集合質問へ置き換えない。

候補720/質問120/depth6は定数。採用生成器の1369状態は実測であり探索worst-caseの多項式保証ではない。生成木を事前固定すれば一case6callback。T最大/partial-score式/実grader適合は未確認。

公式全別解の確認とは分ける: 最適6問以外の部分点採点式とmanual hardcoded treeは未検証。

初回実経路: `interactive-oracles → other`。

- `interactive-oracles/response`「質問すると何が返ってきますか？」→ `other`「その他の返答形式・通信条件」。

到達 `interactive-oracles/general-result`（result）「返答から次の合法な質問・移動を決める」。到達技巧 `['interactive']` は部品の到達であり、原典全域対応ではない。

不足: 任意の部分集合質問や隣接変化回数ではなく、120個の硬貨質問に限定して深さ6の全分岐を実現する必要がある。

候補ID `restricted-ternary-oracle-permutation-decision-tree`。特徴で選ぶ案: 少数の全順列候補を、実行可能な三返答質問だけで深さ制限内に分ける。guard案はregistration-proposal.jsonに保存し、否定/不明はcondition-checkへ戻す。

近接記事の全文・全C++・metadataを照合した範囲:

- `interactive`: 質問形式とflushの一般説明で、硬貨の120合法質問や6深さ保証を構成しない。 本文SHA `678dee906316c0e2cc110f3d8ae5e5ccaeaabec9966150ac41d36cdd155258c2`。
- `interactive-bit-group-testing`: 任意部分集合に対する二値所属を要求し、三硬貨のmin/median/maxとnextLightestしか使えない原典で質問を実行できない。 本文SHA `82fc91eb84ded2ba296dc70e2a76a0691fd941f4238666c3e631c79529b1849b`。
- `interactive-transition-count-species-decision-trees`: 二値配置の隣接変化回数と既知anchorを用いる別オラクル。硬貨の全順列・合法質問120個・6問を扱わない。 本文SHA `852707993381c986c78b9d07694e1ea11d60f2c57978fbc8017059f7a2ca680c`。

小研究probe（原典完成APIの検証ではない）: `{"permutations": 720, "legalQueries": 120, "minimumWorstCaseQuestions": 6, "informationLowerBound": "3^5 < 720 <= 3^6", "depthHistogram": {"6": 720}, "searchStates": 1369, "treeSha256": "99660cf946126463b78889edfde17a973a8165feac8ad670303364358ec22c1b", "oracle": "direct ranks of all six coins; decision tree exhaustively follows all answers", "seconds": 0.07516612600011285}`。

### Teams (teams)

[原典](https://www2.ioi-jp.org/ioi/2015/tasks/teams-en.pdf) / [公式Editorial](https://ioi.te.lv/locations/ioi15/contest/solutions/teams.pdf)。初回 `verified`、原典numeric完全確認 `True`、完成API `false`。

特徴: 各学生はチーム人数の閉区間[A,B]を受け入れる。 / 一つのチーム人数kならk人が必要。一人は当日一回だけ使え、余ってもよい。 / 同じ学生集合に対して独立な日のチーム人数列を多数質問する。

API: `{"entries": ["init(N,A,B)", "can(M,K)"], "protocol": "init once,can once per independent day;1 feasible or0 impossible", "cppHeaderBytesRetrieved": false, "exactCppSignatureConfirmed": true, "printedCppSignatures": ["void init(int N,int A[],int B[]);", "int can(int M,int K[]);"], "signatureEvidenceUrl": "https://ioi.te.lv/locations/ioi15/contest/day1/teams/en-VEN.VEN.pdf", "signatureEvidence": "Printed primary C/C++ program signature,not actual retrieved header bytes."}`。

確認済み数値: `{"N": [1, 500000], "Q": [1, 200000], "sumM": 200000, "A_B": "1<=A[i]<=B[i]<=N", "M": "1<=M<=N", "K": "1<=K[j]<=N", "scoreWeights": [21, 13, 43, 23], "subtasks": [{"N": 100, "Q": 100}, {"N": 100000, "Q": 1}, {"N": 100000, "Q": 100000, "sumM": 100000}, {"N": 500000, "Q": 200000, "sumM": 200000}], "seconds": 4, "memoryMB": 1500}`。

選定手順: チーム人数を昇順にし、現在適格な学生から上限Bの小さいk人を選ぶ。A閾値ごとの永続B頻度と、当日使用済みの別永続頻度の差を、部分木ごと一括消費する独立実装方針。

1. 現在人数kの適格者uを最小B順に選ぶ。別最適割当がvを選びuを後のk′>=kへ置くなら交換できる。vはA_v<=k<=k′かつB_v>=B_u>=k′。uが未使用なら単に置換。よって先に小Bを使う選択は後を妨げない。
2. A<=kを満たす全学生のB頻度root[k]を一点加算のpath copyingで保存。当日usedは0から始め、kの増加に伴いroot[k]は点ごと非減少なのでeligible-usedは常に非負。B<kは対象外である。
3. eligible-usedを小B側から必要人数だけ消費する。完全消費する部分木では、新usedをeligibleの既存nodeそのものへ置き換える。これはused+(eligible-used)=eligibleであり、他の版を書き換えない。葉で一部だけ消費するときは個数を増やす。
4. 消費対象はBの区間[k,last]とlast葉の一部なので、再帰が細分化するのは閾値と最後の選択位置の高々二本の境界だけ。全被覆部分木は共有で停止するため、一teamにO(log N)node訪問/新規nodeで済む。毎日usedを0へ戻して独立性を保つ。

前処理O(NlogN)、一queryの人数列整列O(MlogM)+一括消費O(MlogN)、前処理node O(NlogN)+当日O(MlogN)空間。全席/学生をqueryごとに列挙しない。

公式全別解の確認とは分ける: 公式前半のpersistent二次元greedyと交換の核は確認。末尾Hall DP/一交差/イベント＋fractional cascadingの別満点手順を、本独立bulk方式の証明へ読み替えない。

初回実経路: `flow-matching → place-time-goals`。

- `flow-matching/purpose`「対応や割当について、どの条件の答えを求めますか？」→ `place-time-goals`「場所・時刻・商品の条件に従い、行先・担当・割引券を割り当てる」。

到達 `assignment-place-time-goals/purpose`（question）「対応や割当について、どの条件の答えを求めますか？」。到達技巧 `[]` は部品の到達であり、原典全域対応ではない。

不足: 増加するチーム人数ごとの最小B優先の交換と、適格頻度−当日使用済み頻度を部分木単位で消費する再利用APIがない。

候補ID `interval-team-demand-persistent-count-bulk-greedy`。特徴で選ぶ案: 人数の区間を持つ候補から、同じ人数だけを各チームへ一括して割り当てる。guard案はregistration-proposal.jsonに保存し、否定/不明はcondition-checkへ戻す。

近接記事の全文・全C++・metadataを照合した範囲:

- `persistent-segment-tree`: 一点加算/区間和の部品だけ。二次元の適格学生頻度から当日使用済み頻度を引き、最小Bを一括消費する操作がない。 本文SHA `846dafc427fef6fa1d2e16a3e0d52f373dfe7a69f9fca98420dc148938a25255`。
- `persistent-prefix-kth`: 固定配列の二prefix差のk番目を返す。各queryでサイズ順に需要k人を消費する別used版と交換証明がない。 本文SHA `fa57b2241d937e1e08f5d649092378957b3c68cd69cd3f49ac00311a98aa57f9`。
- `matching`: 明示二部グラフのKuhn O(VE)。需要を席へ展開すると辺が二乗になり、50万人と多数独立日queryを包含しない。 本文SHA `25d266d7cc24298a888ba8f5ed236d938c8c10c1a442d68d4abf3d431527bf07`。
- `threshold-coupon-max-discount`: 一方向lowerのみの入れ子適格集合。学生のupper Bとteam size分の需要を持たない。 本文SHA `c8cb66c386f9ed2f8d6f8861ccd5689eff6f1612e0146f26d9e1e79bba65be3d`。

小研究probe（原典完成APIの検証ではない）: `{"cases": 26405, "oracle": "explicit disjoint student-subset assignment to each labeled team", "productionPersistentApi": false, "prototype": "persistent eligibility counts minus fresh per-query used counts, bulk subtree consumption", "seconds": 0.1229210269957548}`。

### Horses (horses)

[原典](https://www2.ioi-jp.org/ioi/2015/tasks/horses-en.pdf) / [公式Editorial](https://ioi.te.lv/locations/ioi15/contest/solutions/horses.pdf)。初回 `verified`、原典numeric完全確認 `True`、完成API `false`。

特徴: 正の整数倍率Xで年ごとに所持数を増やし、各年の正の価格Yで任意個数を売れる。 / 倍率または価格の一点代入が累積し、各更新後の最大収入を法1e9+7で返す。 / 最大化する大小は剰余を取る前の巨大な整数。倍率1が多数続くこともある。

API: `{"entries": ["init(N,X,Y)", "updateX(pos,val)", "updateY(pos,val)"], "protocol": "one init and cumulative updates; every call returns optimum mod1000000007;positions zero-based", "cppHeaderBytesRetrieved": false, "exactCppSignatureConfirmed": false}`。

確認済み数値: `{"N": [1, 500000], "updates": [0, 100000], "initialAndUpdatedX_Y": [1, 1000000000], "modulus": 1000000007, "scoreWeights": [17, 17, 20, 23, 23], "subtasks": [{"N": 10, "updates": 0, "X_Ymax": 10, "productXmax": 1000}, {"N": 1000, "updates": 1000}, {"N": 500000, "updates": 100000, "minX": 2}, {"N": 500000, "updates": 10000}, {"N": 500000, "updates": 100000}], "seconds": 1.5, "memoryMB": 1500}`。

選定手順: 一年度に全頭売る最適性、X=1 runの最大Yへの圧縮、最後の高々30個X>1とrun代表だけの候補化。比較には上限1e9+1の飽和積、出力にはmod積を別保存。

1. 一年の各馬は同じ倍率・価格を受け、売る/残すの最適継続価値は一頭ごと線形。逆向きDP F_i=max(Y_i,X_{i+1}F_{i+1})より、初期一頭の最大収入はmax_i(Y_i*prod_{j<=i}X_j)。全頭を同一最適年に売る整数行動で上界を達成する。
2. X>1が30個ある区間の倍率積は2^30>1e9。そこより前の候補は、後側の任意正価格>=1に厳密に負ける。従って最後30個の非単位倍率より前を落としてよい。非単位倍率間のX=1 runはprefix積が等しいので最大Yだけを残す。
3. i<jの比較はY_iと(prod_{i<h<=j}X_h)*Y_jだけでよい。積が1e9を超えた場合は後者が常に大きいため、倍率積を1e9+1で飽和しても大小判定は変わらない。最終交差積は<=1000000001*1000000000でsigned64bit内。
4. 非単位位置ordered set、最大YのRMQ、mod積/飽和積のセグメント木でpoint updateを反映する。run内代表の位置を保持し、比較を終えてからprefix mod積*Yを返す。巨大収入そのものを浮動小数点やmodで比較しない。

O(N)またはset構築込みO(NlogN)前処理、1更新O(log(1e9)logN)、O(N)空間の方針。prototypeは配列走査/任意精度整数を使い、上記更新API/時間上限の実証ではない。

公式全別解の確認とは分ける: 浮動小数点log比較法は採用せず、その誤差も確認していない。

初回実経路: `ranges → aggregate-goals → change → point-value-goals → point-set → aggregate → yes`。

- `ranges/updates`「数列について、何を求めますか？」→ `aggregate-goals`「連続する区間・利用期間・開催日の得点を集計する」。
- `range-aggregate-goals/updates`「数列について、何を求めますか？」→ `change`「値を変更しながら区間を集計する」。
- `range-update/change-kind`「一回の操作で、どの値がどう変わりますか？」→ `point-value-goals`「一点の値を変え、区間の集計・順位・重みつき和を答える」。
- `range-point-value-goals/change-kind`「一回の操作で、どの値がどう変わりますか？」→ `point-set`「一点に代入し、区間を集計する」。
- `range-point-value-goals/point-set-goal`「一点を書き換えた後、どの量を求めますか？」→ `aggregate`「和・最小値・最大値など、区間の値を結合した集計」。
- `range-point-value-goals/assoc`「隣り合う区間の答えをまとめて、全体の答えを求められますか？」→ `yes`「はい」。

到達 `range-point-value-goals/segment`（result）「セグメント木」。到達技巧 `['segment-tree']` は部品の到達であり、原典全域対応ではない。

不足: 一般の結合的な集計は到達するが、倍率1の圧縮、価格上限による候補数の定数化、飽和積による正確比較とmod積の分離がない。

候補ID `bounded-price-prefix-product-saturated-candidate-updates`。特徴で選ぶ案: 正の倍率と価格の一点変更後に、prefix積と末尾価格の積が最大の位置を求める。guard案はregistration-proposal.jsonに保存し、否定/不明はcondition-checkへ戻す。

近接記事の全文・全C++・metadataを照合した範囲:

- `segment-tree`: 任意の結合則の部品。max prefix product times priceの比較には巨大整数順序/切詰めとmod積を区別する新要約が必要。 本文SHA `caf3fc7ebba15960c3833c6058ad6599f279662968a9a257051f69541f51005e`。
- `maximum-product-sign-exchange`: 自由なK個を静的に選ぶ符号交換で、正のprefix積×その末尾価格の動的選択とは異なる。 本文SHA `8445c6f5e4605c48d0dc93b2ee3c6346f57a7f07998935e458a396dc0ce60088`。
- `point-update-nonadjacent-max-sum`: 加算max-plusの非隣接部分列。正整数prefix積の正確な大小とmodulo出力を扱わない。 本文SHA `00a937b5e823d75c5ac63f25da7bab0f0877705b3bcf037d167fc5147a040642`。

小研究probe（原典完成APIの検証ではない）: `{"comparisons": 10554, "allSalesHistoryCases": 1554, "oracle": "literal integer horse-sale DP and Python unbounded integer prefix revenue, cumulative random updates", "sourceMaximumExecuted": false, "seconds": 0.4582876469939947}`。

### Sorting (sorting)

[原典](https://www2.ioi-jp.org/ioi/2015/tasks/sorting-en.pdf) / [公式Editorial](https://ioi.te.lv/locations/ioi15/contest/solutions/sorting.pdf)。初回 `unconfirmed`、原典numeric完全確認 `False`、完成API `false`。

特徴: 順列を直す任意二位置交換を一回ずつ行う。相手が先に行う交換列は事前に全て分かる。 / 初期状態と各round終了後に完成を判定し、同位置交換で何もしなくてもよい。 / 最小round数と、各roundの相手交換後に実行する自分の位置交換列が必要。

API: `{"entry": "findSwapPairs(N,S,M,X,Y,P,Q)", "protocol": "one call; return R;write first R entries P/Q in preallocated M arrays;indices may coincide;sorted initial R0", "cppHeaderBytesRetrieved": false, "exactCppSignatureConfirmed": false}`。

確認済み数値: `{"permutation": "0..N-1", "indices": "0..N-1,including self-swaps", "solutionGuaranteedWithinM": true, "scoreWeights": [8, 12, 16, 18, 20, 26], "subtasksRequiringMinimumR": [5, 6], "seconds": 1, "memoryMB": 1500}`。

未確認: Exact N/M bounds and numerical upper limits on R in each subtask omitted from accessible primary extraction. / Subtasks1..3 extra numerical constraints on X/Y omitted; chosen method does not rely on them.

選定手順: 相手の位置swap prefix t後の順列についてN-cyclecount<=tか判定し、単調性で最小tを二分探索。最後に値swap列を作り、実際の各roundで現在位置へ変換して実行する。

1. 位置の置換を作用させる操作と、値ラベルの置換を作用させる操作は可換。よって自分の交換を値swapとして表せば、t回分の相手位置swapを先に行う仮想状態へ移してよい。
2. 仮想状態の最小任意交換数はN−サイクル数。これがt以下なら余りは同位置swapで埋められ、逆にt回以下の自分swapで完成するならその距離以下である。
3. tで可なら次roundは相手と同じ位置対を自分もswapして完成状態を保てる。したがって判定は単調。N−1回あれば任意の仮想順列を直せるため、上界min(M,N−1)で十分（原典はM内の解を保証）。
4. 仮想最終配列を固定する値swap列を保存し、実際には毎round相手位置swapを実行した後、その二値の現在位置を逆配列から取得してswapする。可換性により同じ最終値置換が施される。初期整列は0roundで直ちに停止する。

全入力読み込みを含めO(M+NlogN)時間/O(N+M)保持、prefixを外部arrayとして参照すれば補助O(N)。原典N/M数値・完成C++/witness最大実行は未確認。

公式全別解の確認とは分ける: 公式コメントの動的cycleをBBSTで更新する別手順は未検証。

初回実経路: `ranges → sequence-changes → sort-permutation → arbitrary → yes`。

- `ranges/updates`「数列について、何を求めますか？」→ `sequence-changes`「列の並び・各値・巡回位置を変えて目標の形にする」。
- `range-sequence-changes/updates`「数列について、何を求めますか？」→ `sort-permutation`「順列を位置の交換で昇順に並べ直す」。
- `permutation-swaps/swap-kind`「一回に交換できる位置はどれですか？」→ `arbitrary`「任意の二位置を交換できる」。
- `permutation-swaps/permutation-values`「各値は一回ずつ現れ、値の目標位置を一意に決められますか？」→ `yes`「はい」。

到達 `permutation-swaps/permutation-result`（result）「位置と目標の循環を分け、長さ L の循環を L−1 回で直す」。到達技巧 `['permutation-cycle-minimum-swaps']` は部品の到達であり、原典全域対応ではない。

不足: 静的N−cycleの交換数だけでは相手の先行交換を織り込めない。値交換の可換性・round可否の単調性・位置への戻しが不足する。

候補ID `scheduled-position-swaps-commuting-value-swaps-minimum-rounds`。特徴で選ぶ案: 既知の位置交換が毎回先に入る順列を、最少回数の自分の交換で直す。guard案はregistration-proposal.jsonに保存し、否定/不明はcondition-checkへ戻す。

近接記事の全文・全C++・metadataを照合した範囲:

- `permutation-cycle-minimum-swaps`: 相手の既知位置交換が割り込まない静的順列のみ。必要round判定と値交換/位置交換の可換性による再配置がない。 本文SHA `6e9b243e06e4abce90cae9e058eebcebdf7e3c949c94a6b45754b1b23188ad7e`。
- `simultaneous-swap-parity`: 二列に三相異なるindexを使う同期交換の可否。任意位置交換の既知外乱列や最短round witnessではない。 本文SHA `2c3f37a394c9eff211126495b4945df4d204d9ef3efa39ab673ec475872d9531`。
- `binary-search`: 境界探索の部品で、外乱prefix後のN-cyclecount<=tという判定と操作再生の正当性を持たない。 本文SHA `2974c005fe0a456940fae81d2091b4759dec7b867fc0da7bb79859cc740ee83d`。

小研究probe（原典完成APIの検証ではない）: `{"cases": 3135, "oracle": "all own legal position swaps after each fixed enemy swap, reachable permutations per round", "checksMinimumAndReplayedWitness": true, "seconds": 0.18718760598858353}`。

### Towns (towns)

[原典](https://www2.ioi-jp.org/ioi/2015/tasks/towns-en.pdf) / [公式Editorial](https://ioi.te.lv/locations/ioi15/contest/solutions/towns.pdf)。初回 `verified`、原典numeric完全確認 `True`、完成API `false`。

特徴: 正重みの隠れ木の葉だけに番号があり、二葉の距離だけを質問できる。 / 内部都市は次数3以上で、全葉への最遠距離を最小にする既存内点を探す。 / そのhubを除いた全成分の葉数がN/2以下となるhubの有無も、ceil(7N/2)質問内で判定する。

API: `{"entry": "hubDistance(N,sub)", "callback": "getDistance(i,j)", "protocol": "up to40 cases per run; fresh state every call;sub1/2 may return +/-R;sub3..6 +R iff balanced hub exists,otherwise -R;getDistance same or invalid args returns0", "cppHeaderBytesRetrieved": false, "exactCppSignatureConfirmed": false}`。

確認済み数値: `{"N": [6, 110], "casesPerRunMax": 40, "distinctLeafDistance": [1, 1000000], "internalDegreeMin": 3, "scoreWeights": [13, 12, 13, 10, 13, 39], "queryLimits": ["N(N-1)/2", "ceil(7N/2)", "N(N-1)/2", "ceil(7N/2)", "5N", "ceil(7N/2)"], "balancedHubRequired": [false, false, true, true, true, true], "subtask4InternalDegree": 3, "seconds": 1, "memoryMB": 1500}`。

選定手順: 二点からの全葉距離と射影座標で離散hub候補を得る。左右成分を先に人数で除き、offpathがN/2超の高々一候補だけにBoyer–Moore＋既知Equal group代表による重み検証を行う独立補完。

1. 任意葉vから最遠葉s、sから最遠葉tを求めD=d(s,t)。対称既知距離を再利用し自己質問を省けば2N−3回。最遠葉は直径端点であり、連続中心はv−s経路にある。vの直径合流座標はsからD/2以上で、v−s上の座標cの離心率はmax(c,D−c)。
2. 各葉uのv−sへの射影はc(u)=(d(s,u)+d(s,v)−d(v,u))/2。経路上の各内部都市は次数3以上なので経路外へ分かれる葉があり、射影の異なる値（両端葉0,d(v,s)を除く）が全ての候補内点を尽くす。max(c,D−c)最小の既存座標は高々二個。
3. c(u)<rと>rはhubの左右二成分。どちらかがN/2超なら追加質問なしで棄却。X={u:c(u)=r}内の二葉は、同じoffpath成分 iff d(s,x)+d(s,y)−d(x,y)>2r。Xの人数自体がN/2以下ならその候補はbalanced。異なるrのXは互いに素で、|X|>N/2は高々一候補だけ。
4. m=|X|についてBoyer–Mooreの残高0時候補設定R回、Equal E回、NotEqual U回ならm=R+E+U、最終残高f=R+E−U。異色一対の除去は厳密多数色を失わないため、f=0なら多数派なし、f>0なら元の多数派は最終候補色。
5. 候補選定のEqual返答の辺だけで同色groupをunionする。各Equalは新要素をつなぎ、group数m−E。候補group以外の代表を一度ずつ候補と比較すれば同色人数をgroup重みで完全に集計できる。比較総数は(m−R)+(m−E−1)=(3m−f)/2−1<1.5m。global N/2超ならm/2超でもあるのでこれで足りる。
6. 初期2N−3と、多くても一集合への<1.5m<=1.5N追加からceil(7N/2)以内。公式odd集合を任意dropする記述をそのまま正しいとは認定せず、独立のgroup検証証明で補う。

O(N)距離質問、cacheをmap/arrayで持つ研究版はO(N²)まで空間。候補抽出にsortを使えばO(NlogN)計算、group DSU O(N alphaN)。完成callback API/全source最大native検証は未実装。

公式全別解の確認とは分ける: 公式p2のodd-set任意discardの文字どおりの正当性は未確認。AABでAをdiscardして残りA/Bをcancelすると誤る。採用方式はこの解釈に依存しない。

初回実経路: `interactive-oracles → tree-distance → yes → yes`。

- `interactive-oracles/response`「質問すると何が返ってきますか？」→ `tree-distance`「辺は未知だが、指定した二頂点の木距離」。
- `interactive-oracles/tree-positive`「対象は正の辺重みを持つ木で、距離の返答は正確ですか？」→ `yes`「はい」。
- `interactive-oracles/tree-query-budget`「一始点からの全距離を二度調べ、2(N−1) 回以内の質問が許されますか？」→ `yes`「はい」。

到達 `interactive-oracles/tree-oracle-result`（result）「任意点から最遠点を探し、その点からの最遠距離を調べる」。到達技巧 `['interactive-tree-diameter', 'interactive']` は部品の到達であり、原典全域対応ではない。

不足: 直径の質問部品はあるが、既存内点を表す射影座標と離散hub、offpath同成分の同値関係、予算内多数派検証がない。

候補ID `leaf-distance-hidden-hubs-projection-majority-queries`。特徴で選ぶ案: 葉間距離だけから隠れた内点の最小半径と、葉数が均衡する成分分割を判定する。guard案はregistration-proposal.jsonに保存し、否定/不明はcondition-checkへ戻す。

近接記事の全文・全C++・metadataを照合した範囲:

- `interactive-tree-diameter`: 隠れ木のdiameterだけ。葉だけを質問し、未知内点の離散hubを復元してleaf component過半数を検査する手順がない。 本文SHA `338a8ebe149aae5aaee352c02454364c80440e89469efd1031b3e418cbb66012`。
- `tree-eccentricity-diameter-endpoints`: 明示全頂点・全辺を要求するAPIで、未知内部都市や3.5N葉間質問budgetを扱わない。 本文SHA `7a2f3e38c48aa717d37ec6c762016a2f4bfb5f18dc5924658ff91ac9b91a0213`。
- `centroid-count-cross-subtrees`: 既知隣接木で距離Kの頂点対を数える。未知内点からのleaf balanceとは観測/出力が異なる。 本文SHA `a9e2aed378034b1e25b5ac1be3ad5d6746dd9b72ce5c5870aed598fd1a533567`。

小研究probe（原典完成APIの検証ではない）: `{"allEqualityPartitions": 26442, "randomPositiveWeightedTrees": 2800, "maxLeavesTested": 30, "maxQueriesObserved": 86, "queryBoundVerifiedPerInstance": "ceil(7N/2)", "oracle": "all internal vertices eccentricity and each literal removed-vertex component leaf count", "majorityMethod": "Boyer-Moore plus Equal-connected homogeneous groups; independent clarification of odd-set editorial ambiguity", "seconds": 0.2727007059875177}`。

## 全15分野の比較と独立再生

全六題それぞれについて15根のquestion・全選択肢・root node hashと採用/不採用理由を `root-assessments.json` に保存した。アルゴリズム名から後付けでrootを選ばず、入力の操作・観測を優先する。Horsesは「一点代入→集計→結合可能」を実際にyesへ辿り、generic segment-tree結果まで進めた上で、巨大積の正確比較と更新要約が不足すると判断した。途中に選べる正しいaggregate選択肢があるのに早く止めた記録にはしない。

独立Python raw walkerは質問全文・回答label・target・route境界・到達node全fieldを保存する。別のJSは凍結src/lib/flow.tsを別epochのコンパイラで実compileし、六canonicalと532旧walkの2816回答について、raw steps/label/terminalの全fieldと一致させる。旧全record実bytes自体もledger固定である。`runtime-replay.json` に結果。凍結validatorは511/532/478/3739と25source ledgerを検査し成功、書換えなし。

19近接MDXの各fenceをそのまま抽出して通常C++20 compile/runし、各記事の本来のcomponentの小例を確認した。原典ソルバへ組み替えたものではない。`scope-checks.json` は全MDX/CPP/metadataのhash、全component harnessとscope差を保持する。

## 検査とcounterの意味

`probe.py` はPython小規模研究モデルだけで、新しいC++20本体、原典callback adapter、最大原典native性能、ASanは作成/実行していない。87,395は保存rawの1468SHA比較を含むassertion数。各題のcase数はprobe.jsonへ別に記録し、Horsesの全売却historyケースと更新比較、Scalesの全順列と探索state数を混ぜない。Scales探索の1369state/計算時間は実測であり、探索木生成の一般多項式最悪上界ではない。

Townsだけの別peer補助は `flowchartcp-ioi2015-towns-peer-review.json` とnotes/probe/resultsに保存。142418同値分割・712089閾値、38092 weighted tree、4959568 checksで一致し、source N6..110も独立確認した。この補助を全監査peer完了へ広げない。公式odd arbitrary discardの未確認を残したまま、別のEqual group多数派証明が全質問予算を満たすと確認した。

snapshotだけの別peer補助は `flowchartcp-ioi2015-snapshot-peer-review.json`。1468raw、105vendor、15roots、532walkとactual runtimeを確認したが、六題のsource/nearby scope full peer完了とは呼ばない。最終audit全体は別peerの精査待ちである。

## 再現入口と次の作業

```sh
python3 /tmp/flowchartcp-ioi2015-probe.py
python3 /tmp/flowchartcp-ioi2015-scope-checks.py
python3 /tmp/flowchartcp-ioi2015-replay.py
node /tmp/flowchartcp-ioi2015-runtime-replay.mjs
```

probeは現在tmp JSONを書き出す著者用である。恒久版へ移す際は元rawと元JSONを残し、fresh tempへ全rawを復元して毎回1468SHAを再照合し、既定stdout JSON、明示output引数時だけ結果を書き出す。意味・乱数seed・counterは変えない。全1468raw/全511MDXを決定的archiveで保持し、vendor105を別archiveに分けることを提案する。metadataやmanifestだけで代用しない。

最終freeze前にpeerからの新primary LKA配布を著者も再確認でき、Boxesの全6数値表を解消した。N最大1e7/L最大1e9、subtask5のK<=3000をK<=Nへ狭めない。成功queryは `site:ioi.te.lv/locations/ioi15/contest/day1/boxes/en-LKA.LKA.pdf "Subtasks"`、実際の返却URLも同じである。優先followupはSorting数値表、Scales T範囲/partial-score式のprimary再取得。新しいsource候補がない同一cache/DNS失敗の反復を続けず、未確認の初回状態を残す。数値確認済み四題にも、一般技巧記事・完全API・原典最大・literal比較・invalid/reentrant・通常ASan・別peer・特徴分岐を新たに作る必要がある。初回六rowのpositive/unknown/全falseflag/stopを改変せず、後続の真正な証拠をsubsequent review/resolutionだけで追加する。

日付はJP公式日別一覧で2015-07-28/2015-07-30を確認し、難度値は全題null。カットオフ2026-10-14、調査2026-10-15。共有article/data/flow/walk/audit/plan/sourceは本担当が一切編集していない。
