import { readFile, writeFile } from 'node:fs/promises';
import { compileLocalModules } from './flowchartcp-ioi2015-baseline/scripts/local-modules.mjs';
import assert from 'node:assert/strict';
const base='/tmp/flowchartcp-ioi2015-baseline';
const out='/tmp/flowchartcp-ioi2015-runtime';
await compileLocalModules(base,out);
const flow=await import(`${out}/flow.js`);
const routes=JSON.parse(await readFile('/tmp/flowchartcp-ioi2015-routes.json','utf8'));
for(const [task,row] of Object.entries(routes)) {
 const actual=flow.walkFromRoot(row.choices,row.entryGraphId);
 assert.equal(actual.consumed,row.choices.length);
 assert.deepEqual(actual.steps,row.steps.map(s=>({graph:s.graphId,node:s.nodeId,answer:s.answer,target:s.target})));
 assert.deepEqual({graphId:actual.graph.id,nodeId:actual.current.id,type:actual.current.type,title:actual.current.title,options:flow.getNodeOptions(actual.current),techniques:actual.current.techniques??[],conditions:actual.current.conditions??[]},row.reached);
 for(const step of row.steps) {
  const graph=flow.getGraph(step.graphId),node=flow.getNode(graph,step.nodeId);
  assert.equal(node.title,step.question);assert.equal(flow.getAnswerLabel(node,step.answer),step.answerLabel);
 }
}
const old=JSON.parse(await readFile(base+'/data/problem-walks.json','utf8'));
const rawOld=JSON.parse(await readFile('/tmp/flowchartcp-ioi2015-old-walk-traces.json','utf8')).records;
for(const [index,record] of old.entries()){
 const a=flow.walkFromRoot(record.choices,record.entryGraphId??'ranges');
 assert.equal(a.consumed,record.choices.length);
 assert.deepEqual(a.steps.map(({graph,node,answer})=>({graph,node,answer})),record.steps);
 assert.deepEqual(a.current,rawOld[index].reachedRawNode);
 for(const step of rawOld[index].steps){const g=flow.getGraph(step.graphId),n=flow.getNode(g,step.nodeId);assert.equal(n.title,step.question);assert.equal(flow.getAnswerLabel(n,step.answer),step.answerLabel);}
 for(const id of record.expectedTechniqueIds)assert.ok((a.current.techniques??[]).includes(id));
}
const result={allExistingWalkRecordsReplayed:old.length,allOldWalkStepsPreserved:true,allOldRawCurrentNodesAndLabelsCompared:true,frozenRuntimeReplayEqual:true,sixCanonicalRoutes:6,entryDomainIds:flow.entryGraphs.map(g=>g.id),flowGraphs:flow.graphs.length,allQuestionsAndFullAnswerLabelsEqual:true,productionApiCoverageClaimed:false};
await writeFile('/tmp/flowchartcp-ioi2015-runtime-replay.json',JSON.stringify(result,null,2)+'\n');console.log(result);
