"""Small independent research models. No production C++ API/ASan claim.
The source snapshot and six identities precede this file. Python >=3.10.
"""
from pathlib import Path
from itertools import permutations,combinations,combinations_with_replacement,product
from functools import lru_cache
from collections import deque
import json,math,random,time,hashlib
BASE=Path('/tmp/flowchartcp-ioi2015-baseline')
RNG=random.Random(20150728)
CHECKS=0
def check(a,b):
 global CHECKS
 CHECKS+=1
 assert a==b,(a,b)

def boxes_formula(pos,k,L):
 n=len(pos);a=[0]*(n+1);b=[0]*(n+1)
 for i in range(1,n+1):a[i]=a[max(0,i-k)]+2*pos[i-1]
 for i in range(n-1,-1,-1):b[i]=b[min(n,i+k)]+2*(L-pos[i])
 return min([a[i]+b[i] for i in range(n+1)]+[a[i]+L+b[min(n,i+k)] for i in range(n+1)])
def boxes_literal(pos,k,L):
 # Every individual trip is an unrestricted walk on the circle, found by BFS.
 # Visiting a team is enough; masks retain distinct teams at duplicate locations.
 n=len(pos);at=[0]*L
 for i,x in enumerate(pos):at[x]|=1<<i
 trip={};seen={(0,at[0]):0};q=deque([(0,at[0])])
 while q:
  x,m=q.popleft();d=seen[x,m]
  if x==0:
   sub=m
   while True:
    if sub.bit_count()<=k:trip[sub]=min(trip.get(sub,10**9),d)
    if sub==0:break
    sub=(sub-1)&m
  for y in ((x+1)%L,(x-1)%L):
   v=(y,m|at[y])
   if v not in seen:seen[v]=d+1;q.append(v)
 dp=[10**9]*(1<<n);dp[0]=0
 for m in range(1<<n):
  for s,c in trip.items():dp[m|s]=min(dp[m|s],dp[m]+c)
 return dp[-1]
def probe_boxes():
 cases=0
 for L in range(2,8):
  for n in range(1,6):
   for pos in combinations_with_replacement(range(L),n):
    for k in range(1,n+2):
     check(boxes_formula(pos,k,L),boxes_literal(pos,k,L));cases+=1
 return {'cases':cases,'oracle':'unrestricted circle-walk BFS per trip, then mask partition DP','maxTeams':5,'maxCircleLength':7}

def probe_scales():
 ps=list(permutations(range(6)));queries=[]
 for abc in combinations(range(6),3):
  for kind in range(3):queries.append((kind,abc,None))
  for d in range(6):
   if d not in abc:queries.append((3,abc,d))
 masks=[]
 for kind,abc,d in queries:
  out=[0,0,0]
  for i,p in enumerate(ps):
   rank=[0]*6
   for j,x in enumerate(p):rank[x]=j
   s=sorted(abc,key=rank.__getitem__)
   winner=s[kind] if kind<3 else next((x for x in s if rank[x]>rank[d]),s[0])
   out[abc.index(winner)]|=1<<i
  masks.append(tuple(out))
 states=0
 @lru_cache(None)
 def solve(mask,depth):
  nonlocal states
  states+=1
  if mask.bit_count()==1:return (-1,mask.bit_length()-1)
  if mask.bit_count()>3**depth or depth==0:return None
  cap=3**(depth-1);candidates=[]
  for qi,part in enumerate(masks):
   bs=tuple(mask&x for x in part);counts=tuple(x.bit_count() for x in bs)
   if max(counts)<=cap and max(counts)<mask.bit_count():candidates.append((max(counts),sum(c*c for c in counts),qi,bs))
  candidates.sort()
  for _,__,qi,bs in candidates:
   children=[]
   for b in bs:
    child=solve(b,depth-1) if b else (-2,)
    if child is None:break
    children.append(child)
   else:return (qi,tuple(children))
  return None
 tree=solve((1<<720)-1,6);assert tree is not None
 depthhist={};nodes=set()
 for i,p in enumerate(ps):
  node=tree;depth=0
  while node[0]>=0:
   qi=node[0];nodes.add(qi);out=next(j for j,m in enumerate(masks[qi]) if (m>>i)&1);node=node[1][out];depth+=1
  check(node[1],i);assert depth<=6;depthhist[depth]=depthhist.get(depth,0)+1
 return {'permutations':720,'legalQueries':len(queries),'minimumWorstCaseQuestions':6,'informationLowerBound':'3^5 < 720 <= 3^6','depthHistogram':depthhist,'searchStates':states,'treeSha256':hashlib.sha256(repr(tree).encode()).hexdigest(),'oracle':'direct ranks of all six coins; decision tree exhaustively follows all answers'}

def team_literal(intervals,ks):
 # Team instances are distinct, students selected by subsets, no greedy ordering.
 states={0}
 for k in ks:
  nxt=set()
  for m in states:
   avail=[i for i,(a,b) in enumerate(intervals) if not(m>>i)&1 and a<=k<=b]
   for group in combinations(avail,k):nxt.add(m|sum(1<<i for i in group))
  states=nxt
 return bool(states)
def teams_bulk(intervals,ks):
 n=len(intervals);nodes=[(0,0,0)];versions=[0]*(n+1)
 def add(p,l,r,x):
  a,b,c=nodes[p]
  if l+1<r:
   mid=(l+r)//2
   if x<mid:a=add(a,l,mid,x)
   else:b=add(b,mid,r,x)
  nodes.append((a,b,c+1));return len(nodes)-1
 by=[[] for _ in range(n+1)]
 for a,b in intervals:by[a].append(b)
 for a in range(1,n+1):
  versions[a]=versions[a-1]
  for b in by[a]:versions[a]=add(versions[a],1,n+1,b)
 used=0
 # A leaf can contain repeated B; partial consumption creates its own count.
 def take(e,u,l,r,lower,need):
  if not need or r<=lower:return u,need
  available=nodes[e][2]-nodes[u][2];assert available>=0
  if lower<=l and available<=need:return e,need-available
  if l+1==r:
   nodes.append((0,0,nodes[u][2]+need));return len(nodes)-1,0
  mid=(l+r)//2
  a,left=take(nodes[e][0],nodes[u][0],l,mid,lower,need)
  b,left=take(nodes[e][1],nodes[u][1],mid,r,lower,left)
  nodes.append((a,b,nodes[a][2]+nodes[b][2]));return len(nodes)-1,left
 for k in sorted(ks):
  used,left=take(versions[k],used,1,n+1,k,k)
  if left:return False
 return True
def probe_teams():
 cases=0
 for n in range(1,5):
  opts=list(combinations_with_replacement(range(1,n+1),2))
  # All interval multisets, with arbitrary order tested separately below.
  for iv in combinations_with_replacement(opts,n):
   for m in range(1,min(n,3)+1):
    for ks in combinations_with_replacement(range(1,n+1),m):
     check(teams_bulk(iv,ks),team_literal(iv,ks));cases+=1
 for _ in range(1000):
  n=RNG.randrange(1,10);iv=[sorted([RNG.randrange(1,n+1),RNG.randrange(1,n+1)]) for _ in range(n)];ks=[RNG.randrange(1,n+1) for _ in range(RNG.randrange(1,n+1))]
  check(teams_bulk(iv,ks),team_literal(iv,ks));cases+=1
 return {'cases':cases,'oracle':'explicit disjoint student-subset assignment to each labeled team','productionPersistentApi':False,'prototype':'persistent eligibility counts minus fresh per-query used counts, bulk subtree consumption'}

def horses_compressed(x,y,limit):
 nonunit=[i for i,a in enumerate(x) if a>1]
 keep=nonunit[-(limit.bit_length()):]
 start=keep[0] if len(nonunit)>=limit.bit_length() else 0
 cuts=sorted(set([start,len(x)]+[i for i in keep if i>=start]))
 cand=[max(range(a,b),key=lambda j:y[j]) for a,b in zip(cuts,cuts[1:]) if a<b]
 best=cand[0]
 for j in cand[1:]:
  sat=1
  for a in x[best+1:j+1]:sat=min(limit+1,sat*a)
  if y[best]<=sat*y[j]:best=j
 return math.prod(x[:best+1])*y[best]
def horses_sell_literal(x,y):
 # All choices of number sold in every year, carrying the remaining live horses.
 @lru_cache(None)
 def f(i,h):
  if i==len(x):return 0
  h*=x[i]
  return max(s*y[i]+f(i+1,h-s) for s in range(h+1))
 return f(0,1)
def probe_horses():
 cases=0;histories=0
 for n in range(1,5):
  for x in product(range(1,3),repeat=n):
   for y in product(range(1,4),repeat=n):
    exact=max(math.prod(x[:i+1])*y[i] for i in range(n))
    check(horses_compressed(x,y,3),exact);check(horses_sell_literal(x,y),exact);cases+=1;histories+=1
 for _ in range(3000):
  n=RNG.randrange(1,101);x=[RNG.choice([1,1,2,10**9]) for _ in range(n)];y=[RNG.randrange(1,10**9+1) for _ in range(n)]
  for __ in range(3):
   pos=RNG.randrange(n)
   if RNG.randrange(2):x[pos]=RNG.choice([1,2,10**9])
   else:y[pos]=RNG.randrange(1,10**9+1)
   check(horses_compressed(x,y,10**9),max(math.prod(x[:i+1])*y[i] for i in range(n)));cases+=1
 return {'comparisons':cases,'allSalesHistoryCases':histories,'oracle':'literal integer horse-sale DP and Python unbounded integer prefix revenue, cumulative random updates','sourceMaximumExecuted':False}

def swap(a,u,v):
 b=list(a);b[u],b[v]=b[v],b[u];return tuple(b)
def cycle_cost(a):
 seen=set();c=0
 for i in range(len(a)):
  if i in seen:continue
  c+=1;j=i
  while j not in seen:seen.add(j);j=a[j]
 return len(a)-c
def sorting_method(s,enemy):
 n=len(s);a=s;t=0
 while cycle_cost(a)>t:
  if t==len(enemy):return None
  a=swap(a,*enemy[t]);t+=1
 # Value swaps for the state after all t enemy swaps.
 a=list(a);valuepairs=[]
 for i in range(n):
  if a[i]!=i:
   j=a.index(i);valuepairs.append((a[i],a[j]));a[i],a[j]=a[j],a[i]
 valuepairs += [(0,0)]*(t-len(valuepairs));a=s;own=[]
 for (u,v),(x,y) in zip(enemy,valuepairs):
  a=swap(a,u,v);i=a.index(x);j=a.index(y);own.append((i,j));a=swap(a,i,j)
 check(a,tuple(range(n)))
 return t,own
def sorting_literal(s,enemy):
 target=tuple(range(len(s)));states={s}
 if s==target:return 0
 for t,(u,v) in enumerate(enemy,1):
  states={swap(swap(a,u,v),i,j) for a in states for i in range(len(s)) for j in range(i,len(s))}
  if target in states:return t
 return None
def probe_sorting():
 cases=0
 for n in range(1,5):
  es=list(combinations_with_replacement(range(n),2))
  for s in permutations(range(n)):
   for enemy in product(es,repeat=min(2,n)):
    oracle=sorting_literal(s,enemy);got=sorting_method(s,enemy)
    check(None if got is None else got[0],oracle);cases+=1
 for _ in range(500):
  n=RNG.randrange(2,7);s=list(range(n));RNG.shuffle(s);enemy=[(RNG.randrange(n),RNG.randrange(n)) for _ in range(n)]
  check(sorting_method(tuple(s),enemy)[0],sorting_literal(tuple(s),enemy));cases+=1
 return {'cases':cases,'oracle':'all own legal position swaps after each fixed enemy swap, reachable permutations per round','checksMinimumAndReplayedWitness':True}

def majority_groups(items,same):
 # Equal comparison edges define homogeneous groups; verify representatives.
 parent={i:i for i in items};size={i:1 for i in items};calls=0;cand=None;bal=0
 def root(i):
  while parent[i]!=i:i=parent[i]
  return i
 for i in items:
  if bal==0:cand=i;bal=1
  else:
   calls+=1
   if same(cand,i):
    bal+=1;a=root(cand);b=root(i)
    if a!=b:parent[b]=a;size[a]+=size[b]
   else:bal-=1
 if bal==0:return 0,calls
 cr=root(cand);count=size[cr]
 for r in list(size):
  if root(r)==r and r!=cr:
   calls+=1
   if same(cand,r):count+=size[r]
 assert 2*calls<=3*len(items)
 return count if 2*count>len(items) else 0,calls
def towns_method(adj,leaves):
 n=len(leaves);dist=[]
 for s in range(len(adj)):
  d=[None]*len(adj);d[s]=0;q=[s]
  for v in q:
   for u,w in adj[v]:
    if d[u] is None:d[u]=d[v]+w;q.append(u)
  dist.append(d)
 cache={};calls=0
 def ask(a,b):
  nonlocal calls
  if a==b:return 0
  key=tuple(sorted((a,b)))
  if key not in cache:calls+=1;cache[key]=dist[leaves[a]][leaves[b]]
  return cache[key]
 v=0;dv=[ask(v,i) for i in range(n)];s=max(range(n),key=dv.__getitem__);ds=[ask(s,i) for i in range(n)];D=max(ds)
 p=[(ds[i]+dv[s]-dv[i])//2 for i in range(n)]
 possible=sorted(set(p)-{0,dv[s]});r=min(max(c,D-c) for c in possible)
 hubs=[c for c in possible if max(c,D-c)==r];ok=False
 for c in hubs:
  if sum(x<c for x in p)>n//2 or sum(x>c for x in p)>n//2:continue
  ids=[i for i,x in enumerate(p) if x==c]
  if len(ids)<=n//2:ok=True;break
  count,_=majority_groups(ids,lambda a,b:ds[a]+ds[b]-ask(a,b)>2*c)
  if count<=n//2:ok=True;break
 assert calls<=math.ceil(7*n/2),(n,calls)
 internals=[v for v in range(len(adj)) if len(adj[v])>=3]
 rad={v:max(dist[v][u] for u in leaves) for v in internals};best=min(rad.values());balanced=False
 for h in internals:
  if rad[h]!=best:continue
  sizes=[]
  for u,w in adj[h]:
   seen={h,u};q=[u]
   for z in q:
    for t,w in adj[z]:
     if t not in seen:seen.add(t);q.append(t)
   sizes.append(sum(x in seen for x in leaves))
  if max(sizes)<=n//2:balanced=True
 check(r,best);check(ok,balanced)
 return calls
def probe_towns():
 partitioncases=0;maxratio=0
 # Restricted-growth strings enumerate all equality partitions, no random labeling.
 def gen(a,n):
  if len(a)==n:
   yield a;return
  for c in range(max(a)+2):yield from gen(a+(c,),n)
 for n in range(1,10):
  for p in gen((0,),n):
   value,c=majority_groups(list(range(n)),lambda i,j:p[i]==p[j]);truth=max(p.count(x) for x in set(p));check(value if value else 0,truth if 2*truth>n else 0);partitioncases+=1
 treecases=0;maxcalls=0
 for n in range(3,31):
  for _ in range(100):
   edges=[(0,3,1),(1,3,1),(2,3,1)];leaf=[0,1,2];nextid=4
   while len(leaf)<n:
    if RNG.randrange(2):
     u,v,w=edges.pop(RNG.randrange(len(edges)));edges.extend([(u,nextid,1),(v,nextid,1),(nextid,nextid+1,1)]);leaf.append(nextid+1);nextid+=2
    else:
     internal=RNG.choice([v for v in range(nextid) if v not in leaf]);edges.append((internal,nextid,1));leaf.append(nextid);nextid+=1
   adj=[[] for _ in range(nextid)]
   for u,v,_ in edges:w=RNG.randrange(1,20);adj[u].append((v,w));adj[v].append((u,w))
   c=towns_method(adj,leaf);maxcalls=max(maxcalls,c);treecases+=1
 return {'allEqualityPartitions':partitioncases,'randomPositiveWeightedTrees':treecases,'maxLeavesTested':30,'maxQueriesObserved':maxcalls,'queryBoundVerifiedPerInstance':'ceil(7N/2)','oracle':'all internal vertices eccentricity and each literal removed-vertex component leaf count','majorityMethod':'Boyer-Moore plus Equal-connected homogeneous groups; independent clarification of odd-set editorial ambiguity'}

def preservation():
 manifest=json.loads(Path('/tmp/flowchartcp-ioi2015-manifest.json').read_text());hashes=manifest.get('fullRawHashes')
 if hashes is None:
  hashes=json.loads((BASE/'hashes-before.json').read_text())
 for rel,want in hashes.items():check(hashlib.sha256((BASE/rel).read_bytes()).hexdigest(),want)
 return {'initialRawFiles':len(hashes),'allInitialRawSha256Equal':True,'initialEpochNotCurrentSite':True}
def main():
 started=time.monotonic();result={'kind':'small-independent-research-prototypes','productionApiImplemented':False,'cppFenceCompared':False,'asanClaimed':False,'preservation':preservation()}
 for name in ['boxes','scales','teams','horses','sorting','towns']:
  before=time.monotonic();result[name]=globals()['probe_'+name]();result[name]['seconds']=time.monotonic()-before;print(name,result[name],flush=True)
 result['assertions']=CHECKS;result['elapsedSeconds']=time.monotonic()-started
 Path('/tmp/flowchartcp-ioi2015-snapshot-peer-author-probe-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':main()
