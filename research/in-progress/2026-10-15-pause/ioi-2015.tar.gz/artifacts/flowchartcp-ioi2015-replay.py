from pathlib import Path
import hashlib,json,re,subprocess,tempfile
BASE=Path('/tmp/flowchartcp-ioi2015-baseline')
SPECS=[('boxes','geometry',['travel-partition']),('scales','interactive-oracles',['other']),('teams','flow-matching',['place-time-goals']),('horses','ranges',['aggregate-goals','change','point-value-goals','point-set','aggregate','yes']),('sorting','ranges',['sequence-changes','sort-permutation','arbitrary','yes']),('towns','interactive-oracles',['tree-distance','yes','yes'])]
GRAPHS=json.loads((BASE/'data/flows.json').read_text());BY={g['id']:g for g in GRAPHS}
def options(node):return node.get('options',[{'id':a,'label':{'yes':'はい','no':'いいえ','unknown':'わからない'}.get(a,a)} for a in node.get('answers',{})])
def walk(entry,choices):
    graph=BY[entry];node=next(n for n in graph['nodes'] if n['id']==graph['root']);steps=[];consumed=0;routes=[]
    while True:
        if node['type']=='route':
            key=graph['id']+'/'+node['id'];assert key not in routes;routes.append(key);graph=BY[node['graph']];node=next(n for n in graph['nodes'] if n['id']==graph['root']);continue
        if node['type']!='question' or consumed==len(choices):break
        a=choices[consumed];label=next(o['label'] for o in options(node) if o['id']==a);target=node['answers'][a]
        steps.append({'graphId':graph['id'],'nodeId':node['id'],'question':node['title'],'answer':a,'answerLabel':label,'target':target});consumed+=1;node=next(n for n in graph['nodes'] if n['id']==target)
    assert consumed==len(choices)
    reached={'graphId':graph['id'],'nodeId':node['id'],'type':node['type'],'title':node['title'],'options':options(node),'techniques':node.get('techniques',[]),'conditions':node.get('conditions',[])}
    return {'officialTaskId':entry,'entryGraphId':entry,'choices':choices,'steps':steps,'stepsSha256':hashlib.sha256(json.dumps(steps,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'reached':reached,'reachedRawNode':node,'routeBoundaries':routes}
records={task:walk(entry,choices) for task,entry,choices in SPECS}
for task,row in records.items():row['officialTaskId']=task
Path('/tmp/flowchartcp-ioi2015-routes.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
old=json.loads((BASE/'data/problem-walks.json').read_text())
traces=[]
for row in old:
    trace=walk(row.get('entryGraphId','ranges'),row['choices'])
    assert [{k:s[k+'Id'] if k in ['graph','node'] else s[k] for k in ['graph','node','answer']} for s in trace['steps']]==row['steps']
    assert set(row['expectedTechniqueIds'])<=set(trace['reached']['techniques'])
    traces.append(trace)
Path('/tmp/flowchartcp-ioi2015-old-walk-traces.json').write_text(json.dumps({'recordCount':len(old),'fullRecordSha256':hashlib.sha256((BASE/'data/problem-walks.json').read_bytes()).hexdigest(),'records':traces},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:{'entry':v['entryGraphId'],'choices':v['choices'],'stop':v['reached']} for k,v in records.items()},ensure_ascii=False,indent=2))
