import assert from 'node:assert/strict';
import {readFile,writeFile,mkdtemp,rm} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
const root='/tmp/flowchartcp-ioi2015-baseline';
const prefix='/tmp/flowchartcp-ioi2015-snapshot-peer-';
const compiler=(await import(pathToFileURL(root+'/vendor/typescript.cjs'))).default;
const json=async file=>JSON.parse(await readFile(file,'utf8'));
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const stable=v=>Array.isArray(v)?v.map(stable):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,stable(v[k])])):v;
const digest=v=>hash(JSON.stringify(stable(v)));
const raw=await json(prefix+'raw-replay.json');
const walks=await json(root+'/data/problem-walks.json');
const dependencies=['src/lib/flow.ts','src/lib/flow-layout.ts','data/flows.json','vendor/typescript.cjs'];
const dependencyHashes=Object.fromEntries(await Promise.all(dependencies.map(async f=>[f,hash(await readFile(root+'/'+f))])));
const temporary=await mkdtemp(prefix+'runtime-');
try{
 await writeFile(temporary+'/package.json','{"type":"module"}\n');
 for(const name of ['flow-layout','flow']){
  const original=root+'/src/lib/'+name+'.ts';let source=await readFile(original,'utf8');
  const pattern=/import\s+(\w+)\s+from\s+['"]([^'"]+\.json)['"](?:\s+with\s*\{[^}]+\})?\s*;/g;
  for(const match of [...source.matchAll(pattern)]){
   const absolute=path.resolve(path.dirname(original),match[2]);assert(absolute.startsWith(root+'/data/'));
   source=source.replace(match[0],`const ${match[1]}=${await readFile(absolute,'utf8')};`);
  }
  source=compiler.transpileModule(source,{compilerOptions:{target:compiler.ScriptTarget.ES2022,module:compiler.ModuleKind.ESNext},fileName:original}).outputText;
  source=source.replace(/(from\s+['"])(\.\/?[^'"]+)(['"])/g,(_,a,b,c)=>a+b.replace(/\.ts$/,'').replace(/(?<!\.js)$/,'.js')+c);
  source=source.replace(/import\.meta\.env/g,'({BASE_URL:"/flowchartcp/"})');
  await writeFile(temporary+'/'+name+'.js',source);
 }
 const flow=await import(pathToFileURL(temporary+'/flow.js'));
 assert.deepEqual(flow.validateGraphs(),[]);
 assert.deepEqual(flow.graphs.filter(g=>g.entry===true).map(g=>g.id),raw.entryDomainIds);
 function actual(entry,choices){
  const value=flow.walkFromRoot(choices,entry);assert.equal(value.consumed,choices.length);
  return {
   steps:value.steps.map(step=>{const g=flow.getGraph(step.graph),n=flow.getNode(g,step.node),option=flow.getNodeOptions(n).find(o=>o.id===step.answer);return {graphId:step.graph,nodeId:step.node,question:n.title,answer:step.answer,answerLabel:option.label,target:step.target};}),
   reached:{graphId:value.graph.id,nodeId:value.current.id,type:value.current.type,title:value.current.title,options:flow.getNodeOptions(value.current),techniques:value.current.techniques??[],conditions:value.current.conditions??[]},
   consumed:value.consumed
  };
 }
 const comparable=value=>({steps:value.steps,reached:value.reached,consumed:value.consumed});
 for(let i=0;i<raw.entryDomainIds.length;++i){
  assert.deepEqual(actual(raw.entryDomainIds[i],[]),comparable(raw.entryRoots[i]));
  assert.equal(flow.getFlowDomainId(flow.initialState(raw.entryDomainIds[i])),raw.entryDomainIds[i]);
 }
 const old=[];
 for(let i=0;i<walks.length;++i){const row=walks[i],value=actual(row.entryGraphId,row.choices);assert.deepEqual(value,comparable(raw.oldWalks[i]));old.push(value);}
 const canonical={};for(const[id,row]of Object.entries(raw.sixCanonicalRoutes)){
  canonical[id]=actual(row.entryGraphId,row.choices);assert.deepEqual(canonical[id],comparable(row));
 }
 const result={status:'frozen-runtime-verified-only',fullSolutionPeerComplete:false,allOldWalks:walks.length,allOldSteps:old.reduce((s,v)=>s+v.steps.length,0),entryDomains:raw.entryDomainIds.length,canonicalRoutes:Object.keys(canonical).length,completeQuestionAnswerLabelTargetStopEquality:true,dependencyHashes,compilerFromLaterSeparateVendorEpoch:true,originalRawRuntimeUnchanged:true,allOldRuntimeReplaySha256:digest(old),sixCanonicalRuntimeReplaySha256:digest(canonical),sharedFilesEdited:false,authorArtifactsEdited:false};
 await writeFile(prefix+'runtime-results.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
}finally{await rm(temporary,{recursive:true,force:true});}
