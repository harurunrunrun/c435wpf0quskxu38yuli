#!/usr/bin/env python3
"""Extra mathematical comparisons only; no production API/C++/ASan claim."""
import collections,hashlib,importlib.util,itertools,json,math,pathlib,random,time
BASE='/tmp/flowchartcp-ioi2015-';PFX=BASE+'snapshot-peer-'
prototype=pathlib.Path(BASE+'probe.py')
assert hashlib.sha256(prototype.read_bytes()).hexdigest()=='f756589bc00604a8b627d06e0e3169e6b758c2790ce3d3806a44a599dfab4aa1'
spec=importlib.util.spec_from_file_location('frozen_ioi2015_research',prototype);author=importlib.util.module_from_spec(spec);spec.loader.exec_module(author)
rng=random.Random(720730);checks=0;checksum=0;prototype_calls=0
def need(a,b):
 global checks,checksum
 checks+=1
 assert a==b,(a,b)
 checksum=(checksum*1000003+int(a))%(1<<64)
def boxes_global(pos,k,L):
 # The state retains physical stock, delivered identities and current section.
 # Delivery/pickup cost0, one step cost1. No trip or interval decomposition.
 n=len(pos);k=min(k,n);full=(1<<n)-1;at=[0]*L
 for i,x in enumerate(pos):at[x]|=1<<i
 initial=(0,0,0);distance={initial:0};queue=collections.deque([initial])
 def relax(state,d,free):
  if d<distance.get(state,10**9):
   distance[state]=d
   (queue.appendleft if free else queue.append)(state)
 while queue:
  x,done,stock=queue.popleft();d=distance[x,done,stock]
  if x==0 and done==full:return d
  if x==0 and stock<k and stock<n-done.bit_count():relax((x,done,stock+1),d,True)
  unserved=at[x]&~done
  if stock:
   while unserved:
    bit=unserved&-unserved;unserved-=bit;relax((x,done|bit,stock-1),d,True)
  relax(((x+1)%L,done,stock),d+1,False);relax(((x-1)%L,done,stock),d+1,False)
 raise AssertionError('finite delivery state unreachable')
def boxes():
 global prototype_calls
 count=0;large_k=0
 for L in range(1,7):
  for n in range(1,5):
   for pos in itertools.combinations_with_replacement(range(L),n):
    for k in range(1,n+3):
     need(author.boxes_formula(pos,k,L),boxes_global(pos,k,L));prototype_calls+=1;count+=1;large_k+=k>n
 for _ in range(250):
  n=rng.randint(1,6);L=rng.randint(1,12);pos=sorted(rng.randrange(L) for _ in range(n));k=rng.randint(1,n+5)
  need(author.boxes_formula(pos,k,L),boxes_global(pos,k,L));prototype_calls+=1;count+=1;large_k+=k>n
 return {'physicalStockZeroOneBfsCases':count,'capacityGreaterThanTeamCountCases':large_k,'includesCircleOneAndDepotDuplicates':True}
def hall(intervals,ks):
 eligible=[sum(1<<i for i,(a,b) in enumerate(intervals) if a<=k<=b) for k in ks]
 masks=[0]*(1<<len(ks));demands=[0]*len(masks)
 for subset in range(1,len(masks)):
  bit=subset&-subset;i=bit.bit_length()-1;previous=subset^bit
  masks[subset]=masks[previous]|eligible[i];demands[subset]=demands[previous]+ks[i]
  if masks[subset].bit_count()<demands[subset]:return False
 return True
def teams():
 global prototype_calls
 count=0
 for n in range(1,4):
  options=list(itertools.combinations_with_replacement(range(1,n+1),2))
  for intervals in itertools.product(options,repeat=n):
   for m in range(1,n+1):
    for ks in itertools.product(range(1,n+1),repeat=m):
     need(author.teams_bulk(intervals,ks),hall(intervals,ks));prototype_calls+=1;count+=1
 for trial in range(2000):
  n=rng.randint(1,30);m=rng.randint(1,min(n,8));intervals=[sorted((rng.randint(1,n),rng.randint(1,n))) for _ in range(n)]
  ks=[rng.randint(1,n if trial%2 else min(n,4)) for _ in range(m)]
  need(author.teams_bulk(intervals,ks),hall(intervals,ks));prototype_calls+=1;count+=1
 return {'allTeamSubsetHallCases':count,'oracle':'Every subset of distinct requested teams must have at least its total seat demand in its eligible-student union; no greedy or student-assignment enumeration.'}
def exact_revenue(x,y):
 p=1;answer=0
 for a,b in zip(x,y):p*=a;answer=max(answer,p*b)
 return answer
def horses():
 global prototype_calls
 count=0;metamorphic=0
 for n in [29,30,31,32,60,61]:
  for special in [0,n//2,n-1]:
   for one_gap in [False,True]:
    x=[2]*n;y=[1]*n;y[special]=10**9
    if one_gap:x=[v if i%2 else 1 for i,v in enumerate(x)]
    need(author.horses_compressed(x,y,10**9),exact_revenue(x,y));prototype_calls+=1;count+=1
 # This boundary forbids dropping the first of 30 non-unit positions.
 x=[2]*30;y=[10**9]+[1]*29;need(exact_revenue(x,y),2*10**9);need(max(2**(i+1)*y[i] for i in range(1,30))<exact_revenue(x,y),True)
 for _ in range(1000):
  n=rng.randint(1,120);x=[rng.choice([1,1,2,3,10**9]) for _ in range(n)];y=[rng.randint(1,10**8) for _ in range(n)]
  answer=exact_revenue(x,y);need(author.horses_compressed(x,y,10**9),answer);prototype_calls+=1;count+=1
  scaled=[v*7 for v in y];need(author.horses_compressed(x,scaled,10**9),answer*7);prototype_calls+=1;metamorphic+=1
 return {'exactFullPrefixCases':count,'uniformPriceScalingCases':metamorphic,'thirtyNonunitBoundaryWitness':True}
def swap(a,i,j):
 a=list(a);a[i],a[j]=a[j],a[i];return tuple(a)
def sorting_literal(initial,enemy):
 n=len(initial);goal=tuple(range(n));states={initial}
 if initial==goal:return 0
 for time,(a,b) in enumerate(enemy,1):
  next_states=set()
  for old in states:
   disturbed=swap(old,a,b)
   for i in range(n):
    for j in range(i,n):next_states.add(swap(disturbed,i,j))
  states=next_states
  if goal in states:return time
 return None
def sorting():
 global prototype_calls
 count=0;unsatisfiable=0
 n=3;pairs=list(itertools.combinations_with_replacement(range(n),2))
 for length in range(5):
  for enemy in itertools.product(pairs,repeat=length):
   for initial in itertools.permutations(range(n)):
    exact=sorting_literal(initial,enemy);got=author.sorting_method(initial,enemy);need(-1 if got is None else got[0],-1 if exact is None else exact);prototype_calls+=1;count+=1;unsatisfiable+=exact is None
    if got is not None:
     state=initial
     for pair,own in zip(enemy,got[1]):state=swap(swap(state,*pair),*own)
     need(state==tuple(range(n)),True)
 for _ in range(1000):
  initial=list(range(4));rng.shuffle(initial);enemy=[(rng.randrange(4),rng.randrange(4)) for _ in range(4)];exact=sorting_literal(tuple(initial),enemy);got=author.sorting_method(tuple(initial),enemy)
  need(got[0],exact);prototype_calls+=1;count+=1
 return {'allSchedulesN3Length0to4AndRandomN4':count,'outsideGuaranteedDomainUnsolvableSchedules':unsatisfiable,'witnessesReplayed':True,'numericOriginalRangeStillUnconfirmed':True}
started=time.monotonic();results={}
for name in ['boxes','teams','horses','sorting']:results[name]=globals()[name]()
results.update({'kind':'additional-independent-mathematics-only','productionApiValidated':False,'cppFenceCompared':False,'asanClaimed':False,'sourceSortingScalesUnknownNotPromoted':True,'selectedPrototypeSha256':hashlib.sha256(prototype.read_bytes()).hexdigest(),'selectedPrototypeFunctionCalls':prototype_calls,'checks':checks,'checksum':str(checksum),'seconds':time.monotonic()-started})
pathlib.Path(PFX+'extra-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');print(json.dumps(results,ensure_ascii=False,indent=2))
