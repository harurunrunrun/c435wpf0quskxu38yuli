#!/usr/bin/env python3
"""Research-only Towns majority completion and literal weighted-tree oracle."""
from collections import Counter
from itertools import product
from pathlib import Path
import argparse,hashlib,json,random,time

counts=Counter();checksum=0
def need(condition,label):
    counts['checks']+=1
    if not condition:raise AssertionError(label)
def rec(value):
    global checksum
    checksum=(checksum*1000003+value)&((1<<64)-1)

def majority_group(items,total,equal):
    """Find a class containing >total/2 elements,where total>=len(items).

    Retain *all* homogeneous groups proved by equal candidate comparisons.
    Unlike balanced-round arbitrary odd-set deletion,this never guesses a
    majority-preserving discard. No original solution text is implemented.
    """
    m=len(items);need(total>=m,'global size contains tested subset')
    if 2*m<=total:return False,{'m':m,'R':0,'E':0,'U':0,'f':0,'comparisons':0,'verification':0,'groups':m}
    groups={};candidate=None;balance=0;R=E=U=C=0
    def compare(a,b):
        nonlocal C
        C+=1
        return equal(a,b)
    for item in items:
        groups[item]=1
        if balance==0:candidate=item;balance=1;R+=1
        elif compare(candidate,item):
            groups[candidate]+=groups.pop(item);balance+=1;E+=1
        else:balance-=1;U+=1
    need(m==R+E+U and balance==R+E-U,'candidate accounting identities')
    need(C==m-R and len(groups)==m-E,'query and homogeneous-component accounting')
    if balance==0:
        need(2*C<=3*m,'zero-balance candidate cost')
        return False,{'m':m,'R':R,'E':E,'U':U,'f':0,'comparisons':C,'verification':0,'groups':len(groups)}
    size=groups[candidate];before=C
    for representative,weight in groups.items():
        if representative!=candidate and compare(candidate,representative):size+=weight
    verification=C-before
    need(verification==m-E-1,'verify every other known-homogeneous group once')
    need(2*C==3*m-balance-2,'exact <1.5m comparison identity')
    need(2*C<3*m,'strict1.5m bound')
    return 2*size>total,{'m':m,'R':R,'E':E,'U':U,'f':balance,'comparisons':C,'verification':verification,'groups':len(groups)}

def partitions(n):
    values=[0]*n
    def visit(index,largest):
        if index==n:yield tuple(values);return
        for color in range(largest+2):
            values[index]=color
            yield from visit(index+1,max(largest,color))
    if not n:yield ();return
    yield from visit(1,0)

def partition_checks(maximum):
    for n in range(maximum+1):
        local=0
        for labels in partitions(n):
            local+=1;counts['equivalencePartitions']+=1
            for total in range(max(1,n),n+5):
                actual,trace=majority_group(list(range(n)),total,lambda a,b:labels[a]==labels[b])
                expected=any(2*size>total for size in Counter(labels).values())
                need(actual==expected,'literal class count versus candidate/groups')
                counts['partitionThresholdInstances']+=1
                counts['logicalEqualityComparisons']+=trace['comparisons']
                counts['maximumEqualityComparisons']=max(counts['maximumEqualityComparisons'],trace['comparisons'])
                rec(actual)
        counts['partitionsN'+str(n)]=local
    # The literal ambiguity reported in the official equal-size round prose:
    # arbitrary odd deletion can removeA fromA,A,B,then cancelA/B toempty.
    original=(0,0,1);remaining=list(original);remaining.pop(0)
    survivors=[]
    for a,b in zip(remaining[::2],remaining[1::2]):
        if a==b:survivors.append(a)
    need(not survivors and Counter(original)[0]==2,'literal arbitrary odd discard counterexample')
    counts['officialLiteralOddDiscardCounterexamples']=1

def tree_from_prufer(sequence,n):
    degree=[1]*n
    for node in sequence:degree[node]+=1
    if any(value==2 for value in degree):return None
    edges=[]
    for node in sequence:
        leaf=next(i for i,value in enumerate(degree)if value==1)
        edges.append((leaf,node));degree[leaf]-=1;degree[node]-=1
    a,b=(i for i,value in enumerate(degree)if value==1);edges.append((a,b))
    return edges

def distance_matrix(n,edges,weights):
    graph=[[]for _ in range(n)]
    for (a,b),w in zip(edges,weights):graph[a].append((b,w));graph[b].append((a,w))
    distances=[]
    for source in range(n):
        row=[-1]*n;row[source]=0;stack=[source]
        while stack:
            a=stack.pop()
            for b,w in graph[a]:
                if row[b]<0:row[b]=row[a]+w;stack.append(b)
        distances.append(row)
    return graph,distances

def check_tree(n,edges,weights,leaf_order=None,source_scope=False):
    graph,distances=distance_matrix(n,edges,weights)
    leaves=[i for i in range(n)if len(graph[i])==1]
    if leaf_order is not None:leaves=[leaves[i]for i in leaf_order]
    towns=len(leaves);cache={};calls=0
    def query(i,j):
        nonlocal calls
        need(0<=i<towns and 0<=j<towns,'distance query legal towns')
        if i==j:return 0
        key=tuple(sorted((i,j)))
        if key not in cache:cache[key]=distances[leaves[i]][leaves[j]];calls+=1
        return cache[key]
    v=0;dv=[query(v,u)for u in range(towns)];s=max(range(towns),key=dv.__getitem__)
    ds=[query(s,u)for u in range(towns)];D=max(ds)
    need(calls==2*towns-3,'cached two-star diameter phase exactly2N-3')
    projection=[]
    for u in range(towns):
        twice=ds[u]+dv[s]-dv[u];need(twice%2==0,'integer vertex projection')
        projection.append(twice//2)
    coordinates=sorted({b for b in projection if 0<b<dv[s]})
    need(bool(coordinates),'degree>=3 internal vertex on leaf-to-leaf path')
    radius=min(max(r,D-r)for r in coordinates)
    candidates=[r for r in coordinates if max(r,D-r)==radius]
    need(len(candidates)<=2,'atmosttwo discrete centers')
    balanced=False;majority_calls=0
    for r in candidates:
        if 2*sum(b<r for b in projection)>towns or 2*sum(b>r for b in projection)>towns:continue
        group=[u for u,b in enumerate(projection)if b==r]
        if 2*len(group)<=towns:balanced=True;break
        majority_calls+=1
        need(majority_calls<=1,'disjoint projection classes:atmostone >N/2')
        def same_branch(a,b):
            return ds[a]+ds[b]-query(a,b)>2*r
        giant,trace=majority_group(group,towns,same_branch)
        counts['treeMajorityLogicalComparisons']+=trace['comparisons']
        if not giant:balanced=True;break
    answer=radius if balanced else -radius
    # Literal truth examines every actual large city and removes it in the
    # explicit adjacency tree;no diameter endpoints,projections or majority.
    eccentricities={city:max(distances[city][leaf]for leaf in leaves)for city in range(n)if len(graph[city])>=3}
    literal_radius=min(eccentricities.values());literal_balanced=False
    for city,eccentricity in eccentricities.items():
        if eccentricity!=literal_radius:continue
        sizes=[]
        for start,_ in graph[city]:
            stack=[(start,city)];size=0
            while stack:
                a,parent=stack.pop();size+=len(graph[a])==1
                for b,_ in graph[a]:
                    if b!=parent:stack.append((b,a))
            sizes.append(size)
        literal_balanced|=2*max(sizes)<=towns
    need(answer==(literal_radius if literal_balanced else-literal_radius),'full distance-only signed radius versus every literal city/removal')
    need(2*calls<=7*towns,'all real oracle queries <=3.5N')
    need(calls<=2*towns-3+max(0,(3*(towns-2)-1)//2-1),'independent stronger total bound')
    counts['weightedTreeInstances']+=1;counts['treeDistanceQueries']+=calls;counts['twoCenterInstances']+=len(candidates)==2;counts['treeMajorityInvocations']+=majority_calls
    counts['maxTownCount']=max(counts['maxTownCount'],towns)
    counts['maxActualQueries']=max(counts['maxActualQueries'],calls)
    if towns>=6:
        need(towns<=110 and max(max(row)for row in distances)<=1000000,'source numeric scope for tagged instance')
        counts['originalScopeTreeInstances']+=1
    if source_scope:need(6<=towns<=110,'random explicitly original scope')
    rec(answer)

def tree_checks(max_vertices):
    for n in range(4,max_vertices+1):
        for sequence in product(range(n),repeat=n-2):
            edges=tree_from_prufer(sequence,n)
            if edges is None:continue
            counts['allLabelledTreeShapes']+=1
            check_tree(n,edges,[1]*(n-1))
            if n<=7:
                for bits in product((1,2),repeat=n-1):
                    check_tree(n,edges,bits)
                    counts['allBinaryEdgeWeightInstances']+=1
    rng=random.Random(20150730)
    for case in range(600):
        target=6+case%105;graph=[{1,2,3},{0},{0},{0}]
        leaves={1,2,3}
        while len(leaves)<target:
            if rng.randrange(3):
                leaf=rng.choice(sorted(leaves));parent=next(iter(graph[leaf]));middle=len(graph);new=middle+1
                graph.append({parent,leaf,new});graph.append({middle});graph[parent].remove(leaf);graph[parent].add(middle);graph[leaf]={middle};leaves.add(new)
            else:
                city=rng.choice([i for i,row in enumerate(graph)if len(row)>=3]);new=len(graph);graph.append({city});graph[city].add(new);leaves.add(new)
        edges=[(a,b)for a,row in enumerate(graph)for b in row if a<b];weights=[rng.randrange(1,101)for _ in edges]
        order=list(range(target));rng.shuffle(order)
        check_tree(len(graph),edges,weights,order,True);counts['randomOriginalTreeInstances']+=1

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',default='/tmp/flowchartcp-ioi2015-towns-peer-results.json');ap.add_argument('--max-partition',type=int,default=10);ap.add_argument('--max-vertices',type=int,default=8);args=ap.parse_args()
    start=time.monotonic();partition_checks(args.max_partition);tree_checks(args.max_vertices)
    result={'status':'passed','scope':'independent supplement only;not complete IOI2015 audit peer review','chosenMethod':'Boyer-Moore candidate with retained equal-comparison homogeneous groups and weighted verification','officialOddDiscardLiteralClaimVerified':False,'counts':dict(counts),'checksum':str(checksum),'seconds':time.monotonic()-start,'maxPartition':args.max_partition,'maxExplicitTreeVertices':args.max_vertices,'queryGuarantee':'at most2N-3 initial distance queries;at mostone projection class m>N/2 needs majority;C=(3m-f)/2-1 when f>0 andno verification if f=0;total<3.5N','productionApiValidated':False,'sharedOrAuthorArtifactsModified':False}
    text=json.dumps(result,ensure_ascii=False,indent=2)+'\n';Path(args.output).write_text(text);print(text,end='')
if __name__=='__main__':main()
