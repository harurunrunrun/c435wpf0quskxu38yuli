"""Compile frozen existing fences and test their own stated components.
These checks establish scope, not coverage of any IOI2015 task.
"""
from pathlib import Path
import hashlib,json,re,subprocess,tempfile,time
BASE=Path('/tmp/flowchartcp-ioi2015-baseline')
CASES={
'heuristic-precedence-two-opt':'PrecedenceTour t({{1,0},{2,0},{0,0}},{2,0,1,2});assert(!t.reversal_delta(1,3));assert(t.reversal_delta(1,2).value()==0);',
'median-window-budget':'assert(maximum_gathered_points({0,4,5},1)==2);',
'optional-booster-subset-speed':'assert(fabsl(minimum_boosted_tour({{3,4}},{} )-10)<1e-12L);',
'interactive':'std::istringstream input("7");std::ostringstream output;auto *a=std::cin.rdbuf(input.rdbuf()),*b=std::cout.rdbuf(output.rdbuf());int used=0;assert(ask_interval(1,4,used,1)==7);assert(used==1);std::cin.rdbuf(a);std::cout.rdbuf(b);assert(output.str()=="? 1 4\\n");',
'interactive-bit-group-testing':'auto a=binary_test_groups(6);assert(a.size()==3);assert(decode_binary_test(6,"101")==5);',
'interactive-transition-count-species-decision-trees':'std::vector<int> hidden{0,1,0,1,1,0};auto a=count_two_species_from_transition_queries(6,[&](std::vector<int> q){int r=0;for(size_t i=1;i<q.size();++i)r+=hidden[q[i-1]]!=hidden[q[i]];return r;});assert(a.count_a==3&&a.queries<=226);',
'persistent-segment-tree':'PersistentSum t(4);auto a=t.add(0,1,3),b=t.add(a,2,5);assert(t.sum(0,0,4)==0&&t.sum(a,0,4)==3&&t.sum(b,1,3)==8);',
'persistent-prefix-kth':'PrefixKth t({3,1,3,2});assert(t.kth(1,4,1)==2);',
'matching':'auto m=bipartite_match({{0,1},{0}},2);assert(m[0]>=0&&m[1]>=0&&m[0]!=m[1]);',
'threshold-coupon-max-discount':'assert(minimum_coupon_cost({5,7},{{4,3},{7,5}})==4);',
'segment-tree':'auto op=[](long long a,long long b){return a+b;};SegmentTree t(std::vector<long long>{1,2,3},0LL,op);assert(t.prod(0,3)==6);t.set(1,9);assert(t.prod(0,3)==13);',
'maximum-product-sign-exchange':'assert(maximum_product_mod({-5,-2,3},2)==10);',
'point-update-nonadjacent-max-sum':'NonadjacentSum t({4,7,4});assert(t.maximum_all()==8);t.set(1,20);assert(t.maximum_all()==20);',
'permutation-cycle-minimum-swaps':'std::vector<int> p{1,2,0};auto ops=sort_permutation_swaps(p);assert(ops.size()==2);for(auto [a,b]:ops)std::swap(p[a],p[b]);assert((p==std::vector<int>{0,1,2}));',
'simultaneous-swap-parity':'assert(!can_match_by_shared_index_swaps({1,2,3},{2,1,3}));assert(can_match_by_shared_index_swaps({1,1,2},{2,1,1}));',
'binary-search':'assert(first_true(0,10,[](long long x){return x>=7;})==7);',
'interactive-tree-diameter':'int c=0;auto a=diameter_from_distance_queries(6,[&](int i,int j){++c;return i==j?0LL:2LL;},10);assert(a==2&&c==10);',
'tree-eccentricity-diameter-endpoints':'auto e=tree_eccentricities(4,{{0,1,1},{0,2,1},{0,3,1}});assert((e==std::vector<long long>{1,2,2,2}));',
'centroid-count-cross-subtrees':'assert(count_pairs_at_distance({{1,2,3},{0},{0},{0}},2)==3);'
}
GAPS={
'heuristic-precedence-two-opt':'受取・配達の先行制約を保つ局所改善であり、積載K/円周/厳密最短の三種trip分解を持たない。',
'median-window-budget':'固定個数を中央値に集める線上距離和で、補充点に戻る容量Kの巡回とは目的も費用も違う。',
'optional-booster-subset-speed':'任意加速点付き小集合巡回であり、指数時間・必須点12個のAPI。円上大量重複配送の全域を含まない。',
'interactive':'質問形式とflushの一般説明で、硬貨の120合法質問や6深さ保証を構成しない。',
'interactive-bit-group-testing':'任意部分集合に対する二値所属を要求し、三硬貨のmin/median/maxとnextLightestしか使えない原典で質問を実行できない。',
'interactive-transition-count-species-decision-trees':'二値配置の隣接変化回数と既知anchorを用いる別オラクル。硬貨の全順列・合法質問120個・6問を扱わない。',
'persistent-segment-tree':'一点加算/区間和の部品だけ。二次元の適格学生頻度から当日使用済み頻度を引き、最小Bを一括消費する操作がない。',
'persistent-prefix-kth':'固定配列の二prefix差のk番目を返す。各queryでサイズ順に需要k人を消費する別used版と交換証明がない。',
'matching':'明示二部グラフのKuhn O(VE)。需要を席へ展開すると辺が二乗になり、50万人と多数独立日queryを包含しない。',
'threshold-coupon-max-discount':'一方向lowerのみの入れ子適格集合。学生のupper Bとteam size分の需要を持たない。',
'segment-tree':'任意の結合則の部品。max prefix product times priceの比較には巨大整数順序/切詰めとmod積を区別する新要約が必要。',
'maximum-product-sign-exchange':'自由なK個を静的に選ぶ符号交換で、正のprefix積×その末尾価格の動的選択とは異なる。',
'point-update-nonadjacent-max-sum':'加算max-plusの非隣接部分列。正整数prefix積の正確な大小とmodulo出力を扱わない。',
'permutation-cycle-minimum-swaps':'相手の既知位置交換が割り込まない静的順列のみ。必要round判定と値交換/位置交換の可換性による再配置がない。',
'simultaneous-swap-parity':'二列に三相異なるindexを使う同期交換の可否。任意位置交換の既知外乱列や最短round witnessではない。',
'binary-search':'境界探索の部品で、外乱prefix後のN-cyclecount<=tという判定と操作再生の正当性を持たない。',
'interactive-tree-diameter':'隠れ木のdiameterだけ。葉だけを質問し、未知内点の離散hubを復元してleaf component過半数を検査する手順がない。',
'tree-eccentricity-diameter-endpoints':'明示全頂点・全辺を要求するAPIで、未知内部都市や3.5N葉間質問budgetを扱わない。',
'centroid-count-cross-subtrees':'既知隣接木で距離Kの頂点対を数える。未知内点からのleaf balanceとは観測/出力が異なる。'
}
def main():
 metadata={}
 for path in BASE.glob('data/techniques*.json'):
  for row in json.loads(path.read_text()):
   if row['id'] in CASES:metadata[row['id']]={'path':str(path.relative_to(BASE)),'fileSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'row':row}
 results=[];start=time.monotonic()
 with tempfile.TemporaryDirectory(prefix='flowchartcp-ioi2015-scope-') as tmp:
  for ident,test in CASES.items():
   path=BASE/'src/content/docs/techniques'/f'{ident}.mdx';raw=path.read_bytes();text=raw.decode();fences=re.findall(r'```(?:cpp|c\+\+)\s*\n(.*?)```',text,re.S);assert fences
   code='\n'.join(fences);source=Path(tmp)/f'{ident}.cpp';binary=Path(tmp)/ident
   source.write_text('#include <bits/stdc++.h>\n'+code+'\nint main(){'+test+'}\n')
   subprocess.run(['g++','-std=c++20','-O2',str(source),'-o',str(binary)],check=True,capture_output=True)
   subprocess.run([str(binary)],check=True,capture_output=True)
   results.append({'techniqueId':ident,'articlePath':str(path.relative_to(BASE)),'articleSha256':hashlib.sha256(raw).hexdigest(),'readFullArticleAndAllCppFences':True,'cppFences':len(fences),'combinedCppSha256':hashlib.sha256(code.encode()).hexdigest(),'metadata':metadata[ident],'componentCheck':test,'componentCompiledAndExecuted':True,'fullIOI2015Coverage':False,'verifiedScopeDifference':GAPS[ident]})
 result={'frozenEpoch':511,'nearestArticles':len(results),'allFullMdxAndAllCppFencesRead':True,'onlyOwnComponentChecks':True,'productionIOI2015ApiVerified':0,'semanticMatchAloneNeverCoverage':True,'elapsedSeconds':time.monotonic()-start,'records':results}
 Path('/tmp/flowchartcp-ioi2015-scope-checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'nearestArticles':len(results),'allComponentsCompiledAndExecuted':True,'elapsedSeconds':result['elapsedSeconds']}))
if __name__=='__main__':main()
