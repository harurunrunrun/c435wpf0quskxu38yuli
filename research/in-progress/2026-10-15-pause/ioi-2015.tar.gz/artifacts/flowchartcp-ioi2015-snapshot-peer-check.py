#!/usr/bin/env python3
"""Independent early selection/snapshot review, not a complete solution review."""
import datetime,hashlib,json,pathlib
PREFIX='/tmp/flowchartcp-ioi2015-snapshot-peer-'
ROOT=pathlib.Path('/tmp/flowchartcp-ioi2015-baseline')
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(pathlib.Path(p).read_text())
def digest(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
manifest=read('/tmp/flowchartcp-ioi2015-manifest.json')
selection=read('/tmp/flowchartcp-ioi2015-selection.json')
vendor=read('/tmp/flowchartcp-ioi2015-vendor-manifest.json')
assert sha('/tmp/flowchartcp-ioi2015-selection.json')=='59b8335b6974a7158b85b67a69ab350d6a38aa80ddffaa8b917289c33b4cfe16'
assert sha('/tmp/flowchartcp-ioi2015-manifest.json')=='0a91e9dc6ab00b503599d321b7ede775d1a6474acc304b1391786f8a89399fd0'
assert sha(ROOT/'selection-original.json')==manifest['selectionSha256']==sha('/tmp/flowchartcp-ioi2015-selection.json')
assert sha(ROOT/'manifest.json')==sha('/tmp/flowchartcp-ioi2015-manifest.json')
assert [r['officialTaskId'] for r in selection['records']]==['boxes','scales','teams','horses','sorting','towns']
assert selection['fixedProblemCount']==6 and selection['fixedBeforeTechniqueSearch'] and not selection['semanticTechniqueSearchStarted']
assert selection['practiceExcluded']
for i,row in enumerate(selection['records']):
 assert row['problemId']=='ioi2015_'+row['officialTaskId']
 assert row['day']==(1 if i<3 else 2)
 assert row['date']==('2015-07-28' if i<3 else '2015-07-30')
 assert row['datePrecision']=='day' and row['exactDateVerified'] and row['difficulty'] is None
for a,b in [(selection['selectedAt'],manifest['frozenAt']),(manifest['frozenAt'],vendor['frozenAt'])]:
 assert datetime.datetime.fromisoformat(a)<datetime.datetime.fromisoformat(b)
hashes=manifest['fullRawHashes']
for name in ['hashes-before.json','hashes-after.json','hashes-copied.json']:assert read(ROOT/name)==hashes
ledger={line.split('  ',1)[1]:line.split('  ',1)[0] for line in (ROOT/'SHA256SUMS').read_text().splitlines()}
assert ledger==hashes and sha(ROOT/'SHA256SUMS')==manifest['ledgerSha256']
def validate_files(hashes):
 for relative,expected in hashes.items():
  rel=pathlib.PurePosixPath(relative)
  assert not rel.is_absolute() and '..' not in rel.parts
  assert not any(part.startswith('.env') for part in rel.parts),'forbidden path must never be opened'
  file=ROOT/relative
  assert not file.is_symlink() and file.is_file()
  assert sha(file)==expected,relative
validate_files(hashes)
assert vendor['separateDependencyEpoch'] and vendor['initialRawEpochUnchanged'] and vendor['beforeEqualsAfterEqualsCopied']
assert vendor['fileCount']==len(vendor['hashes'])==105
assert all(p.startswith('vendor/') for p in vendor['hashes'])
assert set(hashes).isdisjoint(vendor['hashes'])
validate_files(vendor['hashes'])
assert manifest['vendorCompilerCopied'] is False
actual=set()
for directory in ['data','src','scripts','tests','public']:
 for file in (ROOT/directory).rglob('*'):
  if file.is_file():
   relative=file.relative_to(ROOT).as_posix();assert not any(p.startswith('.env') for p in file.relative_to(ROOT).parts);actual.add(relative)
actual.update(['.gitignore','README.md','astro.config.mjs','package.json','tsconfig.json'])
assert actual==set(hashes)
flows=read(ROOT/'data/flows.json');walks=read(ROOT/'data/problem-walks.json')
metadata=[r for p in hashes if p.startswith('data/techniques-') and p.endswith('.json') for r in read(ROOT/p)]
references=[r for p in hashes if p.startswith('data/references-') and p.endswith('.json') for r in read(ROOT/p)]
counts={'allTechniqueMdx':sum(p.startswith('src/content/docs/techniques/') and p.endswith('.mdx') for p in hashes),'metadataRecords':len(metadata),'referenceRecords':len(references),'flowcharts':len(flows),'nodes':sum(len(g['nodes']) for g in flows),'walks':len(walks),'oldCorpusAudits':sum(p.startswith('data/corpus-audits/') and p.endswith('.json') for p in hashes),'publicRawFiles':sum(p.startswith('public/') for p in hashes),'rawFileCount':len(hashes)}
assert counts==manifest['rawCounts']=={'allTechniqueMdx':511,'metadataRecords':511,'referenceRecords':532,'flowcharts':478,'nodes':3739,'walks':532,'oldCorpusAudits':10,'publicRawFiles':479,'rawFileCount':1468}
assert 'data/corpus-audits/ioi-2015.json' not in hashes
assert not any(r['id']=='precompiled-permutation-partition-signature-membership' or r['id']=='fixed-run-row-prefix-suffix-feasibility-forced-colors' for r in metadata)
roots=[g['id'] for g in flows if g.get('entry') is True]
assert roots==['ranges','dp','graphs','flow-matching','strings','math','geometry','game-probability','thinking','heuristic','condition-check','set-operations','interactive-oracles','grid-arrangements','fixed-output']
by={g['id']:g for g in flows};labels={'yes':'はい','no':'いいえ','unknown':'わからない'}
def options(n):return n.get('options',[{'id':a,'label':labels.get(a,a)} for a in n.get('answers',{})])
def replay(entry,choices):
 g=by[entry];n=next(v for v in g['nodes'] if v['id']==g['root']);steps=[];routes=[];seen=set();at=0
 for _ in range(1000):
  if n['type']=='route':
   route=g['id']+'/'+n['id'];assert route not in seen;seen.add(route);routes.append(route)
   g=by[n['graph']];n=next(v for v in g['nodes'] if v['id']==g['root']);continue
  if n['type']!='question' or at==len(choices):break
  answer=choices[at];consume=True
  if n['id']==g['root'] and not any(o['id']==answer for o in options(n)) and answer in g.get('legacyEntryChoices',{}):
   answer=g['legacyEntryChoices'][answer]['answer'];consume=False
  option=next(o for o in options(n) if o['id']==answer);target=n['answers'][answer]
  steps.append({'graphId':g['id'],'nodeId':n['id'],'question':n['title'],'answer':answer,'answerLabel':option['label'],'target':target})
  n=next(v for v in g['nodes'] if v['id']==target);at+=int(consume)
 else:raise AssertionError('raw walk failed to terminate')
 return {'steps':steps,'reached':{'graphId':g['id'],'nodeId':n['id'],'type':n['type'],'title':n['title'],'options':options(n),'techniques':n.get('techniques',[]),'conditions':n.get('conditions',[])},'routeBoundaries':routes,'consumed':at}
old=[]
for row in walks:
 value=replay(row['entryGraphId'],row['choices']);assert value['consumed']==len(row['choices'])
 assert [{'graph':s['graphId'],'node':s['nodeId'],'answer':s['answer']} for s in value['steps']]==row['steps']
 assert set(row['expectedTechniqueIds'])<=set(value['reached']['techniques'])
 old.append(value)
author_routes=read('/tmp/flowchartcp-ioi2015-routes.json');new={}
for task,row in author_routes.items():
 value=replay(row['entryGraphId'],row['choices'])
 assert value['steps']==row['steps'] and value['reached']==row['reached'] and value['routeBoundaries']==row['routeBoundaries']
 assert digest(value['steps'])==row['stepsSha256']
 new[task]={'entryGraphId':row['entryGraphId'],'choices':row['choices'],**value}
result={'entryDomainIds':roots,'entryRoots':[replay(r,[]) for r in roots],'oldWalks':old,'sixCanonicalRoutes':new}
pathlib.Path(PREFIX+'raw-replay.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
summary={'status':'selection-and-snapshot-verified-only','fullSolutionPeerComplete':False,'counts':counts,'initialCoreEpoch':manifest['frozenAt'],'selectionDeclaredEpoch':selection['selectedAt'],'laterVendorEpoch':vendor['frozenAt'],'allBeforeAfterCopiedHashMapsEqual':True,'all1468RawBytesVerified':True,'all105VendorBytesVerifiedSeparately':True,'ledgerPath':str(ROOT/'SHA256SUMS'),'ledgerSha256':sha(ROOT/'SHA256SUMS'),'manifestSha256':sha('/tmp/flowchartcp-ioi2015-manifest.json'),'selectionSha256':sha('/tmp/flowchartcp-ioi2015-selection.json'),'vendorManifestSha256':sha('/tmp/flowchartcp-ioi2015-vendor-manifest.json'),'all532WalksFullRawReplaySha256':digest(old),'all532Steps':sum(len(v['steps']) for v in old),'allSixCanonicalStopsAndLabelsMatchAuthor':True,'entryDomainIds':roots,'rawReplayFile':PREFIX+'raw-replay.json','rawReplaySha256':sha(PREFIX+'raw-replay.json'),'sharedFilesEdited':False,'authorArtifactsEdited':False,'forbiddenEnvRead':False}
pathlib.Path(PREFIX+'check-results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
