#include <bits/stdc++.h>
using namespace std;
namespace t0 {
#include <vector>
#include <cassert>
using namespace std;
long long count_sum_at_most(const vector<long long>& a,long long limit) {
    for(long long x:a) assert(x>=0);
    if(limit<0) return 0;
    long long sum=0, ans=0;
    int l=0;
    for(int r=0;r<int(a.size());++r) {
        sum+=a[r];
        while(l<=r && sum>limit) sum-=a[l++];
        ans+=r-l+1;
    }
    return ans;
}

}
namespace t1 {
#include <bits/stdc++.h>
using namespace std;
void shift_or_sum(vector<unsigned long long>& bits,int value,int limit){
    assert(value>=0 && limit>=0);if(value>limit)return;
    int words=value/64,shift=value%64;
    for(int i=(int)bits.size()-1;i>=words;--i){
        unsigned long long moved=bits[i-words]<<shift;
        if(shift && i>words)moved|=bits[i-words-1]>>(64-shift);
        bits[i]|=moved;
    }
    int remainder=(limit+1LL)%64;
    if(remainder)bits.back()&=(1ULL<<remainder)-1;
}
vector<unsigned long long> subset_sum_bits(const vector<int>& values,int limit){
    assert(limit>=0);
    vector<unsigned long long> bits(limit/64+1);bits[0]=1;
    for(int value:values)shift_or_sum(bits,value,limit);
    return bits;
}

}
namespace t2 {
#include <vector>
#include <algorithm>
#include <cassert>
using namespace std;
struct Item { int weight; long long value; };
vector<long long> knapsack_exact(const vector<Item>& items,int capacity) {
    assert(capacity>=0);
    const long long NEG=-(1LL<<60);
    vector<long long> dp(capacity+1,NEG);
    dp[0]=0;
    for(auto [w,v]:items) {
        assert(w>=0);
        for(int x=capacity;x>=w;--x)
            if(dp[x-w]!=NEG) dp[x]=max(dp[x],dp[x-w]+v);
    }
    return dp;
}

}
namespace t3 {
#include <vector>
#include <utility>
#include <optional>
#include <algorithm>
std::optional<std::vector<int>> directed_euler_path(int n,const std::vector<std::pair<int,int>>& edges,int s,int t) {
    std::vector<std::vector<int>> g(n);std::vector<int> balance(n),next(n);
    for(auto [a,b]:edges) {g[a].push_back(b);++balance[a];--balance[b];}
    for(int v=0;v<n;++v) {
        int wanted=(v==s?1:0)-(v==t?1:0);
        if(balance[v]!=wanted) return std::nullopt;
    }
    std::vector<int> stack{s},answer;
    while(!stack.empty()) {
        int v=stack.back();
        if(next[v]<int(g[v].size())) stack.push_back(g[v][next[v]++]);
        else {answer.push_back(v);stack.pop_back();}
    }
    if(answer.size()!=edges.size()+1) return std::nullopt;
    std::reverse(answer.begin(),answer.end());
    if(answer.back()!=t) return std::nullopt;
    return answer;
}

}
namespace t4 {
#include <utility>
#include <vector>
using Graph01 = std::vector<std::vector<std::pair<int, int>>>;
Graph01 group_hubs(int n, const std::vector<std::vector<int>>& groups) {
    Graph01 graph(n + groups.size());
    for (int i = 0; i < int(groups.size()); ++i) {
        int hub = n + i;
        for (int member : groups[i]) {
            graph[member].push_back({hub, 0});
            graph[hub].push_back({member, 1});
        }
    }
    return graph;
}

}
namespace t5 {
#include <numeric>
#include <cassert>
using namespace std;
template<class Predicate>
long long first_true(long long lo, long long hi, Predicate good) {
    assert(lo<=hi);
    while(lo<hi) {
        long long mid=midpoint(lo,hi); // C++20: overflow-safe
        if(good(mid)) hi=mid;
        else lo=mid+1;
    }
    return lo;
}

}
namespace t6 {
#include <bits/stdc++.h>
using namespace std;
__int128 maximum_manhattan_distance(const vector<pair<long long,long long>>& points){
    if(points.empty())return 0;
    __int128 u0=(__int128)points[0].first+points[0].second;
    __int128 v0=(__int128)points[0].first-points[0].second;
    __int128 ulo=u0,uhi=u0,vlo=v0,vhi=v0;
    for(auto [x,y]:points){
        __int128 u=(__int128)x+y,v=(__int128)x-y;
        ulo=min(ulo,u);uhi=max(uhi,u);vlo=min(vlo,v);vhi=max(vhi,v);
    }
    return max(uhi-ulo,vhi-vlo);
}

}
namespace t7 {
#include <bits/stdc++.h>
using namespace std;
vector<long long> tree_eccentricities(int n,const vector<tuple<int,int,long long>>& edges) {
    assert(1<=n && n<=200000 && int(edges.size())==n-1);
    vector<vector<pair<int,long long>>> g(n);
    for(auto [u,v,w]:edges) {
        assert(0<=u && u<n && 0<=v && v<n && 0<=w && w<=1000000000);
        g[u].push_back({v,w});g[v].push_back({u,w});
    }
    auto distances=[&](int start) {
        vector<long long> d(n);
        vector<int> parent(n,-2),order{start};parent[start]=-1;
        for(size_t i=0;i<order.size();++i) {
            int v=order[i];
            for(auto [u,w]:g[v]) if(u!=parent[v]) {
                assert(parent[u]==-2);parent[u]=v;d[u]=d[v]+w;order.push_back(u);
            }
        }
        assert(int(order.size())==n);return d;
    };
    auto first=distances(0);
    int a=max_element(first.begin(),first.end())-first.begin();
    auto from_a=distances(a);
    int b=max_element(from_a.begin(),from_a.end())-from_a.begin();
    auto from_b=distances(b);
    for(int v=0;v<n;++v) from_a[v]=max(from_a[v],from_b[v]);
    return from_a;
}

}
namespace t8 {
#include <array>
#include <queue>
#include <vector>
std::vector<std::array<int, 2>> parity_bfs(
    const std::vector<std::vector<int>>& g, const std::vector<bool>& marked,
    int start, int startParity = 0) {
    std::vector<std::array<int, 2>> distance(g.size(), {-1, -1});
    std::queue<std::pair<int, int>> queue;
    distance[start][startParity] = 0; queue.push({start, startParity});
    while (!queue.empty()) {
        auto [v, p] = queue.front(); queue.pop();
        for (int u : g[v]) {
            int next = p ^ int(marked[u]);
            if (distance[u][next] != -1) continue;
            distance[u][next] = distance[v][p] + 1;
            queue.push({u, next});
        }
    }
    return distance;
}

}
namespace t9 {
#include <cstdlib>
#include <iostream>
int ask_interval(int left, int right, int& used, int budget) {
    if (used >= budget) std::exit(0);
    ++used;
    std::cout << "? " << left << ' ' << right << '\n' << std::flush;
    int reply;
    if (!(std::cin >> reply) || reply == -1) std::exit(0);
    return reply;
}

}
namespace t10 {
#include <bits/stdc++.h>
using namespace std;
vector<vector<int>> binary_test_groups(int n){
    assert(1<=n && n<=100);int m=0;while((1<<m)<n)++m;
    vector<vector<int>> groups(m);
    for(int b=0;b<m;++b)for(int x=0;x<n;++x)if(x>>b&1)groups[b].push_back(x);
    return groups;
}
int decode_binary_test(int n,const string& response){
    assert(1<=n && n<=100);int m=0;while((1<<m)<n)++m;
    if(response.size()!=size_t(m))throw invalid_argument("invalid response length");
    int value=0;
    for(int b=0;b<(int)response.size();++b){
        if(response[b]!='0' && response[b]!='1')throw invalid_argument("invalid response bit");
        if(response[b]=='1')value|=1<<b;
    }
    if(value>=n)throw invalid_argument("invalid candidate");
    return value;
}
void solve_binary_test_protocol(){
    int n;if(!(cin>>n))return;
    auto groups=binary_test_groups(n);cout<<groups.size()<<endl;
    for(const auto& group:groups){cout<<group.size();for(int x:group)cout<<' '<<x+1;cout<<endl;}
    if(groups.empty()){cout<<1<<endl;return;}
    string response;if(!(cin>>response))return;
    cout<<decode_binary_test(n,response)+1<<endl;
}

}
namespace t11 {
#include <bits/stdc++.h>
using namespace std; using i128=__int128_t;
struct Penalized { i128 value; int count; };
// solve(lambda): minimizes F(k)+lambda*k; on ties chooses larger k.
// lo is feasible (count>=K); hi is infeasible (count<K).
template<class Solve>
i128 exact_count(int K,long long lo,long long hi,Solve solve) {
    assert(lo<hi && solve(lo).count>=K && solve(hi).count<K);
    while(i128(hi)-lo>1) {
        long long mid=(long long)(i128(lo)+(i128(hi)-lo)/2);
        if(solve(mid).count>=K) lo=mid; else hi=mid;
    }
    return solve(lo).value-i128(lo)*K;
}
bool better(Penalized a,Penalized b) {
    return a.value<b.value || (a.value==b.value && a.count>b.count);
}

}
namespace t12 {
#include <bits/stdc++.h>
using namespace std;
using PenaltyInt=__int128_t;
struct CountCost { PenaltyInt value; int count; };
CountCost choose_count_cost(CountCost a,CountCost b) {
    if(a.value!=b.value) return a.value<b.value?a:b;
    return a.count>b.count?a:b;
}
PenaltyInt nonadjacent_exact_cost(const vector<long long>& a,int K) {
    assert(0<=K && K<=(int(a.size())+1)/2); if(K==0) return 0;
    PenaltyInt bound=1;
    for(long long x:a) bound+=x>=0?PenaltyInt(x):-PenaltyInt(x);
    assert(bound<=1000000000000001LL);
    auto solve=[&](long long penalty) {
        CountCost two{0,0},one{0,0};
        for(long long x:a) {
            CountCost take{two.value+x+penalty,two.count+1};
            auto next=choose_count_cost(one,take); two=one; one=next;
        }
        return one;
    };
    long long lo=-static_cast<long long>(bound),hi=static_cast<long long>(bound);
    assert(solve(lo).count>=K && solve(hi).count<K);
    while(PenaltyInt(hi)-lo>1) {
        long long mid=static_cast<long long>(PenaltyInt(lo)+(PenaltyInt(hi)-lo)/2);
        if(solve(mid).count>=K) lo=mid; else hi=mid;
    }
    return solve(lo).value-PenaltyInt(lo)*K;
}

}
namespace t13 {
#include <bits/stdc++.h>
using namespace std; using i128=__int128_t;
struct MonotoneCHT {
    struct Line { long long a,b; i128 at(long long x) const { return i128(a)*x+b; } };
    deque<Line> h; optional<long long> last_x,last_a;
    void add(long long a,long long b) {
        assert(!last_a || a<*last_a); last_a=a; Line z{a,b};
        while(h.size()>=2) {
            auto x=h[h.size()-2],y=h.back();
            if((i128(y.b)-x.b)*(i128(y.a)-z.a)
                < (i128(z.b)-y.b)*(i128(x.a)-y.a)) break;
            h.pop_back();
        }
        h.push_back(z);
    }
    i128 get(long long x) {
        assert(!h.empty() && (!last_x || *last_x<=x)); last_x=x;
        while(h.size()>1 && h[0].at(x)>=h[1].at(x)) h.pop_front();
        return h.front().at(x);
    }
};

}
namespace t14 {
#include <bits/stdc++.h>
using namespace std; using i128=__int128_t;
struct MonotoneCHT {
    struct Line { long long a,b; i128 at(long long x) const { return i128(a)*x+b; } };
    deque<Line> h; optional<long long> last_x,last_a;
    void add(long long a,long long b) {
        assert(!last_a || a<*last_a); last_a=a; Line z{a,b};
        while(h.size()>=2) {
            auto x=h[h.size()-2],y=h.back();
            if((i128(y.b)-x.b)*(i128(y.a)-z.a)
                < (i128(z.b)-y.b)*(i128(x.a)-y.a)) break;
            h.pop_back();
        }
        h.push_back(z);
    }
    i128 get(long long x) {
        assert(!h.empty() && (!last_x || *last_x<=x)); last_x=x;
        while(h.size()>1 && h[0].at(x)>=h[1].at(x)) h.pop_front();
        return h.front().at(x);
    }
};
vector<i128> affine_transition_dp(const vector<long long>& a,
    const vector<long long>& b) {
    assert(a.size()==b.size()); if(a.empty()) return {};
    vector<i128> dp(a.size()); MonotoneCHT hull; hull.add(b[0],0);
    for(int i=1;i<int(a.size());++i) {
        assert(a[i-1]<=a[i] && b[i-1]>b[i]);
        dp[i]=hull.get(a[i]);
        assert(dp[i]>=LLONG_MIN && dp[i]<=LLONG_MAX);
        hull.add(b[i],static_cast<long long>(dp[i]));
    }
    return dp;
}

}
namespace t15 {
#include <bits/stdc++.h>
using namespace std; using i128=__int128_t;
struct LiChao {
    struct Line { long long a,b; i128 at(long long x) const { return i128(a)*x+b; } };
    vector<long long> x; vector<optional<Line>> t;
    explicit LiChao(vector<long long> xs):x(move(xs)) {
        sort(x.begin(),x.end()); x.erase(unique(x.begin(),x.end()),x.end());
        assert(!x.empty()); t.resize(4*x.size());
    }
    void add(Line z,int v,int l,int r) {
        if(!t[v]) { t[v]=z; return; }
        int m=(l+r)/2;
        bool left=z.at(x[l])<t[v]->at(x[l]),mid=z.at(x[m])<t[v]->at(x[m]);
        if(mid) swap(z,*t[v]);
        if(l==r) return;
        if(left!=mid) add(z,v*2,l,m); else add(z,v*2+1,m+1,r);
    }
    void add(long long a,long long b) { add({a,b},1,0,x.size()-1); }
    optional<i128> get(long long at) const {
        int k=lower_bound(x.begin(),x.end(),at)-x.begin();
        assert(k<int(x.size()) && x[k]==at);
        int v=1,l=0,r=x.size()-1; optional<i128> ans;
        while(true) {
            if(t[v]) { auto z=t[v]->at(at); if(!ans || z<*ans) ans=z; }
            if(l==r) break;
            int m=(l+r)/2;
            if(k<=m) { v*=2; r=m; } else { v=v*2+1; l=m+1; }
        }
        return ans;
    }
};

}
namespace t16 {
#include <vector>
#include <algorithm>
using namespace std;
struct DSU {
    vector<int> p;
    explicit DSU(int n):p(n,-1) {}
    int leader(int v) {
        int r=v;
        while(p[r]>=0) r=p[r];
        while(v!=r) { int next=p[v];p[v]=r;v=next; }
        return r;
    }
    bool merge(int a,int b) {
        a=leader(a);b=leader(b);
        if(a==b) return false;
        if(p[a]>p[b]) swap(a,b);
        p[a]+=p[b];p[b]=a;
        return true;
    }
    bool same(int a,int b) { return leader(a)==leader(b); }
    int size(int v) { return -p[leader(v)]; }
};

}
namespace t17 {
#include <bits/stdc++.h>
using namespace std;

template<class Sequence>
Sequence lcs_hirschberg(const Sequence& a, const Sequence& b) {
    const Sequence* A = &a;
    const Sequence* B = &b;
    if (A->size() < B->size()) swap(A, B);

    Sequence answer;
    if (B->empty()) return answer;
    answer.reserve(B->size());
    using Task = array<size_t, 4>;
    vector<Task> pending{{0, A->size(), 0, B->size()}};

    while (!pending.empty()) {
        auto [al, ar, bl, br] = pending.back();
        pending.pop_back();
        size_t n = ar - al, m = br - bl;
        if (n == 1) {
            for (size_t j = bl; j < br; ++j) {
                if ((*A)[al] == (*B)[j]) {
                    answer.push_back((*A)[al]);
                    break;
                }
            }
            continue;
        }
        if (m == 1) {
            for (size_t i = al; i < ar; ++i) {
                if ((*A)[i] == (*B)[bl]) {
                    answer.push_back((*B)[bl]);
                    break;
                }
            }
            continue;
        }

        size_t am = al + n / 2, cut = 0;
        {
            vector<size_t> forward(m + 1), backward(m + 1);
            for (size_t i = al; i < am; ++i) {
                size_t diagonal = 0;
                for (size_t j = 1; j <= m; ++j) {
                    size_t old = forward[j];
                    forward[j] = ((*A)[i] == (*B)[bl + j - 1])
                        ? diagonal + 1 : max(forward[j], forward[j - 1]);
                    diagonal = old;
                }
            }
            for (size_t i = ar; i > am;) {
                --i;
                size_t diagonal = 0;
                for (size_t j = m; j > 0;) {
                    --j;
                    size_t old = backward[j];
                    backward[j] = ((*A)[i] == (*B)[bl + j])
                        ? diagonal + 1 : max(backward[j], backward[j + 1]);
                    diagonal = old;
                }
            }
            size_t best = 0;
            for (size_t j = 0; j <= m; ++j) {
                if (forward[j] + backward[j] > best) {
                    best = forward[j] + backward[j];
                    cut = j;
                }
            }
        } // DP配列をここで破棄する。

        size_t bm = bl + cut;
        if (bm < br) pending.push_back({am, ar, bm, br});
        if (bl < bm) pending.push_back({al, am, bl, bm});
    }
    return answer;
}

}
namespace t18 {
#include <bits/stdc++.h>
using namespace std;
long long squared_partition_cost(const vector<long long>& a,int K) {
    int n=a.size(); assert(1<=K && K<=n);
    vector<long long> p(n+1);
    for(int i=0;i<n;++i) { assert(a[i]>=0); p[i+1]=p[i]+a[i]; }
    assert(p[n]<=1000000000LL);
    const long long INF=1LL<<62;
    vector<long long> prev(n+1,INF),cur(n+1,INF); prev[0]=0;
    for(int t=1;t<=K;++t) {
        fill(cur.begin(),cur.end(),INF);
        auto solve=[&](auto&& self,int l,int r,int optl,int optr)->void {
            if(l>r) return;
            int m=(l+r)/2,q=-1; long long best=INF;
            for(int j=optl;j<=min(optr,m-1);++j) {
                if(prev[j]==INF) continue;
                long long s=p[m]-p[j],value=prev[j]+s*s;
                if(value<best) { best=value; q=j; }
            }
            assert(q>=0); cur[m]=best;
            self(self,l,m-1,optl,q); self(self,m+1,r,q,optr);
        };
        solve(solve,t,n,t-1,n-1); prev.swap(cur);
    }
    return prev[n];
}

}
int checks=0;void require(bool b,const char*msg){++checks;if(!b){std::cerr<<msg;std::exit(1);}}
int main(){
require(t0::count_sum_at_most({6,8,8,7},17)==7,"contiguous interval COUNT, not arbitrary subset witness");
auto bits=t1::subset_sum_bits({6,8,8,7},17);require((bits[0]>>15&1)&&!(bits[0]>>17&1),"sum bits, no selected original indices");
auto kd=t2::knapsack_exact({{6,1},{8,1},{8,1},{7,1}},17);require(kd[15]==2,"capacity-indexed max values, no witness");
require(!t3::directed_euler_path(2,{{0,1},{0,1},{1,0}},0,0),"railroad2 equal increasing sections require paid augmentation before Euler");
auto hubs=t4::group_hubs(2,{{0,1}});require(hubs.size()==3&&hubs[0][0]==std::pair{2,0},"group movement graph, no speed-order augmentation");
require(t5::first_true(0,201,[](long long k){return k>=100;})==100,"binary search requires external proven shortcut feasibility");
require(t6::maximum_manhattan_distance({{0,0},{100,0},{200,0}})==200,"fixed point diameter200, legal shortcut reduces railway diameter to100");
auto ecc=t7::tree_eccentricities(3,{{0,1,100},{1,2,100}});require(*max_element(ecc.begin(),ecc.end())==200,"fixed tree only; added shortcut creates cycle and reduces diameter to100");
auto parity=t8::parity_bfs({{1},{}},{false,false},0);require(parity[1][0]==1,"parity BFS does not represent run-length puzzle completions");
static_assert(std::is_same_v<decltype(&t9::ask_interval),int(*)(int,int,int&,int)>);require(true,"compile-only protocol; MUST NOT invoke stdin/stdout in original messy callback");
auto groups=t10::binary_test_groups(4);require(groups.size()==2&&t10::decode_binary_test(4,"11")==3,"one hidden item, not whole bit permutation; API cap100 below source128");
auto penalty=[](long long lambda){t11::Penalized best{t11::i128(1)<<100,0};for(int q=1;q<=3;++q){t11::Penalized v{t11::i128(std::array{9,5,3}[q-1])+t11::i128(lambda)*q,q};if(t11::better(v,best))best=v;}return best;};require(t11::exact_count(2,-10,10,penalty)==5,"generic wrapper only; photo DP/convexity/count bounds are caller obligations");
require(t12::nonadjacent_exact_cost({1,100,1},2)==2,"nonadjacent POSITION selection, not square area union partition");
t13::MonotoneCHT hull;hull.add(3,0);hull.add(2,-1);hull.add(1,0);require(hull.get(0)==-1&&hull.get(5)==5,"scalar min lines; no photo count tie metadata or overlap formula");
auto affine=t14::affine_transition_dp({0,1,2},{3,2,1});require(affine[1]==3&&affine[2]==6,"fixed scalar affine recurrence; no geometric preprocessing/photo penalty");
t15::LiChao lichao({-1,0,1});lichao.add(1,0);lichao.add(-1,0);require(lichao.get(1)&&*lichao.get(1)==-1,"scalar line query; generality does not create photo count API");
t16::DSU dsu(3);require(dsu.merge(0,1)&&!dsu.merge(1,0)&&dsu.size(0)==2,"merge primitive, no cut balance/MST cost derivation");
require(t17::lcs_hirschberg(std::string("ABBA"),std::string("BABA")).size()==3,"returns ONE LCS, not colors common to ALL run-length completions");
require(t18::squared_partition_cost({1,1,1},2)==5,"sum-of-weights squared partitions, lacks photo overlap correction and full unrestrictedK scaling");
std::cout<<checks<<"\n";
}