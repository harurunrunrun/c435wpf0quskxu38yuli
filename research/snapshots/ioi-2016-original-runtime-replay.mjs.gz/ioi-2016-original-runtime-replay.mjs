import { readFile, writeFile } from 'node:fs/promises';
import { compileLocalModules } from './flowchartcp-ioi2016-baseline/scripts/local-modules.mjs';
import assert from 'node:assert/strict';
const base='/tmp/flowchartcp-ioi2016-baseline';
const out='/tmp/flowchartcp-ioi2016-runtime';
await compileLocalModules(base,out);
const flow=await import(`${out}/flow.js`);
const routes=JSON.parse(await readFile('/tmp/flowchartcp-ioi2016-routes.json','utf8'));
for(const [task,row] of Object.entries(routes)) {
 const actual=flow.walkFromRoot(row.choices,row.entryGraphId);
 assert.equal(actual.consumed,row.choices.length);
 assert.deepEqual(actual.steps,row.steps.map(s=>({graph:s.graphId,node:s.nodeId,answer:s.answer,target:s.target})));
 assert.deepEqual({graphId:actual.graph.id,nodeId:actual.current.id,type:actual.current.type,title:actual.current.title,options:flow.getNodeOptions(actual.current),techniques:actual.current.techniques??[],conditions:actual.current.conditions??[]},row.reached);
 for(const step of row.steps) {
  const graph=flow.getGraph(step.graphId),node=flow.getNode(graph,step.nodeId);
  assert.equal(node.title,step.question);assert.equal(flow.getAnswerLabel(node,step.answer),step.answerLabel);
 }
}
const result={frozenRuntimeReplayEqual:true,sixCanonicalRoutes:6,entryDomainIds:flow.entryGraphs.map(g=>g.id),flowGraphs:flow.graphs.length,allQuestionsAndFullAnswerLabelsEqual:true,productionApiCoverageClaimed:false};
await writeFile('/tmp/flowchartcp-ioi2016-runtime-replay.json',JSON.stringify(result,null,2)+'\n');console.log(result);
